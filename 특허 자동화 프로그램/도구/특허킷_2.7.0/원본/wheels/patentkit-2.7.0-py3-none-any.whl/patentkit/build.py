# -*- coding: utf-8 -*-
"""제출본 생성 — 명세서 본문 뒤에 청구범위, 그 뒤에 요약서를 둔다.

관청 표기 순서가 명세서 → 청구범위 → 요약서이므로 그 순서로 합친다.
청구범위 파일 말미의 「회피 논거」처럼 내부 검토용으로 붙여 둔 절은 제출본에서 뺀다.
같은 내용이면 다시 쓰지 않는다. 「제출본 변동 없음」이 정상 상태다.
"""
from __future__ import annotations

import re
from pathlib import Path

from .util import 읽기, 쓰기

요약표식 = "## 【요약서】"
청구표식 = "## 【청구범위】"


def 내부절제거(청구범위: str, 절이름들) -> str:
    """내부 검토용 절 이후를 잘라낸다."""
    본문, _꼬리글 = _본문과꼬리(청구범위, 절이름들)
    return 본문 + "\n"


def _본문과꼬리(청구범위: str, 절이름들) -> tuple:
    """내부 절을 잘라 낸 본문과, 본문 뒤에 남아 있던 구분 줄을 나눈다."""
    자른곳 = len(청구범위)
    for 이름 in 절이름들 or []:
        맞음 = re.search(rf"^#{{1,6}}\s*{re.escape(이름)}\s*$", 청구범위, re.M)
        if 맞음:
            자른곳 = min(자른곳, 맞음.start())
    남은것 = 청구범위[:자른곳].rstrip("\n")
    줄들 = 남은것.split("\n")
    끝 = len(줄들) - 1
    while 끝 >= 0 and (not 줄들[끝].strip() or re.fullmatch(r"[-*_]{3,}", 줄들[끝].strip())):
        끝 -= 1
    본문 = "\n".join(줄들[:끝 + 1]).rstrip()
    꼬리 = "\n".join(줄들[끝 + 1:])
    return 본문, ("\n" + 꼬리 + "\n") if 꼬리.strip("\n") or 꼬리 else ""


def 제출본만들기(명세서: str, 청구범위: str, 내부절=None) -> str:
    """명세서에 청구범위를 끼워 넣은 제출본 문자열을 만든다."""
    청구, 청구꼬리 = _본문과꼬리(청구범위, 내부절)

    # 명세서에 청구범위가 이미 편입돼 있으면 그 자리를 새 청구범위로 갈음한다.
    편입 = re.search(rf"^{re.escape(청구표식)}\s*$", 명세서, re.M)
    요약 = re.search(rf"^{re.escape(요약표식)}\s*$", 명세서, re.M)
    if not 요약:
        raise ValueError(f"명세서에 「{요약표식}」 표제가 없어 청구범위를 끼울 자리를 찾지 못한다")

    앞 = 명세서[:편입.start()] if 편입 else 명세서[:요약.start()]
    뒤 = 명세서[요약.start():]
    # 청구범위와 【요약서】 사이의 구분 줄은 원래 모양을 그대로 지킨다. 명세서에
    # 편입돼 있었으면 명세서 쪽 모양을, 아니면 청구범위 파일 쪽 모양을 쓴다.
    # 그래야 제출본을 다시 만들어도 없던 변경이 생기지 않는다.
    if 편입:
        _사이본문, 꼬리 = _본문과꼬리(명세서[편입.start():요약.start()], None)
    else:
        꼬리 = 청구꼬리
    return 앞.rstrip() + "\n\n" + 청구 + (꼬리 or "\n") + "\n" + 뒤.lstrip("\n")


def 실행(폴더: Path, 설정본, 조용히: bool = False) -> tuple:
    """폴더 안의 명세서·청구범위로 제출본 파일을 갱신한다.

    반환 (대상경로, 변동여부, 메시지)
    """
    폴더 = Path(폴더)
    명세서경로 = 폴더 / 설정본.경로("spec_md", "01_명세서.md")
    청구경로 = 폴더 / 설정본.경로("claims_md", "02_청구범위.md")
    대상 = 폴더 / 설정본.경로("submission_md", "03_제출본_명세서_청구범위.md")

    if not 명세서경로.exists():
        raise FileNotFoundError(f"명세서를 찾지 못했다: {명세서경로}")
    if not 청구경로.exists():
        raise FileNotFoundError(f"청구범위를 찾지 못했다: {청구경로}")

    제출본 = 제출본만들기(읽기(명세서경로), 읽기(청구경로),
                       설정본.값("build", "internal_sections", 기본=["회피 논거"]))
    기존길이 = len(읽기(대상)) if 대상.exists() else 0
    변동 = 쓰기(대상, 제출본)
    메시지 = ("제출본 변동 없음" if not 변동
              else f"제출본 갱신 — {기존길이:,}자 → {len(제출본):,}자")
    if not 조용히:
        print(메시지)
    return 대상, 변동, 메시지
