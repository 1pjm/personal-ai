# -*- coding: utf-8 -*-
"""IR 포트폴리오 — 투자 설명 자리에 그대로 들고 갈 한 장짜리 웹 문서를 만든다.

브라우저로 열고, 인쇄하면 A4 로 나온다. 안의 숫자·문헌·논거는 전부 이 프로젝트의
실측 자료에서 온다. 지어낸 값이 없고, 비어 있는 자리는 비어 있다고 적는다.
등록 여부는 심사관이 판단한다 — 이 문서는 그 판단을 통과할 준비가 어디까지
됐는지를 보이는 것이다.

  patentkit ir            프로젝트 루트에 IR_특허포트폴리오.html 을 만든다
                          건별 _근거자료/05_등록성_분석.md 도 함께 갱신한다
"""
from __future__ import annotations

import base64
import html
from datetime import date
from pathlib import Path

from . import candidates, compare, config, sources, 기술분야, 등록성

파일이름 = "IR_특허포트폴리오.html"

상태색 = {"갖춤": "ok", "진행": "go", "사람 판단": "hu", "위험": "risk"}


def _막기(글) -> str:
    return html.escape(str(글 or ""))


def _도1(자리: Path, 설정본) -> str:
    """대표 도면 하나를 base64 로 넣는다. 없으면 빈 글."""
    폴더 = Path(자리) / (설정본.경로("drawings_dir", "도면") or "도면")
    그림들 = sorted(폴더.glob("도1*.png")) or sorted(폴더.glob("*.png"))
    if not 그림들:
        return ""
    자료 = base64.b64encode(그림들[0].read_bytes()).decode("ascii")
    return f"data:image/png;base64,{자료}"


def _축들(자리: Path, 설정본) -> list:
    """독립항 1을 구성요소로 쪼갠 축 이름들."""
    from . import doc

    경로 = doc.청구범위찾기(자리, 설정본) or doc.명세서찾기(자리, 설정본)
    if not 경로:
        return []
    문 = doc.읽어들이기(경로)
    독립 = [항 for 항 in 문.청구항들 if 항.독립항]
    if not 독립:
        return []
    return [요소["축"] for 요소 in compare.구성요소쪼개기(독립[0].본문)
            if 요소["축"] != "전제부"][:7]


def _대비수치(자리: Path, 설정본) -> dict:
    """대비표에서 나온 사실 셋 — 문헌 수, 전문 확보 수, 대응 없음 축 수."""
    from . import 보기자료

    답 = 보기자료.대비(자리, 설정본)
    대응없음 = sum(1 for 문헌 in 답["청구항대비"] if not 문헌["대조못함"]
               for 줄 in 문헌["줄"] if not 줄["대응있음"])
    확보 = sum(1 for 문 in 답["목록"] if 문["청구항있음"])
    return {"문헌수": 답["문헌수"], "확보": 확보, "대응없음": 대응없음,
           "대조못함": sum(1 for 문헌 in 답["청구항대비"] if 문헌["대조못함"])}


def _독립항1(자리: Path, 설정본) -> str:
    from . import doc

    경로 = doc.청구범위찾기(자리, 설정본) or doc.명세서찾기(자리, 설정본)
    if not 경로:
        return ""
    문 = doc.읽어들이기(경로)
    독립 = [항 for 항 in 문.청구항들 if 항.독립항]
    return (독립[0].본문 or "").strip() if 독립 else ""


def 자료모으기(뿌리: Path) -> dict:
    from .web import 출원건모으기, 한건상태

    뿌리 = Path(뿌리)
    후보들 = {한건.get("출원건"): 한건 for 한건 in candidates.읽기(뿌리)}
    건들 = []
    for 폴더 in 출원건모으기(뿌리):
        설정본 = config.불러오기(폴더)
        상태 = 한건상태(폴더)
        등록 = 등록성.분석(폴더, 설정본)
        건들.append({
            "이름": 폴더.name, "설정본": 설정본, "상태": 상태, "등록": 등록,
            "영문": 설정본.값("invention", "title_en", 기본="") or "",
            "축": _축들(폴더, 설정본),
            "그림": _도1(폴더, 설정본),
            "등급": (후보들.get(폴더.name) or {}).get("등급", "보류"),
            "판단자": (후보들.get(폴더.name) or {}).get("판단자", ""),
            "분야": 기술분야.분류(폴더.name),
            "대비": _대비수치(폴더, 설정본),
            "독립항1": _독립항1(폴더, 설정본),
            "ipc": [{"부호": 부호, "뜻": 기술분야.뜻(부호)}
                   for 부호 in (설정본.값("ipc", 기본=[]) or [])],
        })
    회사 = {"이름": "퍼스널에이아이", "대표": "", "사업자": "", "주소": "", "출처": ""}
    if 건들:
        받침 = 건들[0]["설정본"].값("applicants", 기본=[{}])
        첫 = (받침[0] or {}) if 받침 else {}
        회사 = {"이름": (첫.get("name") or "퍼스널에이아이").lstrip("★"),
              "대표": (첫.get("representative") or "").lstrip("★"),
              "사업자": (첫.get("biz_no") or "").lstrip("★") if not str(첫.get("biz_no", "")).startswith("★") else "",
              "주소": (첫.get("address") or "").lstrip("★"),
              "출처": 첫.get("biz_no_출처", "")}
    return {"뿌리": 뿌리, "건들": 건들, "출원인": 회사["이름"], "회사": 회사,
            "오늘": str(date.today())}


# ── 화면 ────────────────────────────────────────────────────────
멋 = """
:root{--ground:#F4F4F1;--panel:#fff;--panel2:#FAFAF8;--ink:#1C2530;--soft:#55606C;
 --faint:#8A949E;--rule:#DEDFD9;--firm:#C6C9BF;--seal:#A32A1C;--sealw:#F7E8E5;
 --ok:#2C6E63;--okw:#E3EFEC;--warn:#8A6A17;--warnw:#F7EFDC;
 --disp:"Gowun Batang","바탕",Batang,serif;--body:"맑은 고딕","Malgun Gothic",system-ui,sans-serif;
 --mono:Consolas,"D2Coding",monospace}
*{box-sizing:border-box}
body{margin:0;background:var(--ground);color:var(--ink);font-family:var(--body);
 font-size:14px;line-height:1.65;-webkit-font-smoothing:antialiased}
.page{max-width:960px;margin:0 auto;padding:0 1.2rem 3rem}
section{background:var(--panel);border:1px solid var(--rule);border-radius:8px;
 margin-top:1.2rem;padding:1.6rem 2rem;box-shadow:0 1px 2px rgba(28,37,48,.05)}
h1,h2{font-family:var(--disp);font-weight:700}
h2{font-size:1.25rem;margin:0 0 1rem;padding-bottom:.6rem;border-bottom:2px solid var(--ink)}
h2 .no{color:var(--seal);font-family:var(--mono);font-size:.85rem;margin-right:.5rem}
h3{font-size:.95rem;margin:1.2rem 0 .4rem}
table{border-collapse:collapse;width:100%;font-size:.83rem}
th{font-size:.68rem;letter-spacing:.07em;color:var(--faint);text-transform:uppercase;
 font-weight:500;text-align:left;padding:.35rem .55rem;border-bottom:1px solid var(--firm)}
td{padding:.45rem .55rem;border-bottom:1px solid var(--rule);vertical-align:top}
.num{font-family:var(--mono);font-variant-numeric:tabular-nums;white-space:nowrap}
.cover{background:var(--ink);color:#F2F1EC;border:0;padding:3.2rem 2.6rem;position:relative}
.cover .seal{width:52px;height:52px;border:2.5px solid #E0705F;border-radius:5px;
 display:grid;place-items:center;color:#E0705F;font-family:var(--disp);font-size:1.6rem;margin-bottom:1.6rem}
.cover h1{font-size:2rem;margin:.2rem 0 .6rem;line-height:1.3}
.cover .who{font-size:1rem;color:#B8BDB4}
.cover .strip{position:absolute;top:1.4rem;right:2rem;font-family:var(--mono);font-size:.7rem;
 letter-spacing:.25em;color:#E0705F;border:1px solid #E0705F;padding:.2rem .7rem;border-radius:3px}
.cover .meta{margin-top:2.2rem;display:flex;gap:2.4rem;flex-wrap:wrap;font-size:.8rem;color:#B8BDB4}
.cover .meta b{display:block;color:#F2F1EC;font-family:var(--mono);font-size:1.35rem}
.note{background:var(--warnw);color:var(--warn);border-radius:5px;padding:.6rem .9rem;
 font-size:.8rem;margin:.9rem 0 0}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(128px,1fr));gap:.7rem}
.stat{background:var(--panel2);border:1px solid var(--rule);border-radius:6px;padding:.7rem .9rem}
.stat b{display:block;font-family:var(--mono);font-size:1.5rem}
.stat span{font-size:.72rem;color:var(--faint)}
.chip{display:inline-block;background:var(--panel2);border:1px solid var(--firm);
 border-radius:14px;padding:.1rem .6rem;font-size:.74rem;margin:0 .25rem .3rem 0}
.st{display:inline-block;border-radius:3px;padding:.05rem .5rem;font-size:.72rem;
 font-family:var(--mono);white-space:nowrap}
.st.ok{background:var(--okw);color:var(--ok)} .st.go{background:#E8ECF3;color:#3D5578}
.st.hu{background:var(--warnw);color:var(--warn)} .st.risk{background:var(--sealw);color:var(--seal)}
.split{display:flex;gap:1.6rem;align-items:flex-start}
.split .txt{flex:1 1 58%;min-width:0} .split .fig{flex:0 1 38%}
.fig img{width:100%;border:1px solid var(--rule);border-radius:5px;background:#fff}
.fig figcaption{font-family:var(--mono);font-size:.68rem;color:var(--faint);margin-top:.3rem}
.en{color:var(--faint);font-size:.8rem;margin:-.6rem 0 .8rem}
.ref{margin:.5rem 0 .9rem;padding-left:.9rem;border-left:3px solid var(--firm)}
.ref b{font-size:.85rem} .ref p{margin:.15rem 0 0;font-size:.8rem;color:var(--soft)}
.lane{display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.8rem}
.step{flex:1 1 150px;background:var(--panel2);border:1px solid var(--rule);border-radius:6px;
 padding:.6rem .8rem;position:relative}
.step b{display:block;font-size:.82rem} .step span{font-size:.72rem;color:var(--soft)}
.step .k{font-family:var(--mono);font-size:.66rem;color:var(--seal)}
footer{margin-top:1.4rem;font-size:.72rem;color:var(--faint);line-height:1.7}
footer a{color:var(--seal)}
@media print{
 body{background:#fff;font-size:11.5px}
 .page{max-width:none;padding:0}
 section{border:0;box-shadow:none;border-radius:0;padding:1.2rem .2rem;break-inside:avoid}
 .case{page-break-before:always}
 .cover{-webkit-print-color-adjust:exact;print-color-adjust:exact}
}
"""

머리말 = ("이 문서의 수치·문헌·논거는 전부 프로젝트 실측 자료에서 자동 집계한 것이다. "
       "등록 여부는 심사관이 판단하며, 어떤 표현도 등록을 보장하지 아니한다.")


def _분야지도(건들: list) -> str:
    """대분류 → 건별 자리 → 세부 분야. 청구항 구성 축에서 나온 사실만 싣는다."""
    묶음들 = []
    for 묶음 in 기술분야.지도():
        카드들 = []
        for 이름, 자리 in 묶음["건들"].items():
            건 = next((하나 for 하나 in 건들 if 하나["이름"] == 이름), None)
            if not 건:
                continue
            세부 = "".join(f"<li>{_막기(줄)}</li>" for 줄 in 자리["세부"])
            카드들.append(
                f"<td style='width:50%'><b style='font-size:.88rem'>{_막기(자리['자리'])}</b>"
                f"<div style='font-size:.74rem;color:var(--faint)'>{_막기(건['상태']['명칭'])[:46]}… · "
                f"청구항 {건['상태']['청구항수']}</div>"
                f"<ul style='margin:.4rem 0 0;padding-left:1.1rem;font-size:.79rem'>{세부}</ul></td>")
        묶음들.append(
            f"<h3>{_막기(묶음['대분류'])} <span style='font-weight:400;color:var(--faint);"
            f"font-size:.75rem'>{_막기(묶음['영문'])}</span></h3>"
            f"<p style='font-size:.83rem;color:var(--soft);margin:.2rem 0 .6rem'>{_막기(묶음['설명'])}</p>"
            f"<table><tr>{''.join(카드들)}</tr></table>")

    부호들 = {}
    for 건 in 건들:
        for 줄 in 건["ipc"]:
            부호들.setdefault(줄["부호"], {"뜻": 줄["뜻"], "건": []})
            부호들[줄["부호"]]["건"].append(건["이름"].split("_")[1])
    ipc표 = "".join(
        f"<tr><td class=num>{_막기(부호)}</td><td>{_막기(정보['뜻'] or '뜻 미등록 — 사람이 확인')}</td>"
        f"<td class=num>{', '.join(sorted(set(정보['건'])))}</td></tr>"
        for 부호, 정보 in sorted(부호들.items()))
    return ("".join(묶음들)
            + "<h3>국제특허분류(IPC) 지도</h3>"
            + "<table><thead><tr><th>부호</th><th>뜻 (WIPO IPC)</th><th>발명</th></tr></thead>"
            + f"<tbody>{ipc표}</tbody></table>"
            + f"<p style='font-size:.72rem;color:var(--faint)'>부호 뜻은 WIPO 국제특허분류 "
            + f"공표본에서 확인 ({기술분야.IPC확인일}) · {기술분야.IPC출처}</p>")


def _조문표(등록: dict) -> str:
    줄들 = []
    for 줄 in 등록["조문"]:
        색 = 상태색.get(줄["상태"], "go")
        줄들.append(
            f"<tr><td class=num>{_막기(줄['법령'])}</td><td>{_막기(줄['이름'])}</td>"
            f"<td><span class='st {색}'>{_막기(줄['상태'])}</span></td>"
            f"<td>{_막기(줄['근거'])}</td><td>{_막기(줄['할일'] or '—')}</td></tr>")
    return ("<table><thead><tr><th>조문</th><th>항목</th><th>상태</th>"
            "<th>지금 갖춘 것</th><th>남은 일</th></tr></thead><tbody>"
            + "".join(줄들) + "</tbody></table>")


def _건카드(차례: int, 건: dict) -> str:
    상태, 등록 = 건["상태"], 건["등록"]
    축칩 = "".join(f"<span class=chip>{_막기(축)}</span>" for 축 in 건["축"])
    그림 = (f"<figure class=fig style='margin:0'><img src='{건['그림']}' alt='도 1'>"
          f"<figcaption>도 1 — 블록도 (제출용 렌더)</figcaption></figure>"
          if 건["그림"] else "")
    논거 = "".join(f"<div class=ref><b>{_막기(줄['문헌'])}</b>"
                f"<p>{_막기(줄['요지'])}</p></div>"
                for 줄 in 등록["회피논거"][:4])
    더 = len(등록["회피논거"]) - 4
    if 더 > 0:
        논거 += f"<p style='font-size:.75rem;color:var(--faint)'>그 밖에 {더}건 — 건별 등록성 분석 문서에 전부 실었다.</p>"
    사다리 = " · ".join(f"제{하나['독립항']}항 아래 {len(하나['칸'])}단"
                    for 하나 in 등록["사다리"])
    등급말 = candidates.등급뜻.get(건["등급"], "")
    return f"""
<section class=case>
  <h2><span class=no>발명 {차례:02d}</span>{_막기(상태['명칭'])}</h2>
  <p class=en>{_막기(건['영문'])}</p>
  <p style="margin:-.4rem 0 1rem;font-size:.82rem"><span class="st go">{_막기(건['분야']['대분류'])}</span>
   <b style="margin-left:.4rem">{_막기(건['분야']['자리'])}</b>
   <span style="color:var(--faint);font-family:var(--mono);font-size:.72rem;margin-left:.5rem">{" · ".join(_막기(줄['부호']) for 줄 in 건['ipc'])}</span></p>
  <div class=split><div class=txt>
    <div class=grid>
      <div class=stat><b>{상태['청구항수']}</b><span>청구항 (독립 {_막기(상태['독립항'])})</span></div>
      <div class=stat><b>{상태['단락수']}</b><span>명세서 단락</span></div>
      <div class=stat><b>{상태['도면수']}</b><span>도면</span></div>
      <div class=stat><b>{등록['선행']['문헌수']}</b><span>선행문헌 검토</span></div>
      <div class=stat><b>{len(등록['회피논거'])}</b><span>구별 논거 서면</span></div>
      <div class=stat><b>{건['대비']['대응없음']}</b><span>대응 없음 축 (회피 논거 자리)</span></div>
      <div class=stat><b>{건['대비']['확보']}/{건['대비']['문헌수']}</b><span>상대 청구항 확보</span></div>
      <div class=stat><b>{건['등급']}</b><span>사람이 매긴 등급{'' if not 등급말 else ' · ' + _막기(등급말)}</span></div>
    </div>
    <h3>독립항 1 의 구성 축</h3>{축칩 or '<span class=chip>—</span>'}
  </div>{그림}</div>
  <details style="margin:1rem 0 0"><summary style="cursor:pointer;font-size:.88rem;font-weight:700">독립항 1 전문 — 권리범위의 몸통 (누르면 펼친다)</summary>
    <p style="white-space:pre-line;font-size:.82rem;background:var(--panel2);border:1px solid var(--rule);border-radius:5px;padding:.8rem 1rem;margin:.5rem 0 0">{_막기(건['독립항1'])}</p></details>
  <h3>거절이유 조문별 준비 상태</h3>
  {_조문표(등록)}
  <h3>핵심 문헌과 구별 논거 <span style="font-weight:400;font-size:.75rem;color:var(--faint)">— 문헌을 읽고 사람이 썼다. 킷은 옮겨 보일 뿐이다</span></h3>
  {논거 or "<p style='font-size:.8rem'>구별 논거가 아직 없다.</p>"}
  <h3>거절 시 물러설 보정 사다리 (제47조)</h3>
  <p style="font-size:.83rem">{_막기(사다리) or '—'} — 한정은 이미 종속항에 들어 있어 신규사항 금지에 걸리지 아니한다.</p>
</section>"""


def html만들기(자료: dict) -> str:
    건들 = 자료["건들"]
    합청구항 = sum(건["상태"]["청구항수"] for 건 in 건들)
    합도면 = sum(건["상태"]["도면수"] for 건 in 건들)
    합논거 = sum(len(건["등록"]["회피논거"]) for 건 in 건들)
    선행수 = max((건["등록"]["선행"]["문헌수"] for 건 in 건들), default=0)
    자사수 = max((건["등록"]["선행"]["자사"] for 건 in 건들), default=0)
    증거수 = max((건["등록"]["증거수"] for 건 in 건들), default=0)
    기한 = next((건["등록"]["공지예외기한"] for 건 in 건들 if 건["등록"]["공지예외기한"]), "")
    위험합 = sum(건["등록"]["위험수"] for 건 in 건들)

    지도 = "".join(
        f"<tr><td><b>{_막기(건['상태']['명칭'])[:52]}{'…' if len(건['상태']['명칭'])>52 else ''}</b>"
        f"<div style='font-size:.72rem;color:var(--faint)'>{_막기(건['이름'])}</div></td>"
        f"<td style='font-size:.78rem'>{_막기(건['분야']['자리'] or '—')}</td>"
        f"<td class=num>{건['상태']['청구항수']}</td>"
        f"<td class=num>{len(건['등록']['회피논거'])}</td>"
        f"<td class=num>{건['상태']['진행']}%</td>"
        f"<td><span class='st {'risk' if 건['등록']['위험수'] else 'go'}'>"
        f"{'위험 ' + str(건['등록']['위험수']) + '건' if 건['등록']['위험수'] else '진행 중'}</span></td>"
        f"<td class=num>{_막기(건['등급'])}</td></tr>"
        for 건 in 건들)

    미확정합 = sum(건["등록"]["미확정수"] for 건 in 건들)
    확보합 = sum(건["등록"]["대비"]["청구항확보"] for 건 in 건들)
    대비합 = sum(건["등록"]["대비"]["문헌수"] for 건 in 건들)
    if 미확정합:
        확정줄 = (f"<tr><td>출원서 확정 값</td><td>확정되지 아니한 값 {미확정합}칸이 남아 있다</td>"
                "<td>설정 화면에서 채우면 즉시 출원 가능 판정으로 바뀐다</td></tr>")
    else:
        확정줄 = ("<tr><td>출원서 확정 값</td><td>모두 채워짐 — 4건 출원 가능 판정. "
                "발명자는 대표자 성함으로 기재됨</td>"
                "<td>출원 전 실제 발명 기여자가 맞는지 최종 확인한다 — 발명자 기재는 "
                "뒤에 정정하기 번거롭다</td></tr>")
    if 확보합 >= 대비합 and 대비합:
        전문줄 = (f"<tr><td>상대 청구항 전문</td><td>대비 문헌 {대비합}건 전문 확보 완료</td>"
                "<td>대비표의 「사람이 판정」 칸을 변리사와 확정한다</td></tr>")
    else:
        전문줄 = (f"<tr><td>상대 청구항 전문</td><td>대비 문헌 {대비합}건 중 확보 {확보합}건</td>"
                "<td>KIPRIS 열쇠 발급 뒤 단추 한 번으로 자동 수집 (기능 구현·검증 완료)</td></tr>")
    리스크 = f"""
<table><thead><tr><th>솔직하게 적는 리스크</th><th>지금 상태</th><th>대응</th></tr></thead><tbody>
{확정줄}
{전문줄}
<tr><td>구현 뒷받침</td><td>구성요소별 대조표는 준비, 소스 대조 실행 전</td>
    <td>제품 소스 폴더 지정 뒤 대조 실행. 구현 미확인 한정은 청구항에서 뺀다</td></tr>
<tr><td>미공개 타사 선출원</td><td>어떤 조사로도 보이지 아니하는 구조적 맹점</td>
    <td>빠른 출원이 유일한 대응 — 그래서 마감 관리가 이 킷에 들어 있다</td></tr>
<tr><td>등록 판단</td><td>심사관 몫이다</td>
    <td>조문별 준비 상태와 물러설 사다리로 거절이유에 대응한다</td></tr>
</tbody></table>"""

    타임라인 = f"""
<div class=lane>
 <div class=step><span class=k>지남</span><b>제품 공개</b><span>2026-08-02 · 증거 {증거수}건 헤더째 보관</span></div>
 <div class=step><span class=k>지금</span><b>출원 준비</b><span>명세서 4건 검사 통과 · 확정 값 2칸 대기</span></div>
 <div class=step><span class=k>마감 {_막기(기한)}</span><b>출원 + 공지예외 주장</b><span>취지 기재 · 증명서류는 출원일부터 30일 안</span></div>
 <div class=step><span class=k>출원일 + 1년</span><b>국내우선권 정규출원</b><span>가출원을 쓰는 경우 (제55조)</span></div>
 <div class=step><span class=k>출원일 + 3년</span><b>심사청구 마감</b><span>제59조 · 우선심사 신청 가능</span></div>
 <div class=step><span class=k>심사</span><b>거절이유 대응</b><span>종속항 사다리로 후퇴 보정 (제47조)</span></div>
</div>"""

    무결성 = """
<table><thead><tr><th>실행력 근거</th><th>확인한 방법</th></tr></thead><tbody>
<tr><td>제출본 재현성</td><td>4건 모두 명세서+청구범위+요약서 합본을 다시 만들어 기존 제출본과 글자 단위로 같음을 확인</td></tr>
<tr><td>형식 검사 자동화</td><td>표제·단락번호·청구항 인용·카테고리·도면·부호·문체·기한 10개 묶음, 자체 시험으로 상시 검증</td></tr>
<tr><td>자료 출처 보존</td><td>KIPRIS 응답 원본 XML·공개 증거 응답 헤더를 그대로 보관 — 뒤에 다툼이 생기면 그것이 증거다</td></tr>
<tr><td>사람·기계 역할 분리</td><td>기계는 사실을 세고, 등급·논거·판정은 사람이 이름과 날짜를 남기고 정한다</td></tr>
</tbody></table>"""

    출처들 = "".join(
        f"<div>· {_막기(항목.get('법령') or 항목['이름'])} — "
        f"<a href='{항목['출처']}'>{_막기(항목['출처이름'])}</a></div>"
        for 열쇠, 항목 in sources.근거표.items())

    return f"""<!doctype html><html lang=ko><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<title>특허 포트폴리오 — {_막기(자료['출원인'])}</title><style>{멋}</style></head><body>
<div class=page>

<section class=cover>
  <div class=strip>CONFIDENTIAL</div>
  <div class=seal>特</div>
  <h1>특허 포트폴리오<br>출원 준비 현황과 등록성 근거</h1>
  <div class=who>{_막기(자료['출원인'])}{(' · 대표 ' + _막기(자료['회사']['대표'])) if 자료['회사']['대표'] else ''}{(' · 사업자등록번호 ' + _막기(자료['회사']['사업자'])) if 자료['회사']['사업자'] else ''}</div>
  <div class=who style="font-size:.8rem;margin-top:.25rem">{_막기(자료['회사']['주소'])} · {_막기(자료['오늘'])}</div>
  <div class=meta>
    <div><b>{len(건들)}</b>출원 준비 발명</div>
    <div><b>{합청구항}</b>청구항</div>
    <div><b>{선행수}</b>선행문헌 검토</div>
    <div><b>{합논거}</b>구별 논거 서면</div>
    <div><b>{합도면}</b>제출용 도면</div>
  </div>
  <div style="margin-top:1.6rem;font-size:.82rem;color:#B8BDB4">
    기술 분야 — {" · ".join(_막기(묶음["대분류"]) for 묶음 in 기술분야.지도())}</div>
</section>

<section>
  <h2><span class=no>01</span>한눈에</h2>
  <div class=grid>
    <div class=stat><b>{len(건들)}</b><span>출원 준비 발명</span></div>
    <div class=stat><b>{합청구항}</b><span>청구항 (건당 16)</span></div>
    <div class=stat><b>{선행수}</b><span>KIPRIS 선행문헌 검토</span></div>
    <div class=stat><b>{자사수}</b><span>자사 선출원 (권리 연결)</span></div>
    <div class=stat><b>{증거수}</b><span>공개 증거 · 헤더 보관</span></div>
    <div class=stat><b>{_막기(기한) or '—'}</b><span>공지예외 출원 마감</span></div>
  </div>
  <div class=note>{머리말} 남은 위험 표시 {위험합}건은 아래 각 발명 카드와 리스크 절에 그대로 적었다.</div>
  <h3>포트폴리오 지도</h3>
  <table><thead><tr><th>발명</th><th>분야 자리</th><th>청구항</th><th>구별 논거</th><th>준비</th>
  <th>상태</th><th>등급*</th></tr></thead><tbody>{지도}</tbody></table>
  <p style="font-size:.72rem;color:var(--faint)">* 등급은 사람이 매기고 판단자·날짜가 기록된다. 킷은 등급을 매기지 아니한다.</p>
</section>

<section>
  <h2><span class=no>02</span>기술 분야 지도 — 무엇을 권리화하는가</h2>
  {_분야지도(건들)}
</section>

{"".join(_건카드(차례 + 1, 건) for 차례, 건 in enumerate(건들))}

<section>
  <h2><span class=no>{len(건들) + 5:02d}</span>리스크와 대응 — 숨기지 아니한 것</h2>
  {리스크}
</section>

<section>
  <h2><span class=no>{len(건들) + 3:02d}</span>등록까지의 절차</h2>
  {타임라인}
</section>

<section>
  <h2><span class=no>{len(건들) + 4:02d}</span>프로세스 무결성 — 이 숫자를 믿어도 되는 까닭</h2>
  {무결성}
</section>

<footer>
  <b>근거 법령과 출처</b> (확인일 {sources.확인일} — 법령은 개정되므로 출원 전 원문을 다시 확인한다)
  {출처들}
  <div style="margin-top:.6rem">{머리말}</div>
  <div>이 문서는 특허 자동화 킷이 프로젝트 자료에서 자동 생성했다 · {_막기(자료['오늘'])}</div>
</footer>
</div></body></html>"""


def 만들기(뿌리: Path) -> dict:
    """건별 등록성 분석과 포트폴리오를 함께 만든다."""
    뿌리 = Path(뿌리)
    자료 = 자료모으기(뿌리)
    건별 = []
    for 건 in 자료["건들"]:
        건별.append(등록성.만들기(뿌리 / 건["이름"], 건["설정본"]))
    대상 = 뿌리 / 파일이름
    대상.write_text(html만들기(자료), encoding="utf-8")
    return {"포트폴리오": 대상, "건별": 건별, "건수": len(자료["건들"])}
