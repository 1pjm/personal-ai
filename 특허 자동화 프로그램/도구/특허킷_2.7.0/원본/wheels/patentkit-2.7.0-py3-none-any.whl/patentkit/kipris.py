# -*- coding: utf-8 -*-
"""KIPRIS Plus 열린 API — 문헌 하나의 서지와 청구항 전문을 받아 온다.

대비표의 「상대 청구항」 칸은 손으로 옮겨 적던 자리였다. 옮겨 적다 한 줄을
빠뜨리면 회피 논거가 사실과 어긋나므로, 받아 올 수 있으면 받아 오는 편이 낫다.

  getWordSearch                     낱말로 찾는다 (prior_art 가 쓴다)
  getBibliographyDetailInfoSearch   출원번호로 서지와 청구항을 받는다 (여기서 쓴다)

  터  https://plus.kipris.or.kr/kipo-api/kipi/patUtiModInfoSearchSevice/
  확인 2026-08-26 · https://plus.kipris.or.kr/portal/main/apiStatus.do?menuNo=210157

**열쇠가 있어야 돈다.** KIPRIS Plus 나 공공데이터포털에서 발급받아
patent_config.json 의 `prior_art.kipris_key` 에 넣거나 환경변수 `KIPRIS_KEY`
로 준다. 열쇠는 설정 파일에 남으므로 그 파일을 사외로 보내지 아니한다.

응답의 칸 이름은 서비스 개정에 따라 조금씩 달라져 왔다(`claimInfoArray/claimInfo/
claim`, `patentClaimInfo` 등). 그래서 이름을 하나로 못박지 아니하고 **이름에
claim 이 들어간 칸을 나온 차례대로 훑는다.** 못 찾으면 못 찾았다고 말한다.
없는 것을 지어내는 것보다 낫다.
"""
from __future__ import annotations

import re
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from xml.etree import ElementTree

한국시각 = timezone(timedelta(hours=9))

기본터 = "https://plus.kipris.or.kr/kipo-api/kipi/patUtiModInfoSearchSevice"
상세오퍼레이션 = "getBibliographyDetailInfoSearch"
받는이름 = "patentkit/2.3 (KIPRIS Plus REST)"
확인일 = "2026-08-26"

# 청구항 칸을 찾을 때 쓸 이름. 이름에 claim 이 들어가되 아래는 청구항 글이 아니다.
청구항아닌칸 = {"claimcount", "claimcnt", "claimnumber", "claimno", "totalclaimcount"}


class 열쇠없음(RuntimeError):
    """서비스 열쇠가 없거나 ★ 인 채로 남아 있다."""


class 받지못함(RuntimeError):
    """망이 끊겼거나 KIPRIS 가 오류를 돌려주었다."""


def 지금() -> str:
    return datetime.now(한국시각).strftime("%Y-%m-%d %H:%M:%S")


def 열쇠찾기(설정본=None) -> str:
    """설정 파일 → 환경변수 차례로 찾는다."""
    import os

    열쇠 = ""
    if 설정본 is not None:
        열쇠 = (설정본.값("prior_art", "kipris_key", 기본="") or "").strip()
    if not 열쇠 or 열쇠.startswith("★"):
        열쇠 = (os.environ.get("KIPRIS_KEY") or "").strip()
    if not 열쇠 or 열쇠.startswith("★"):
        raise 열쇠없음(
            "KIPRIS 서비스 열쇠가 없다.\n"
            "  · patent_config.json 의 prior_art.kipris_key 에 넣거나\n"
            "  · 환경변수 KIPRIS_KEY 로 준다.\n"
            "  열쇠는 KIPRIS Plus(plus.kipris.or.kr) 또는 공공데이터포털에서 발급받는다.")
    return 열쇠


def 출원번호정리(번호: str) -> str:
    """「10-2024-0176792」·「1020240176792」 를 KIPRIS 가 받는 13자리로 맞춘다."""
    숫자 = re.sub(r"\D", "", 번호 or "")
    return 숫자


def 쓸만한번호인가(번호: str) -> bool:
    """13자리(출원번호)나 11~13자리 공개·등록번호면 물어볼 만하다."""
    return len(출원번호정리(번호)) >= 10


def 부르기(오퍼레이션: str, 물음: dict, 열쇠: str, 터: str = "",
        시간제한: int = 60) -> ElementTree.Element:
    """REST 로 한 번 부르고 XML 뿌리를 돌려준다."""
    바탕 = (터 or 기본터).rstrip("/")
    붙임 = dict(물음)
    붙임["ServiceKey"] = 열쇠
    주소 = f"{바탕}/{오퍼레이션}?{urllib.parse.urlencode(붙임)}"
    부탁 = urllib.request.Request(주소, headers={"User-Agent": 받는이름})
    try:
        with urllib.request.urlopen(부탁, timeout=시간제한) as 답:
            글 = 답.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as 문제:
        raise 받지못함(f"KIPRIS 가 {문제.code} 를 돌려주었다 — {문제.reason}") from 문제
    except (urllib.error.URLError, TimeoutError, OSError) as 문제:
        raise 받지못함(f"KIPRIS 에 닿지 못했다 — {문제}") from 문제

    try:
        뿌리 = ElementTree.fromstring(글)
    except ElementTree.ParseError as 문제:
        raise 받지못함(f"KIPRIS 응답을 읽지 못했다 — {문제}") from 문제

    까닭 = _오류읽기(뿌리)
    if 까닭:
        raise 받지못함(까닭)
    return 뿌리


def _오류읽기(뿌리) -> str:
    """KIPRIS 는 200 으로 답하면서 본문에 오류를 싣는 때가 있다."""
    코드 = _첫글(뿌리, "resultCode", "returnReasonCode", "errorCode")
    말 = _첫글(뿌리, "resultMsg", "returnAuthMsg", "errMsg", "errorMessage")
    if 코드 and 코드 not in ("00", "0", "200"):
        return f"KIPRIS 오류 {코드}" + (f" — {말}" if 말 else "")
    if 말 and re.search(r"(ERROR|error|없|초과|만료|인증)", 말) and not 코드:
        return f"KIPRIS 오류 — {말}"
    return ""


def _첫글(뿌리, *이름들) -> str:
    for 이름 in 이름들:
        for 칸 in 뿌리.iter():
            if _막이름(칸.tag) == 이름.lower() and (칸.text or "").strip():
                return 칸.text.strip()
    return ""


def _막이름(태그: str) -> str:
    """이름공간을 떼고 소문자로 만든다."""
    return str(태그).rsplit("}", 1)[-1].lower()


def 청구항뽑기(뿌리) -> list:
    """이름에 claim 이 들어간 칸을 나온 차례대로 모은다.

    칸 이름이 개정될 수 있으므로 이름을 못박지 아니한다. 다만 청구항 「수」를
    담는 칸(claimCount 등)은 글이 아니므로 뺀다.
    """
    모은것 = []
    for 칸 in 뿌리.iter():
        이름 = _막이름(칸.tag)
        if "claim" not in 이름 or 이름 in 청구항아닌칸:
            continue
        글 = (칸.text or "").strip()
        if not 글 or 글.isdigit():
            continue
        글 = re.sub(r"[ \t]+", " ", 글).strip()
        if len(글) < 10:                      # 「1」·「청구항」 같은 토막은 글이 아니다
            continue
        if 글 not in 모은것:
            모은것.append(글)
    return 모은것


def 서지뽑기(뿌리) -> dict:
    return {
        "명칭": _첫글(뿌리, "inventionTitle", "title", "inventionName"),
        "출원인": _첫글(뿌리, "applicantName", "applicant", "assignee"),
        "발명자": _첫글(뿌리, "inventorName", "inventor"),
        "출원번호": _첫글(뿌리, "applicationNumber", "appNumber"),
        "출원일": _날짜(_첫글(뿌리, "applicationDate", "appDate")),
        "공개번호": _첫글(뿌리, "openNumber", "publicationNumber"),
        "공개일": _날짜(_첫글(뿌리, "openDate", "publicationDate")),
        "등록번호": _첫글(뿌리, "registerNumber", "registrationNumber"),
        "등록일": _날짜(_첫글(뿌리, "registerDate", "registrationDate")),
        "요약": _첫글(뿌리, "astrtCont", "abstract", "abstractInfo"),
        "법적상태": _첫글(뿌리, "registerStatus", "applicationStatus", "legalStatus"),
    }


def _날짜(글: str) -> str:
    숫자 = re.sub(r"\D", "", 글 or "")
    return f"{숫자[:4]}-{숫자[4:6]}-{숫자[6:8]}" if len(숫자) >= 8 else ""


def 갈무리읽기(자리: Path):
    """이미 받아 둔 응답이 있으면 그것을 쓴다.

    무료 한도가 달마다 1,000회다(확인 2026-08-26). 같은 문헌을 다시 물어보는 것은
    한도만 축내는 일이므로, 받아 둔 원본이 있으면 그것을 읽는다. 새로 받으려면
    덮어쓰기로 부른다.
    """
    자리 = Path(자리)
    if not 자리.exists():
        return None
    try:
        글 = 자리.read_text(encoding="utf-8")
        뿌리 = ElementTree.fromstring(글)
    except (OSError, ElementTree.ParseError):
        return None
    if _오류읽기(뿌리):
        return None                    # 오류를 담은 응답은 갈무리로 치지 아니한다
    return 뿌리


def 상세받기(출원번호: str, 열쇠: str, 터: str = "", 시간제한: int = 60,
        갈무리자리: Path | None = None, 다시받기: bool = False) -> dict:
    """출원번호 하나로 서지와 청구항을 받는다.

    돌려주는 것
      서지      명칭·출원인·출원일·공개일·등록일·요약·법적상태
      청구항들  나온 차례대로의 글 목록
      출처      어느 오퍼레이션에서 언제 받았는지 (보고서에 그대로 적는다)
    """
    번호 = 출원번호정리(출원번호)
    if not 쓸만한번호인가(번호):
        raise 받지못함(f"출원번호로 보이지 아니한다: {출원번호}")

    갈무리 = None if 다시받기 else (갈무리읽기(갈무리자리) if 갈무리자리 else None)
    if 갈무리 is not None:
        뿌리, 새로받음 = 갈무리, False
    else:
        뿌리 = 부르기(상세오퍼레이션, {"applicationNumber": 번호}, 열쇠, 터, 시간제한)
        새로받음 = True
        if 갈무리자리:
            원본저장(뿌리, 갈무리자리)

    청구항들 = 청구항뽑기(뿌리)
    답 = 서지뽑기(뿌리)
    답.update({
        "물어본번호": 번호,
        "청구항들": 청구항들,
        "청구항수": len(청구항들),
        "출처": f"KIPRIS Plus {상세오퍼레이션}",
        "받은때": 지금(),
        "새로받음": 새로받음,
        "원본": ElementTree.tostring(뿌리, encoding="unicode"),
    })
    return 답


def 원본저장(뿌리_또는_글, 자리: Path) -> Path:
    """받은 응답을 그대로 남긴다. 뒤에 다툼이 생기면 이것이 증거가 된다."""
    자리 = Path(자리)
    자리.parent.mkdir(parents=True, exist_ok=True)
    글 = (뿌리_또는_글 if isinstance(뿌리_또는_글, str)
         else ElementTree.tostring(뿌리_또는_글, encoding="unicode"))
    자리.write_text(글, encoding="utf-8")
    return 자리


# ── 열쇠를 어떻게 받는가 ────────────────────────────────────────
# 아래 절차와 값은 2026-08-26 에 각 출처를 열어 확인한 것이다. 값은 바뀔 수 있다.
시험번호 = "1020240176792"          # 공개된 문헌. 열쇠가 도는지만 본다

발급출처 = [
    ("KIPRIS Plus 가입 및 신청 안내",
     "https://plus.kipris.or.kr/portal/main/contents.do?menuNo=210104"),
    ("KIPRIS Plus 서비스 수수료",
     "https://plus.kipris.or.kr/portal/use/paymentMmg.do?menuNo=210112"),
    ("KIPRIS Plus 열린 API 목록",
     "https://plus.kipris.or.kr/portal/main/apiStatus.do?menuNo=210157"),
    ("공공데이터포털 — 특허실용신안 정보 검색 서비스",
     "https://www.data.go.kr/data/15058788/openapi.do"),
]


def 발급안내() -> str:
    """열쇠 받는 법. 킷 안에 넣어 두어 사람이 검색하지 아니하여도 되게 한다."""
    return "\n".join([
        "  ── KIPRIS 열쇠 받는 법 ──────────────────────────────",
        "",
        "  길이 둘이다. 어느 쪽 열쇠든 이 킷에 그대로 넣으면 된다.",
        "",
        "  [가] KIPRIS Plus — 특허청 정보원이 직접 내주는 열쇠",
        "    1. plus.kipris.or.kr 에서 회원 가입한다.",
        "       법인 계좌나 법인 카드로 결제하려면 「단체회원」으로 가입한다.",
        "    2. 위 메뉴의 「Open API」 에서 특허·실용 공개·등록 공보를 고른다.",
        "       청구항은 이 서비스의 getBibliographyDetailInfoSearch 에 들어 있다.",
        "    3. 장바구니에서 이용 조건과 할인 유형을 적어 신청한다.",
        "       관리자 승인이 나야 결제 단추가 열린다. 마이페이지에서 본다.",
        "    4. 마이페이지에서 견적서를 뽑아 계좌이체나 신용카드로 낸다.",
        "    5. 마이페이지 > APIKEY 관리에서 인증키를 확인한다. 그것이 열쇠다.",
        "",
        "    값 — 달마다 1,000회까지 무료이고, 매월 1일에 다시 채워진다.",
        "         넘겨 쓰면 하루 5,320원(연 1,941,800원)이다.",
        "         상품을 둘 이하로 신청하면 50%, 개인·중소중견기업·공공기관·",
        "         비영리 단체는 여기에 50% 를 더 깎는다.",
        "    문의 — 02-6915-1553 (평일 09:00~12:00, 13:00~18:00)",
        "",
        "  [나] 공공데이터포털 — 같은 자료를 무료로 여는 길",
        "    1. data.go.kr 에서 회원 가입한다.",
        "    2. 「특허실용신안 정보 검색 서비스」를 찾아 활용신청을 누른다.",
        "    3. 개발계정은 자동승인이라 신청과 동시에 열린다.",
        "       마이페이지 > 오픈API > 개발계정에서 일반 인증키를 복사한다.",
        "    4. 하루 1,000건까지 쓸 수 있다. 더 필요하면 운영계정으로 바꾼다.",
        "",
        "    ※ 포털 열쇠는 Encoding·Decoding 두 벌로 나온다. 이 킷은 값을 스스로",
        "      감싸므로 **Decoding 열쇠**를 넣는다. Encoding 열쇠를 넣어 %2B 가",
        "      두 번 감싸지면 인증이 되지 아니한다.",
        "",
        "  ── 받은 열쇠를 넣는 곳 ──────────────────────────────",
        "    · 메인보드 「설정」 탭의 「KIPRIS 서비스 열쇠」 칸 (권함)",
        "    · patent_config.json 의 prior_art.kipris_key",
        "    · 환경변수 KIPRIS_KEY",
        "",
        "    넣은 뒤 이렇게 시험한다 —  patentkit kipris",
        "",
        "  ── 출처 ────────────────────────────────────────────",
    ] + [f"    · {이름}\n      {주소}" for 이름, 주소 in 발급출처] + [
        f"    확인일 {확인일}",
    ])


def 실패풀이(까닭: str) -> str:
    """KIPRIS 가 돌려준 오류를 사람 말로 풀어 준다."""
    글 = (까닭 or "").upper()
    if "SERVICE KEY IS NOT REGISTERED" in 글 or "30" in 글[:40]:
        return ("  열쇠가 등록돼 있지 아니하다는 뜻이다.\n"
                "    · 신청한 서비스가 「특허·실용 공개·등록 공보」가 맞는지 본다.\n"
                "    · 공공데이터포털 열쇠라면 Decoding 열쇠를 넣었는지 본다.\n"
                "    · 신청 직후에는 반영에 몇 분 걸릴 수 있다.")
    if "LIMITED NUMBER" in 글 or "초과" in 까닭 or "22" in 글[:40]:
        return ("  이 달(또는 오늘) 쓸 수 있는 횟수를 다 썼다는 뜻이다.\n"
                "    · KIPRIS Plus 는 매월 1일에 다시 채워진다.\n"
                "    · 공공데이터포털 개발계정은 날마다 다시 채워진다.\n"
                "    · 받아 둔 원본이 _근거자료/KIPRIS원본/ 에 있으면 그것을 그대로 쓴다.")
    if "DEADLINE" in 글 or "만료" in 까닭:
        return "  열쇠 기한이 지났다. 마이페이지에서 연장하거나 다시 신청한다."
    if "닿지 못했다" in 까닭:
        return ("  망에 닿지 못했다.\n"
                "    · 사내망이 바깥으로 나가는 것을 막고 있는지 본다.\n"
                "    · plus.kipris.or.kr 을 브라우저로 열어 본다.")
    return ("  풀이가 준비되지 아니한 오류다. 위 문구를 그대로 두고\n"
            "  KIPRIS Plus 에 문의한다 — 02-6915-1553")


def 열쇠상태(설정본=None) -> dict:
    """열쇠가 있는지만 본다. 실제로 부르지는 아니한다(한도를 축내지 않는다)."""
    try:
        열쇠 = 열쇠찾기(설정본)
    except 열쇠없음:
        return {"있음": False, "어디서": "", "길이": 0}
    import os
    설정값 = ""
    if 설정본 is not None:
        설정값 = (설정본.값("prior_art", "kipris_key", 기본="") or "").strip()
    어디서 = "설정 파일" if 설정값 and not 설정값.startswith("★") else "환경변수 KIPRIS_KEY"
    return {"있음": True, "어디서": 어디서, "길이": len(열쇠)}
