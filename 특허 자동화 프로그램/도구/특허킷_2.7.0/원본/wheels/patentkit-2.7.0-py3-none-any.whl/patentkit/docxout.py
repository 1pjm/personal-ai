# -*- coding: utf-8 -*-
"""관청 제출용 DOCX 생성.

제출본 마크다운을 읽어 명세서 → 청구범위 → 요약서 순서의 문서를 만든다.
사람이 확정해야 하는 값(★)이 남아 있으면 만들지 않는다. 관청 서식에 그대로
인쇄되는 값이기 때문이다. 확인하고도 강행하려면 --force 를 준다.
"""
from __future__ import annotations

import re
from datetime import date
from pathlib import Path

from . import build, doc
from .util import 읽기

쪽나눔표제 = {"청구범위", "요약서"}


class 의존성없음(RuntimeError):
    pass


def _문서만들기(설정본):
    try:
        from docx import Document
    except ImportError as 오류내용:
        raise 의존성없음(
            "python-docx 가 없다. 다음을 실행한다:  pip install python-docx"
        ) from 오류내용
    본틀 = 설정본.값("style", "template_docx", 기본="") or ""
    if 본틀 and Path(본틀).exists():
        return Document(본틀)
    return Document()


def _글꼴맞추기(글자, 설정본, 크기=None, 굵게=False):
    from docx.shared import Pt
    from docx.oxml.ns import qn

    이름 = 설정본.값("style", "font_kr", 기본="바탕")
    글자.font.name = 이름
    글자._element.rPr.rFonts.set(qn("w:eastAsia"), 이름)
    글자.font.size = Pt(크기 or 설정본.값("style", "body_size", 기본=11))
    글자.bold = 굵게


def 만들기(폴더: Path, 설정본, 강행: bool = False, 표지: bool = False) -> Path:
    폴더 = Path(폴더)
    미확정 = 설정본.미확정값()
    if 미확정 and not 강행:
        자리들 = ", ".join(자리 for 자리, _ in 미확정)
        raise ValueError(
            f"사람이 확정해야 하는 값이 남아 관청 서식을 만들지 않는다: {자리들}\n"
            "값을 채우거나, 검토용이라면 --force 를 준다"
        )

    제출본경로 = 폴더 / 설정본.경로("submission_md", "03_제출본_명세서_청구범위.md")
    if not 제출본경로.exists():
        명세서 = 폴더 / 설정본.경로("spec_md", "01_명세서.md")
        청구 = 폴더 / 설정본.경로("claims_md", "02_청구범위.md")
        if not (명세서.exists() and 청구.exists()):
            raise FileNotFoundError("제출본도 명세서·청구범위도 없다")
        본문 = build.제출본만들기(읽기(명세서), 읽기(청구),
                              설정본.값("build", "internal_sections", 기본=["회피 논거"]))
    else:
        본문 = 읽기(제출본경로)

    문서 = _문서만들기(설정본)
    if 표지:
        _표지쓰기(문서, 설정본)

    from docx.enum.text import WD_ALIGN_PARAGRAPH

    크기표 = 설정본.값("style", "heading_sizes", 기본={}) or {}
    첫표제 = True
    for 줄 in 본문.splitlines():
        맞음 = doc.표제식.match(줄)
        if 맞음:
            수준, 이름 = len(맞음.group(1)), 맞음.group(2)
            if 이름 in 쪽나눔표제 and not 첫표제:
                문서.add_page_break()
            문단 = 문서.add_paragraph()
            글자 = 문단.add_run(f"【{이름}】")
            _글꼴맞추기(글자, 설정본, 크기표.get(str(수준), 12), 굵게=True)
            if 수준 <= 2:
                문단.alignment = WD_ALIGN_PARAGRAPH.CENTER
            첫표제 = False
            continue
        if not 줄.strip():
            continue
        문단 = 문서.add_paragraph()
        문단.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        글자 = 문단.add_run(_잔재정리(줄))
        _글꼴맞추기(글자, 설정본)

    출력폴더 = 설정본.출력폴더
    출력폴더.mkdir(parents=True, exist_ok=True)
    본새 = 설정본.값("output", "filename_pattern", 기본="임시명세서_{date}.docx")
    이름 = 본새.format(date=f"{date.today():%Y%m%d}",
                     title=(설정본.명칭[:20] or "명세서"))
    대상 = 출력폴더 / 이름
    문서.save(str(대상))
    return 대상


def _표지쓰기(문서, 설정본) -> None:
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    제목 = 문서.add_paragraph()
    제목.alignment = WD_ALIGN_PARAGRAPH.CENTER
    글자 = 제목.add_run(설정본.값("filing", "kind", 기본="특허출원") + " 표지")
    _글꼴맞추기(글자, 설정본, 16, 굵게=True)

    출원인 = ", ".join(사람.get("name", "") for 사람 in 설정본.값("applicants", 기본=[]))
    발명자 = ", ".join(사람.get("name", "") for 사람 in 설정본.값("inventors", 기본=[]))
    공개 = 설정본.값("filing", "disclosure_exception", 기본={}) or {}
    칸들 = [
        ("발명의 명칭", 설정본.명칭),
        ("출원인", 출원인),
        ("발명자", 발명자),
        ("IPC", ", ".join(설정본.값("ipc", 기본=[]))),
        ("출원 종류", 설정본.값("filing", "kind", 기본="")),
        ("수수료 감면", 설정본.값("filing", "fee_reduction", 기본="")),
        ("공지예외 주장", "예" if 공개.get("claimed") else "아니오"),
        ("공개일", 공개.get("date", "")),
        ("공지예외 기한", str(설정본.공지예외기한() or "")),
        ("작성일", str(date.today())),
    ]
    표 = 문서.add_table(rows=0, cols=2)
    본새 = 설정본.값("style", "table_style", 기본="")
    if 본새:
        try:
            표.style = 본새
        except KeyError:
            pass
    for 이름, 값 in 칸들:
        줄 = 표.add_row().cells
        for 칸, 글 in zip(줄, (이름, str(값))):
            칸.text = ""
            글자 = 칸.paragraphs[0].add_run(글)
            _글꼴맞추기(글자, 설정본)
    문서.add_page_break()


def _잔재정리(줄: str) -> str:
    """마크다운 흔적을 지운다. 검사에서 걸러지지만 서식에는 남기지 않는다."""
    줄 = re.sub(r"\*\*(.+?)\*\*", r"\1", 줄)
    줄 = re.sub(r"`([^`]+)`", r"\1", 줄)
    return 줄.strip()
