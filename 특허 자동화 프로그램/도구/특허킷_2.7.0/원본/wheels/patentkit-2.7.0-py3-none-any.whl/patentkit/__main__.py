# -*- coding: utf-8 -*-
import sys

from .cli import 실행

sys.exit(실행())
