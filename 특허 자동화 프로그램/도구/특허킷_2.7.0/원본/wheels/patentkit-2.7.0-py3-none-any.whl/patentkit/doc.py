# -*- coding: utf-8 -*-
"""명세서·청구범위 마크다운 해석기.

관청 표제는 「## 【명세서】」처럼 마크다운 표제 안에 【 】로 적는다.
단락 표지는 행 머리의 [0001] 만 표지로 보고, 행 가운데의 [0058] 은
다른 단락을 가리키는 인용으로 본다. 이 구별이 종전 킷의 오탐 원인이었다.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from .util import 읽기

표제식 = re.compile(r"^(#{1,6})\s*【\s*([^】]+?)\s*】\s*$")
단락표지식 = re.compile(r"^\[(\d{4})\]\s?")
인용식 = re.compile(r"\[(\d{4})\]")
청구항표제식 = re.compile(r"^#{1,6}\s*【\s*청구항\s*(\d+)\s*】\s*$")
도면인용식 = re.compile(r"(?<![가-힣A-Za-z0-9])도\s*(\d+)\s*(?![\d.])")
부호선언식 = re.compile(r"(S?\d{2,4})\s*(?:내지\s*(S?\d{2,4}))?\s*:")
부호사용식 = re.compile(r"\((S?\d{2,4})\)")
항인용식 = re.compile(r"제\s*(\d+)\s*항")


@dataclass
class 구간:
    """표제 하나와 그 아래 본문의 범위."""

    이름: str
    수준: int
    표제행: int          # 1부터 세는 행 번호
    시작: int            # 본문 시작 행 번호
    끝: int              # 본문 끝 행 번호(포함)

    def 본문(self, 행들: list) -> str:
        return "\n".join(행들[self.시작 - 1:self.끝])


@dataclass
class 청구항:
    번호: int
    표제행: int
    본문: str
    인용: list = field(default_factory=list)     # 인용한 항 번호
    다중종속: bool = False

    @property
    def 독립항(self) -> bool:
        return not self.인용

    @property
    def 말미범주(self) -> str:
        """「…, 지표 처리 장치.」의 마지막 쉼표 뒤 범주 명사를 뽑는다."""
        끝문장 = [줄.strip() for 줄 in self.본문.splitlines()
                if 줄.strip() and not re.fullmatch(r"[-*_]{3,}", 줄.strip())]
        if not 끝문장:
            return ""
        마지막 = 끝문장[-1].rstrip(".")
        return 마지막.rsplit(",", 1)[-1].strip() if "," in 마지막 else ""


@dataclass
class 문서:
    """명세서 또는 청구범위 마크다운 한 편."""

    경로: Path
    본문: str
    행들: list = field(default_factory=list)
    구간들: list = field(default_factory=list)
    단락들: list = field(default_factory=list)   # (번호, 행번호, 글)
    인용들: list = field(default_factory=list)   # (번호, 행번호) — 행 가운데 인용
    청구항들: list = field(default_factory=list)

    @property
    def 이름(self) -> str:
        return self.경로.name

    # ── 구간 찾기 ────────────────────────────────────────────────
    def 구간찾기(self, 이름: str):
        for 구 in self.구간들:
            if 구.이름 == 이름:
                return 구
        return None

    def 구간본문(self, 이름: str) -> str:
        구 = self.구간찾기(이름)
        return 구.본문(self.행들) if 구 else ""

    def 구간이름들(self) -> list:
        return [구.이름 for 구 in self.구간들]

    def 행이속한구간(self, 행번호: int) -> str:
        해당 = ""
        for 구 in self.구간들:
            if 구.표제행 <= 행번호 <= 구.끝:
                해당 = 구.이름
        return 해당

    def 최상위구간(self, 행번호: int) -> str:
        """행이 【명세서】·【청구범위】·【요약서】 중 어디에 속하는지."""
        해당 = ""
        for 구 in self.구간들:
            if 구.수준 <= 2 and 구.표제행 <= 행번호:
                해당 = 구.이름
        return 해당

    def 단락번호목록(self) -> list:
        return [번호 for 번호, _행, _글 in self.단락들]


def 읽어들이기(경로) -> 문서:
    경로 = Path(경로)
    본문 = 읽기(경로)
    문 = 문서(경로=경로, 본문=본문, 행들=본문.splitlines())
    _표제해석(문)
    _단락해석(문)
    _청구항해석(문)
    return 문


def _표제해석(문: 문서) -> None:
    자리 = []   # (표제행, 수준, 이름)
    for 번호, 줄 in enumerate(문.행들, 1):
        맞음 = 표제식.match(줄)
        if 맞음:
            자리.append((번호, len(맞음.group(1)), 맞음.group(2)))
    끝행 = len(문.행들)
    for i, (표제행, 수준, 이름) in enumerate(자리):
        끝 = 끝행
        for 표제행2, 수준2, _ in 자리[i + 1:]:
            if 수준2 <= 수준:
                끝 = 표제행2 - 1
                break
        else:
            끝 = 끝행
        # 바로 다음 표제까지를 본문으로 삼는다(하위 표제가 있으면 그 앞까지).
        본문끝 = 자리[i + 1][0] - 1 if i + 1 < len(자리) else 끝행
        문.구간들.append(구간(이름, 수준, 표제행, 표제행 + 1, min(끝, max(본문끝, 표제행))))


def _단락해석(문: 문서) -> None:
    for 번호, 줄 in enumerate(문.행들, 1):
        맞음 = 단락표지식.match(줄)
        if 맞음:
            문.단락들.append((int(맞음.group(1)), 번호, 줄[맞음.end():]))
            나머지 = 줄[맞음.end():]
            시작 = 맞음.end()
        else:
            나머지 = 줄
            시작 = 0
        for 인용 in 인용식.finditer(나머지):
            문.인용들.append((int(인용.group(1)), 번호))


def _청구항해석(문: 문서) -> None:
    자리 = []
    for 번호, 줄 in enumerate(문.행들, 1):
        맞음 = 청구항표제식.match(줄)
        if 맞음:
            자리.append((번호, int(맞음.group(1))))
    for i, (표제행, 항번호) in enumerate(자리):
        끝 = 자리[i + 1][0] - 1 if i + 1 < len(자리) else len(문.행들)
        # 청구범위 뒤에 다른 표제(요약서·회피 논거 등)가 오면 그 앞에서 끊는다.
        for 번호 in range(표제행 + 1, 끝 + 1):
            if re.match(r"^#{1,6}\s", 문.행들[번호 - 1]) and not 청구항표제식.match(문.행들[번호 - 1]):
                끝 = 번호 - 1
                break
        조각 = 문.행들[표제행:끝]
        while 조각 and (not 조각[-1].strip() or re.fullmatch(r"[-*_]{3,}", 조각[-1].strip())):
            조각.pop()
        글 = "\n".join(조각).strip()
        인용 = sorted({int(맞음.group(1)) for 맞음 in 항인용식.finditer(글)})
        다중 = ("내지" in 글 or "또는" in 글) and len(인용) >= 2
        문.청구항들.append(청구항(항번호, 표제행, 글, 인용, 다중))


def 명세서찾기(폴더: Path, 설정) -> Path | None:
    후보 = 폴더 / 설정.경로("spec_md", "01_명세서.md")
    return 후보 if 후보.exists() else None


def 청구범위찾기(폴더: Path, 설정) -> Path | None:
    후보 = 폴더 / 설정.경로("claims_md", "02_청구범위.md")
    return 후보 if 후보.exists() else None
