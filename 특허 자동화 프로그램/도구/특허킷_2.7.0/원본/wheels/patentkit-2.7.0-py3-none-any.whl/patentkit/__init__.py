# -*- coding: utf-8 -*-
"""특허 출원 자동화 킷.

윈도우 콘솔의 기본 코드페이지(cp949)에서는 「—」 같은 글자가 깨지므로,
꾸러미를 들일 때 표준 출력을 UTF-8 로 맞춘다. 이미 UTF-8 이면 아무것도 하지 않는다.
"""
import sys

__version__ = "2.7.0"


def _콘솔맞추기() -> None:
    for 스트림 in (sys.stdout, sys.stderr):
        인코딩 = (getattr(스트림, "encoding", "") or "").lower()
        if 인코딩.replace("-", "") == "utf8":
            continue
        try:
            스트림.reconfigure(encoding="utf-8")
        except Exception:
            pass


_콘솔맞추기()
