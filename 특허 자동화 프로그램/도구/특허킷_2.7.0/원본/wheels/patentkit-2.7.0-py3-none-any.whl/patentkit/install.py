# -*- coding: utf-8 -*-
"""이 컴퓨터에 설치하고 지운다.

관리자 권한을 쓰지 않는다. 모두 사용자 계정 안에서만 일어난다.
  프로그램  %LOCALAPPDATA%\\Programs\\PatentKit\\
  바로가기  바탕화면, 시작 메뉴
  PATH      사용자 PATH 에 프로그램 폴더를 더한다(창 어디서나 「특허킷」으로 부를 수 있다)
지울 때는 위 셋을 그대로 되돌린다. 출원건 자료에는 손대지 않는다.

설치 폴더 이름은 영문으로 둔다. 배치 파일과 PATH 가 한글 경로에서 코드페이지를
타는 일을 없애기 위한 것이며, 사람에게 보이는 이름은 모두 한글로 둔다.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

폴더이름 = "PatentKit"
표시이름 = "특허 자동화 킷"
부르는이름들 = ["특허킷", "patentkit"]      # 두 이름 다 만든다


def 언제나설치자리() -> Path:
    바탕 = os.environ.get("LOCALAPPDATA")
    if 바탕:
        return Path(바탕) / "Programs" / 폴더이름
    return Path.home() / ".local" / "share" / 폴더이름


def 굳힌실행파일() -> Path | None:
    """PyInstaller 로 구운 exe 로 돌고 있으면 그 경로."""
    return Path(sys.executable) if getattr(sys, "frozen", False) else None


def 설치됨() -> Path | None:
    자리 = 언제나설치자리()
    for 이름 in 부르는이름들:
        for 꼬리 in (".cmd", ".exe"):
            후보 = 자리 / f"{이름}{꼬리}"
            if 후보.exists():
                return 후보
    return None


def 파워셸(스크립트: str):
    return subprocess.run(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", 스크립트],
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0,
    )


def 바탕화면() -> Path:
    답 = 파워셸("[Environment]::GetFolderPath('Desktop')")
    자리 = Path(답.stdout.strip()) if 답.returncode == 0 and 답.stdout.strip() else Path.home() / "Desktop"
    return 자리 if 자리.exists() else Path.home()


def 시작메뉴() -> Path:
    답 = 파워셸("[Environment]::GetFolderPath('Programs')")
    if 답.returncode == 0 and 답.stdout.strip():
        return Path(답.stdout.strip())
    return (Path(os.environ.get("APPDATA", Path.home()))
            / "Microsoft" / "Windows" / "Start Menu" / "Programs")


def 아이콘놓기(대상폴더: Path) -> Path | None:
    """꾸러미가 들고 있는 아이콘을 설치 폴더에 둔다. 바로가기가 이 그림을 쓴다."""
    본디 = Path(__file__).resolve().parent / "자료" / "특허킷.ico"
    if not 본디.exists():
        return None
    대상 = 대상폴더 / "특허킷.ico"
    try:
        shutil.copy2(본디, 대상)
    except OSError:
        return None
    return 대상


def 바로가기만들기(자리: Path, 가리킬것: Path, 일할곳: Path, 설명: str,
                 아이콘: Path | None = None, 딸림: str = "") -> bool:
    자리.parent.mkdir(parents=True, exist_ok=True)
    그림 = f"{아이콘},0" if 아이콘 else f"{가리킬것},0"
    스크립트 = (
        f"$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{자리}');"
        f"$s.TargetPath='{가리킬것}';"
        + (f"$s.Arguments='{딸림}';" if 딸림 else "")
        + f"$s.WorkingDirectory='{일할곳}';"
        f"$s.Description='{설명}';"
        f"$s.IconLocation='{그림}';"
        "$s.Save()"
    )
    return 파워셸(스크립트).returncode == 0


def 길더하기(폴더: Path) -> str:
    """사용자 PATH 에 폴더를 더한다. 반환은 사람에게 보일 결과 문구."""
    스크립트 = (
        "$새='" + str(폴더) + "';"
        "$옛=[Environment]::GetEnvironmentVariable('PATH','User');"
        "if ([string]::IsNullOrEmpty($옛)) { $옛='' }"
        "$조각=$옛.Split(';') | Where-Object { $_ -ne '' };"
        "if ($조각 -contains $새) { 'exists' } else {"
        "  $합=(($조각 + $새) -join ';');"
        "  [Environment]::SetEnvironmentVariable('PATH',$합,'User'); 'added' }"
    )
    답 = 파워셸(스크립트)
    return {"added": "더했다", "exists": "이미 들어 있다"}.get(답.stdout.strip(), "잡지 못했다")


def 길빼기(폴더: Path) -> str:
    스크립트 = (
        "$뺄것='" + str(폴더) + "';"
        "$옛=[Environment]::GetEnvironmentVariable('PATH','User');"
        "if ([string]::IsNullOrEmpty($옛)) { 'empty' } else {"
        "  $조각=$옛.Split(';') | Where-Object { $_ -ne '' -and $_ -ne $뺄것 };"
        "  [Environment]::SetEnvironmentVariable('PATH',($조각 -join ';'),'User'); 'removed' }"
    )
    답 = 파워셸(스크립트).stdout.strip()
    return {"removed": "뺐다", "empty": "들어 있지 않았다"}.get(답, "지우지 못했다")


def 실행파일놓기(대상폴더: Path) -> list:
    """프로그램을 부르는 파일들을 설치 폴더에 놓는다. 첫 번째가 대표다.

    exe 로 돌고 있으면 그 exe 를 복사하고, 아니면 지금 쓰는 파이썬을 부르는 작은
    실행 파일(.cmd)을 만든다. 「특허킷」과 「patentkit」 두 이름 모두로 부를 수 있다.
    """
    대상폴더.mkdir(parents=True, exist_ok=True)
    구운것 = 굳힌실행파일()
    if 구운것:
        대상 = 대상폴더 / f"{부르는이름들[0]}.exe"
        if 구운것.resolve() != 대상.resolve():
            shutil.copy2(구운것, 대상)
        return [대상]

    꾸러미자리 = Path(__file__).resolve().parent.parent
    제대로설치됨 = 꾸러미자리.name == "site-packages"     # venv 안에 든 경우
    줄들 = ["@echo off", "chcp 65001 >nul"]
    if not 제대로설치됨:      # 소스 폴더에서 바로 쓸 때만 길을 잡아 준다
        줄들.append(f'set "PYTHONPATH={꾸러미자리}"')
    줄들.append(f'"{sys.executable}" -m patentkit %*')

    놓은것 = []
    for 이름 in 부르는이름들:
        대상 = 대상폴더 / f"{이름}.cmd"
        대상.write_text("\r\n".join(줄들) + "\r\n", encoding="utf-8", newline="")
        놓은것.append(대상)
    return 놓은것


def 설치(조용히: bool = False) -> int:
    자리 = 언제나설치자리()
    말 = (lambda 글: None) if 조용히 else print

    말(f"\n  {표시이름} 을 이 컴퓨터에 설치한다.")
    말(f"  놓을 곳 — {자리}")
    try:
        놓은것 = 실행파일놓기(자리)
    except OSError as 문제:
        말(f"  실패 — 파일을 놓지 못했다: {문제}")
        return 1
    본체 = 놓은것[0]
    말(f"  부르는 이름 — {' · '.join(자리.name for 자리 in 놓은것)}")

    일할곳 = 바탕화면()
    그림 = 아이콘놓기(자리)
    만든것 = []
    # 아이콘 셋을 만든다. 대부분은 「메인보드」 하나만 쓰면 된다.
    아이콘들 = [
        (f"{표시이름}.lnk", "", f"{표시이름} — 번호로 고르는 화면"),
        (f"{표시이름} 메인보드.lnk", "web",
         f"{표시이름} — 브라우저에서 전체를 다룬다 (이 PC 에서만 열린다)"),
        (f"{표시이름} 메인보드 (사내망 공유).lnk", "web --host lan",
         f"{표시이름} — 같은 사내망의 다른 PC 에서도 열린다. 시연용"),
    ]
    for 이름, 딸림, 설명 in 아이콘들:
        for 바탕 in (바탕화면(), 시작메뉴()):
            if 바로가기만들기(바탕 / 이름, 본체, 일할곳, 설명, 그림, 딸림):
                만든것.append(바탕 / 이름)
    for 어디 in 만든것:
        말(f"  바로가기 — {어디}")
    if not 만든것:
        말("  바로가기를 만들지 못했다. 설치 폴더에서 직접 실행해도 된다.")

    말(f"  PATH — {길더하기(자리)} (새 창부터 「{부르는이름들[0]}」 으로 부를 수 있다)")

    자취남기기(자리, 놓은것, 만든것)
    말("\n  설치를 마쳤다. 바탕화면의 「메인보드」 아이콘을 두 번 누르면")
    말("  브라우저가 열리고 거기서 전부 처리한다.")
    말("  다른 PC 에서도 보이려면 「메인보드 (사내망 공유)」 를 쓴다.")
    말(f"  지우려면 — {부르는이름들[0]} uninstall")
    return 0


def 자취남기기(자리: Path, 놓은것: list, 바로가기들: list) -> None:
    """무엇을 놓았는지 적어 둔다. 지울 때 이 파일을 본다."""
    적을것 = [str(어디) for 어디 in list(놓은것) + list(바로가기들)]
    (자리 / "설치자취.txt").write_text("\n".join(적을것) + "\n", encoding="utf-8")


def 제거(조용히: bool = False) -> int:
    자리 = 언제나설치자리()
    말 = (lambda 글: None) if 조용히 else print
    말(f"\n  {표시이름} 을 지운다. 출원건 자료에는 손대지 않는다.")

    자취 = 자리 / "설치자취.txt"
    지울것 = []
    if 자취.exists():
        지울것 = [Path(줄) for 줄 in 자취.read_text(encoding="utf-8").splitlines() if 줄.strip()]
    for 이름 in (f"{표시이름}.lnk", f"{표시이름} 메인보드.lnk",
              f"{표시이름} 메인보드 (사내망 공유).lnk"):
        지울것 += [바탕화면() / 이름, 시작메뉴() / 이름]

    for 어디 in 지울것:
        if 어디.suffix == ".lnk" and 어디.exists():
            try:
                어디.unlink()
                말(f"  지움 — {어디}")
            except OSError as 문제:
                말(f"  남음 — {어디} ({문제})")

    말(f"  PATH — {길빼기(자리)}")

    도는중 = 굳힌실행파일() or Path(sys.executable)
    if 자리 in 도는중.parents:
        말(f"  프로그램이 지금 이 폴더에서 돌고 있어 폴더는 남긴다: {자리}")
        말("  제거.bat 이 창을 닫은 뒤 이 폴더를 지운다.")
        return 0
    if 자리.exists():
        try:
            shutil.rmtree(자리)
            말(f"  지움 — {자리}")
        except OSError as 문제:
            말(f"  남음 — {자리} ({문제})")
    말("\n  제거를 마쳤다.")
    return 0
