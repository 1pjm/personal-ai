# -*- coding: utf-8 -*-
"""선행기술 조사 — KIPRIS 결과를 읽어 대비표와 경고를 만든다.

두 갈래로 쓴다.
  · 이미 받아 둔 결과 파일(JSON)을 읽어 보고서를 만든다. 열쇠가 없어도 된다.
  · patent_config.json 의 prior_art.kipris_key 가 있으면 직접 조회해 저장한다.

건별로 다음 셋을 판정한다. 셋 다 날짜와 출원인 이름만으로 정해지는 사실 판정이며,
신규성·진보성 판단이 아니다. 그 판단은 사람이 한다.
  자사 선출원   출원인이 우리 회사인 문헌
  확대된 선원   우리 출원일보다 먼저 출원됐고 그때까지 공개되지 아니한 문헌(특허법 제29조제3항)
  공개 선행     우리 출원일 이전에 공개된 문헌(제29조제1항)
"""
from __future__ import annotations

import json
import re
from datetime import date
from pathlib import Path

from . import sources
from .config import _날짜

칸이름 = ["pubnum", "appno", "title", "assignee", "app_date", "open_date",
        "pub_date", "reg_date", "disclosed_date", "snippet", "url"]

자사선출원 = "자사 선출원"
확대선원 = "확대된 선원 후보"
공개선행 = "공개 선행문헌"
이후출원 = "우리 출원 뒤"


class 문헌:
    """KIPRIS 검색 결과 한 건."""

    def __init__(self, 자료: dict, 질의: str = ""):
        self.자료 = 자료
        self.질의 = 질의

    def __getattr__(self, 이름):
        if 이름 in 칸이름:
            return self.자료.get(이름, "") or ""
        raise AttributeError(이름)

    @property
    def 출원일(self):
        return _날짜(self.app_date)

    @property
    def 공개일(self):
        """공개·공고·등록 가운데 가장 이른 날. 이 날부터 남에게 알려진 것으로 본다."""
        날들 = [_날짜(self.자료.get(칸, "")) for 칸 in
              ("open_date", "pub_date", "reg_date", "disclosed_date")]
        있는것 = [날 for 날 in 날들 if 날]
        return min(있는것) if 있는것 else None

    def 자사인가(self, 이름들) -> bool:
        상대 = _이름정리(self.assignee)
        return any(_이름정리(이름) and _이름정리(이름) in 상대 for 이름 in 이름들)

    def 지위(self, 우리출원일: date, 우리이름들) -> str:
        if self.자사인가(우리이름들):
            return 자사선출원
        출원 = self.출원일
        공개 = self.공개일
        if 공개 and 공개 <= 우리출원일:
            return 공개선행
        if 출원 and 출원 < 우리출원일:
            return 확대선원
        return 이후출원


def 결과읽기(경로: Path) -> list:
    """저장된 KIPRIS 결과 파일을 문헌 목록으로 편다.

    두 모양을 모두 받는다.
      {"질의": {"total": n, "hits": [...]}, ...}   검색 결과 모음
      [ {...}, ... ]                                문헌 목록 그대로
    """
    자료 = json.loads(Path(경로).read_text(encoding="utf-8-sig"))
    모은것 = []
    if isinstance(자료, list):
        모은것 = [문헌(한건, 경로.stem) for 한건 in 자료 if isinstance(한건, dict)]
    elif isinstance(자료, dict):
        for 질의, 값 in 자료.items():
            묶음 = 값.get("hits", []) if isinstance(값, dict) else 값
            if isinstance(묶음, list):
                모은것 += [문헌(한건, 질의) for 한건 in 묶음 if isinstance(한건, dict)]
    return 모은것


def 폴더목록(자리들) -> list:
    """하나를 줘도 되고 여럿을 줘도 된다. 있는 폴더만 남긴다."""
    if isinstance(자리들, (str, Path)):
        자리들 = [자리들]
    본것, 남길것 = set(), []
    for 자리 in 자리들:
        자리 = Path(자리)
        풀린것 = 자리.resolve() if 자리.exists() else 자리
        if 자리.exists() and 풀린것 not in 본것:
            본것.add(풀린것)
            남길것.append(자리)
    return 남길것


def 모아읽기(폴더들) -> list:
    """폴더 안의 KIPRIS 결과 파일을 모두 읽는다. 같은 문헌은 한 번만 센다.

    출원건 옆의 _원본자료와 프로젝트 전체의 _원본자료를 함께 볼 수 있게 여럿을 받는다.
    """
    본것, 모은것 = set(), []
    for 폴더 in 폴더목록(폴더들):
        for 파일 in sorted(Path(폴더).glob("*.json")):
            try:
                문헌들 = 결과읽기(파일)
            except (ValueError, OSError):
                continue                      # 우리 형식이 아닌 JSON 은 지나친다
            for 한건 in 문헌들:
                열쇠 = 한건.appno or 한건.pubnum or 한건.title
                if 열쇠 and 열쇠 not in 본것:
                    본것.add(열쇠)
                    모은것.append(한건)
    return 모은것


def 겹침점수(한건: 문헌, 낱말들) -> tuple:
    """우리 발명의 낱말이 문헌의 명칭·초록에 몇 개나 나오는지 센다.

    권리범위 판단이 아니라 사람이 먼저 읽을 문헌의 차례를 정하기 위한 값이다.
    """
    글 = f"{한건.title} {한건.snippet}"
    맞은것 = [낱말 for 낱말 in 낱말들 if 낱말 and 낱말 in 글]
    return len(맞은것), 맞은것


군더더기 = {
    "장치", "시스템", "방법", "서버", "단말", "매체", "기록매체", "기록한", "기록",
    "컴퓨터", "판독", "가능한", "판독가능", "판독가능한", "프로그램", "비휘발성",
    "그", "및", "이를", "위한", "따른", "관한", "하는", "되는", "대한", "저장",
}


def 우리낱말(설정본, 청구범위=None) -> list:
    """발명의 명칭과 독립항에서 조사에 쓸 낱말을 뽑는다.

    범주 명사(장치·방법·기록매체)처럼 어느 특허에나 있는 낱말은 뺀다.
    그런 낱말을 세면 관계없는 문헌이 위로 올라온다.
    """
    낱말 = set()
    for 조각 in re.split(r"[,·\s]+", 설정본.명칭 or ""):
        조각 = 조각.strip()
        if len(조각) >= 2 and 조각 not in 군더더기:
            낱말.add(조각)
    for 질의 in 설정본.값("prior_art", "queries", 기본=[]) or []:
        낱말.update(조각 for 조각 in 낱말쪼개기(질의) if 조각 not in 군더더기)
    if 청구범위:
        for 항 in 청구범위.청구항들:
            if 항.독립항:
                for 부 in re.findall(r"([가-힣]{2,}(?:부|기|표|값|코드))", 항.본문):
                    if 부 not in 군더더기:
                        낱말.add(부)
    return sorted(낱말)


def 낱말쪼개기(글: str) -> list:
    return [조각 for 조각 in re.split(r"[,·\s]+", 글 or "") if len(조각) >= 2]


def 조사(설정본, 자료폴더, 우리출원일: date | None = None,
        청구범위=None, 상위: int = 12) -> dict:
    """저장된 결과를 읽어 판정과 차례를 매긴다."""
    우리출원일 = 우리출원일 or date.today()
    우리이름들 = [사람.get("name", "") for 사람 in 설정본.값("applicants", 기본=[])]
    낱말들 = 우리낱말(설정본, 청구범위)

    본폴더 = 폴더목록(자료폴더)
    문헌들 = 모아읽기(본폴더)
    줄들 = []
    for 한건 in 문헌들:
        점수, 맞은것 = 겹침점수(한건, 낱말들)
        줄들.append({
            "문헌": 한건,
            "지위": 한건.지위(우리출원일, 우리이름들),
            "점수": 점수,
            "맞은낱말": 맞은것,
        })
    줄들.sort(key=lambda 줄: (-줄["점수"], 줄["문헌"].app_date), reverse=False)
    줄들.sort(key=lambda 줄: -줄["점수"])

    묶음 = {이름: [줄 for 줄 in 줄들 if 줄["지위"] == 이름]
          for 이름 in (자사선출원, 확대선원, 공개선행, 이후출원)}
    return {
        "우리출원일": 우리출원일,
        "낱말": 낱말들,
        "전체": 줄들,
        "묶음": 묶음,
        "상위": 줄들[:상위],
        "자료폴더": " · ".join(str(자리) for 자리 in 본폴더) or "(없음)",
        "문헌수": len(문헌들),
    }


def 보고서(결과: dict, 제목: str = "선행기술 조사") -> str:
    묶음 = 결과["묶음"]
    줄들 = [f"# {제목}", "",
           f"작성 {date.today()} · 문헌 {결과['문헌수']}건 · "
           f"기준 출원일 {결과['우리출원일']} · 자료 {결과['자료폴더']}", "",
           "○ 아래 판정은 출원인 이름과 날짜만으로 정해지는 사실 판정이다. "
           "신규성·진보성 판단이 아니며 변리사 검토를 대신하지 아니한다.", "",
           "---", "", "## 1. 판정별 건수", "",
           "| 판정 | 건수 | 뜻 |", "| --- | --- | --- |",
           f"| {자사선출원} | {len(묶음[자사선출원])} | 출원인이 우리 회사인 문헌 |",
           f"| {확대선원} | {len(묶음[확대선원])} | 우리 출원일 전에 출원됐고 그때까지 공개되지 아니한 문헌(제29조제3항) |",
           f"| {공개선행} | {len(묶음[공개선행])} | 우리 출원일 전에 공개된 문헌(제29조제1항) |",
           f"| {이후출원} | {len(묶음[이후출원])} | 우리 출원일 뒤에 출원된 문헌. 선행기술이 아니다 |",
           ""]

    줄들 += ["---", "", "## 2. 먼저 읽을 문헌", "",
            "○ 낱말 겹침은 우리 명칭·독립항의 낱말이 문헌의 명칭·초록에 몇 개나 나오는지 센 값이다. "
            "읽을 차례를 정하는 데에만 쓴다.", "",
            "| 겹침 | 판정 | 출원번호 | 명칭 | 출원인 | 출원일 | 공개일 |",
            "| --- | --- | --- | --- | --- | --- | --- |"]
    for 줄 in 결과["상위"]:
        한건 = 줄["문헌"]
        줄들.append(
            f"| {줄['점수']} | {줄['지위']} | {한건.appno or '-'} | "
            f"{_자르기(한건.title, 60)} | {_자르기(한건.assignee, 24)} | "
            f"{한건.app_date or '-'} | {한건.공개일 or '-'} |")
    줄들.append("")

    for 이름 in (자사선출원, 확대선원):
        묶인것 = 묶음[이름]
        줄들 += ["---", "", f"## 3. {이름}" if 이름 == 자사선출원 else f"## 4. {이름}", ""]
        if not 묶인것:
            줄들 += [f"○ 해당 문헌이 없다.", ""]
            continue
        if 이름 == 확대선원:
            줄들 += ["○ 확대된 선원은 청구항이 아니라 **명세서 전문**과 대비한다. "
                    "아래 문헌은 전문을 확보해 대비표를 만들어야 한다.", "",
                    "○ 발명자가 같거나 출원 시의 출원인이 같으면 확대된 선원을 적용하지 "
                    "아니한다(특허법 제29조제3항 단서). 위 자사 선출원 목록과 겹치는지 "
                    "함께 본다.", ""]
        줄들 += ["| 출원번호 | 명칭 | 출원인 | 출원일 | 공개일 | 겹침 낱말 |",
                "| --- | --- | --- | --- | --- | --- |"]
        for 줄 in 묶인것[:20]:
            한건 = 줄["문헌"]
            줄들.append(
                f"| {한건.appno or '-'} | {_자르기(한건.title, 50)} | "
                f"{_자르기(한건.assignee, 20)} | {한건.app_date or '-'} | "
                f"{한건.공개일 or '-'} | {', '.join(줄['맞은낱말'][:5]) or '-'} |")
        줄들.append("")

    줄들 += ["---", "", "## 5. 사람이 해야 하는 일", "",
            "○ 위 문헌 가운데 먼저 읽을 것을 정해 **청구항 전문**을 확보하고 구성 대비표를 만든다.",
            "○ 확대된 선원 후보는 **명세서 전문**을 확보한다. 청구항만으로는 대비가 성립하지 아니한다.",
            "○ 자사 선출원과 겹치는 한정은 신규 출원의 독립항에서 뺀다.",
            "○ 조사 범위의 한계(질의어·국가·건수)를 보고서에 남긴다.", "",
            "---", ""]
    줄들.append(sources.출처묶음(["신규성", "확대선원", "확대선원배제"]))
    return "\n".join(줄들)


def 조회(설정본, 질의: str, 최대: int = 10) -> dict:
    """KIPRIS 에 직접 물어본다. 열쇠가 없으면 뜻을 알려 주고 멈춘다.

    터와 열쇠 찾기·오류 읽기는 kipris 꾸러미 한 곳에 모아 두었다. 예전에는 이
    함수가 낡은 터(http://…/openapi/rest/…)를 따로 들고 있어 개정 뒤에 닿지
    못했다. 고칠 곳을 둘로 나누어 둔 것이 화근이었다.
    """
    from . import kipris

    열쇠 = kipris.열쇠찾기(설정본)
    터 = 설정본.값("prior_art", "kipris_endpoint", 기본="") or \
        설정본.값("prior_art", "endpoint", 기본="") or ""
    뿌리 = kipris.부르기("getWordSearch",
                     {"word": 질의, "numOfRows": 최대, "pageNo": 1}, 열쇠, 터)
    묶음 = []
    for 항목 in 뿌리.iter("item"):
        묶음.append({
            "pubnum": _글(항목, "publicationNumber", "openNumber"),
            "appno": _글(항목, "applicationNumber"),
            "title": _글(항목, "inventionTitle", "title"),
            "assignee": _글(항목, "applicantName", "assignee"),
            "app_date": _날짜글(_글(항목, "applicationDate")),
            "open_date": _날짜글(_글(항목, "openDate")),
            "pub_date": _날짜글(_글(항목, "publicationDate")),
            "reg_date": _날짜글(_글(항목, "registerDate")),
            "disclosed_date": "",
            "snippet": _글(항목, "astrtCont", "abstract"),
            "url": _글(항목, "url"),
        })
    return {"total": len(묶음), "err": None, "hits": 묶음}


def 조회모음(설정본, 저장할곳: Path, 최대: int = 10) -> Path:
    """config 의 질의어를 모두 조회해 한 파일로 저장한다."""
    질의들 = 설정본.값("prior_art", "queries", 기본=[]) or []
    if not 질의들:
        raise RuntimeError("patent_config.json 의 prior_art.queries 가 비어 있다.")
    모은것 = {}
    for 질의 in 질의들:
        모은것[질의] = 조회(설정본, 질의, 최대)
    저장할곳 = Path(저장할곳)
    저장할곳.parent.mkdir(parents=True, exist_ok=True)
    저장할곳.write_text(json.dumps(모은것, ensure_ascii=False, indent=1), encoding="utf-8")
    return 저장할곳


def _글(항목, *이름들) -> str:
    for 이름 in 이름들:
        칸 = 항목.find(이름)
        if 칸 is not None and (칸.text or "").strip():
            return 칸.text.strip()
    return ""


def _날짜글(글: str) -> str:
    글 = re.sub(r"\D", "", 글 or "")
    return f"{글[:4]}-{글[4:6]}-{글[6:8]}" if len(글) >= 8 else ""


def _이름정리(이름: str) -> str:
    return re.sub(r"[\s()（）주식회사㈜(주)]", "", 이름 or "")


def _자르기(글: str, 길이: int) -> str:
    글 = (글 or "").replace("|", "\\|").strip()
    return 글 if len(글) <= 길이 else 글[:길이 - 1] + "…"


def 조사결과(자리: Path, 설정본, 청구범위=None):
    """선행기술 조사 자료가 있으면 그 결과를 돌려준다. 없으면 None."""
    자료폴더 = [Path(자리) / "_원본자료", Path(자리).parent / "_원본자료"]
    if not 모아읽기(자료폴더):
        return None
    return 조사(설정본, 자료폴더, None, 청구범위)
