# -*- coding: utf-8 -*-
"""명령줄 진입점.

명세서를 쓰는 일           init · validate · build · renumber
관청에 낼 것을 만드는 일    draw · figures · docx
조사하고 뒷받침하는 일      prior-art · compare · evidence · trace
여러 건을 살피는 일         web · status · report · menu
프로그램을 다루는 일        install · uninstall · doctor · selftest

  patentkit                                      번호로 고르는 화면
  patentkit init 출원건_05_새발명 --title "…"   출원건 폴더 만들기
  patentkit validate [폴더]                      검사
  patentkit build [폴더]                         제출본 생성
  patentkit renumber [폴더]                      단락번호 다시 매기기
  patentkit docx [폴더] --cover                  관청 서식(DOCX) 생성
  patentkit figures [폴더]                       도면 SVG → PNG
  patentkit prior-art [폴더]                     선행기술 판정과 보고서
  patentkit evidence [폴더] <주소…>              공개 증거 수집
  patentkit trace [폴더] --source <제품소스>     청구항·소스 대조
  patentkit compare [폴더]                       인용문헌 대비표(청구항·전문)
  patentkit web [루트]                           웹 메인보드(브라우저)
  patentkit draw [폴더]                          도면 초안 만들기
  patentkit report [루트]                        변리사 검토 초안·종합보고서
  patentkit status [루트]                        여러 출원건 한눈에
  patentkit doctor                               실행 환경 점검
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from . import build as 제출본
from . import compare, config, doc, docxout, dossier, evidence, figures, install, prior_art
from . import candidates, drawings, renumber, report, rules, scaffold, sources, trace
from . import 보기자료
from . import web as 메인보드
from .util import 콘솔준비, 쓰기


def 출원건인가(폴더: Path) -> bool:
    폴더 = Path(폴더)
    return (폴더 / "patent_config.json").exists() or (폴더 / "01_명세서.md").exists()


def 출원건모으기(루트: Path) -> list:
    """루트 자체가 출원건이면 그것만, 아니면 바로 아래 출원건 폴더를 모은다."""
    루트 = Path(루트)
    if 출원건인가(루트):
        return [루트]
    하위 = sorted(자리 for 자리 in 루트.iterdir()
                 if 자리.is_dir() and 출원건인가(자리))
    return 하위


def 명령_init(인자) -> int:
    대상 = Path(인자.폴더)
    만든것 = scaffold.만들기(대상, 인자.title or "", 인자.force)
    print(f"출원건 폴더를 만들었다: {대상}")
    for 자리 in 만든것[1:]:
        print(f"  {Path(자리).relative_to(대상.parent)}")
    print("\n다음 순서로 진행한다.")
    print("  1. patent_config.json 의 ★ 값을 채운다")
    print("  2. 01_명세서.md · 02_청구범위.md 의 ★ 자리를 채운다")
    print(f"  3. patentkit validate \"{대상}\"")
    return 0


def 명령_validate(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.폴더))
    if not 폴더들:
        print(f"출원건 폴더를 찾지 못했다: {인자.폴더}")
        return 2
    결과들 = []
    for 폴더 in 폴더들:
        설정본 = config.불러오기(폴더)
        결과 = rules.검사(폴더, 설정본)
        결과들.append(결과)
        if not 인자.json:
            report.콘솔출력(결과, 인자.verbose)

    if 인자.json:
        print(json.dumps([결과.사전() for 결과 in 결과들], ensure_ascii=False, indent=2))
    elif len(결과들) > 1:
        print("\n" + report.일람표(결과들))

    if 인자.out:
        쓰기(Path(인자.out), report.마크다운보고서(결과들))
        print(f"\n보고서를 썼다: {인자.out}")

    오류합 = sum(결과.오류수 for 결과 in 결과들)
    경고합 = sum(결과.경고수 for 결과 in 결과들)
    if 오류합:
        return 1
    return 3 if (경고합 and 인자.strict) else 0


def 명령_build(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.폴더))
    for 폴더 in 폴더들:
        설정본 = config.불러오기(폴더)
        print(f"■ {폴더.name}")
        try:
            _대상, _변동, _메시지 = 제출본.실행(폴더, 설정본)
        except (FileNotFoundError, ValueError) as 문제:
            print(f"  실패 — {문제}")
            return 1
    return 0


def 명령_renumber(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.폴더))
    for 폴더 in 폴더들:
        설정본 = config.불러오기(폴더)
        명세서경로 = doc.명세서찾기(폴더, 설정본)
        if 명세서경로 is None:
            print(f"■ {폴더.name} — 명세서가 없다")
            continue
        결과 = renumber.다시매기기(명세서경로, 인자.dry_run)
        표시 = "미리보기" if 인자.dry_run else "적용"
        print(f"■ {폴더.name} — 단락 {결과['총단락']}개 중 {결과['바뀐수']}개 번호 변경 ({표시})")
        for 옛, 새 in 결과["대응표"].items():
            if 옛 != 새:
                print(f"    [{옛:04d}] → [{새:04d}]")
        for 옛 in 결과["모호번호"]:
            print(f"    [{옛:04d}] 이 두 번 이상 있어 이 번호를 가리키는 본문 인용은 "
                  "그대로 두었다. 직접 확인한다")
        if 결과["매핑파일"]:
            print(f"    대응표 {Path(결과['매핑파일']).name} · 원본 백업 완료")
        if not 인자.dry_run and 결과["변동"]:
            print("    제출본을 다시 만들려면 build 명령을 실행한다")
    return 0


def 명령_docx(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.폴더))
    실패 = 0
    for 폴더 in 폴더들:
        설정본 = config.불러오기(폴더)
        print(f"■ {폴더.name}")
        if not 인자.force:
            결과 = rules.검사(폴더, 설정본, 빠르게=True)
            if 결과.오류수:
                print(f"  차단 — 검사 오류 {결과.오류수}건. validate 로 확인한다")
                실패 = 1
                continue
        try:
            대상 = docxout.만들기(폴더, 설정본, 인자.force, 인자.cover)
            print(f"  생성 — {대상}")
        except (ValueError, FileNotFoundError, docxout.의존성없음) as 문제:
            print(f"  실패 — {문제}")
            실패 = 1
    return 실패


def 명령_figures(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.폴더))
    실패 = 0
    for 폴더 in 폴더들:
        설정본 = config.불러오기(폴더)
        도면폴더 = 폴더 / (설정본.경로("drawings_dir", "도면") or "도면")
        print(f"■ {폴더.name}")
        try:
            for 이름, 폭, 높이, 바이트 in figures.렌더(도면폴더, 인자.scale):
                if 폭 == 0:
                    print(f"  건너뜀 — {이름} · {바이트}")
                    실패 = 1
                    continue
                print(f"  렌더 — {이름} {폭}x{높이} @{인자.scale}x {바이트 / 1024:.1f}KB")
        except FileNotFoundError as 문제:
            print(f"  건너뜀 — {문제}")        # 그릴 도면이 없는 것은 실패가 아니다
        except RuntimeError as 문제:
            print(f"  실패 — {문제}")
            실패 = 1
    return 실패


def 명령_status(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.루트))
    if not 폴더들:
        print(f"출원건 폴더를 찾지 못했다: {인자.루트}")
        return 2
    결과들 = [rules.검사(폴더, config.불러오기(폴더)) for 폴더 in 폴더들]
    print()
    print(report.일람표(결과들))
    print()
    for 결과 in 결과들:
        기한 = 결과.수치.get("공지예외기한") or 결과.수치.get("우선일마감")
        if 기한:
            print(f"  {결과.대상} — 기한 {기한}")
    if 인자.out:
        쓰기(Path(인자.out), report.마크다운보고서(결과들))
        print(f"\n보고서를 썼다: {인자.out}")
    return 1 if any(결과.오류수 for 결과 in 결과들) else 0


def 명령_doctor(_인자) -> int:
    굳힌것 = install.굳힌실행파일()
    site여부 = Path(__file__).resolve().parent.parent.name == "site-packages"
    방식 = "실행 파일" if 굳힌것 else ("설치본" if site여부 else "소스 폴더에서 바로 실행")
    print(f"특허 자동화 킷 {__version__}")
    print(f"  실행 방식 — {방식}")
    print(f"  파이썬 — {sys.version.split()[0]} ({sys.executable})")
    놓인곳 = install.설치됨()
    print(f"  설치 — {놓인곳.parent if 놓인곳 else '설치돼 있지 않다. install 명령으로 설치한다'}")

    print("\n기능별 준비 상태")
    print("  됨     검사 · 제출본 생성 · 단락번호 — 추가 설치 없이 동작한다")
    try:
        import docx  # noqa: F401
        print("  됨     관청 서식(DOCX) 생성")
    except ImportError:
        print("  안 됨  관청 서식(DOCX) 생성 — pip install python-docx")
    try:
        import pypdf  # noqa: F401
        print("  됨     인용문헌 PDF 에서 글자 뽑기")
    except ImportError:
        print("  안 됨  인용문헌 PDF 에서 글자 뽑기 — pip install pypdf (txt 로 두면 그대로 읽는다)")
    그리기 = figures.렌더러이름()
    if 그리기:
        print(f"  됨     도면 SVG → PNG — {그리기}")
    else:
        print("  안 됨  도면 SVG → PNG — 엣지나 크롬이 있으면 바로 된다")

    from . import kipris
    설정본 = None
    for 자리 in 출원건모으기(Path(".")) or []:
        try:
            설정본 = config.불러오기(자리)
            break
        except Exception:
            pass
    상태 = kipris.열쇠상태(설정본)
    if 상태["있음"]:
        print(f"  됨     KIPRIS 청구항 받아오기 — 열쇠 {상태['길이']}자 ({상태['어디서']})")
        print("         실제로 도는지는  patentkit kipris  로 시험한다")
    else:
        print("  안 됨  KIPRIS 청구항 받아오기 — 열쇠가 없다")
        print("         받는 방법은  patentkit kipris  가 알려 준다")
    return 0


def 자료폴더고르기(폴더: Path, 인자) -> list:
    """조사 자료가 있는 곳. 출원건 옆과 프로젝트 전체를 함께 본다."""
    if getattr(인자, "자료", None):
        return [Path(인자.자료)]
    return [폴더 / "_원본자료", 폴더.parent / "_원본자료"]


def 명령_prior_art(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.폴더))
    if not 폴더들:
        print(f"출원건 폴더를 찾지 못했다: {인자.폴더}")
        return 2
    실패 = 0
    for 폴더 in 폴더들:
        설정본 = config.불러오기(폴더)
        자료 = 자료폴더고르기(폴더, 인자)
        print(f"■ {폴더.name}")

        if 인자.fetch:
            try:
                저장 = prior_art.조회모음(
                    설정본, 자료[0] / f"선행기술_KIPRIS_{폴더.name}.json", 인자.max)
                print(f"  조회 — {저장}")
            except (RuntimeError, OSError) as 문제:
                print(f"  조회 못 함 — {문제}")
                실패 = 1

        청구경로 = doc.청구범위찾기(폴더, 설정본)
        청구범위 = doc.읽어들이기(청구경로) if 청구경로 else None
        출원일 = config._날짜(인자.date) if 인자.date else None
        결과 = prior_art.조사(설정본, 자료, 출원일, 청구범위)
        if not 결과["문헌수"]:
            print(f"  읽을 결과 파일이 없다 — {자료}")
            print("  KIPRIS 결과 JSON 을 그 폴더에 두거나 --fetch 로 직접 조회한다.")
            실패 = 1
            continue
        print(f"  문헌 {결과['문헌수']}건 · 자사 선출원 {len(결과['묶음'][prior_art.자사선출원])}건 · "
              f"확대선원 후보 {len(결과['묶음'][prior_art.확대선원])}건")
        for 줄 in 결과["상위"][:5]:
            print(f"    겹침{줄['점수']} {줄['지위']} — {줄['문헌'].title[:44]}")
        대상 = Path(인자.out) if 인자.out else 폴더 / "_근거자료" / "선행기술조사.md"
        쓰기(대상, prior_art.보고서(결과, f"선행기술 조사 — {폴더.name}"))
        print(f"  보고서 — {대상}")
    return 실패


def 명령_evidence(인자) -> int:
    폴더 = Path(인자.폴더)
    설정본 = config.불러오기(폴더)
    대상 = Path(인자.out) if 인자.out else 보기자료.증거폴더찾기(폴더)
    if 인자.주소:
        print(f"■ 공개 증거를 받는다 — {len(인자.주소)}곳")
        for 기록 in evidence.수집(인자.주소, 대상):
            상태 = 기록["상태"] or "받지 못함"
            뒤 = 기록["문제"] or f"{기록['크기']:,}B · 접근통제 {기록['접근통제']}"
            print(f"  {상태}  {기록['주소']}  {뒤}")
    기록들 = evidence.대장읽기(대상)
    if not 기록들:
        print(f"  받아 둔 기록이 없다 — {대상}")
        print("  주소를 붙여 실행한다. 보기: patentkit evidence . https://example.com")
        return 2
    보고 = Path(인자.report) if 인자.report else 대상.parent / "공개이력대장.md"
    쓰기(보고, evidence.대장보고서(대상, 설정본))
    print(f"  대장 — {보고} (기록 {len(기록들)}건)")
    return 0


def 명령_trace(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.폴더))
    if not 폴더들:
        print(f"출원건 폴더를 찾지 못했다: {인자.폴더}")
        return 2
    실패 = 0
    for 폴더 in 폴더들:
        설정본 = config.불러오기(폴더)
        print(f"■ {폴더.name}")
        if 인자.init:
            청구경로 = doc.청구범위찾기(폴더, 설정본) or doc.명세서찾기(폴더, 설정본)
            문 = doc.읽어들이기(청구경로) if 청구경로 else None
            if not (문 and 문.청구항들):
                print("  청구항을 찾지 못해 뼈대를 만들지 못했다.")
                실패 = 1
                continue
            print(f"  대조표 뼈대 — {trace.뼈대만들기(폴더, 문.청구항들)}")
            print("  ★ 자리에 제품 소스의 파일과 행을 적은 뒤 --update 로 지문을 남긴다.")
            continue

        if 인자.source:
            소스길 = Path(인자.source)
            소스뿌리 = 소스길 if 소스길.is_absolute() else (폴더 / 소스길)
        else:
            소스뿌리 = trace.소스뿌리찾기(폴더, 설정본) or 폴더
        if not 소스뿌리.exists():
            print(f"  제품 소스 폴더가 없다 — {소스뿌리}")
            print("  --source 로 알려 주거나 patent_config.json 의 trace.source_root 에 적는다.")
            실패 = 1
            continue
        결과 = trace.검증(폴더, 소스뿌리, 인자.update)
        if not 결과["줄"]:
            print(f"  대조표가 없다 — {결과['대조표']}")
            print("  --init 으로 뼈대를 만든다.")
            실패 = 1
            continue
        for 이름, 수 in 결과["셈"].items():
            print(f"  {이름} {수}건")
        대상 = Path(인자.out) if 인자.out else 폴더 / "_근거자료" / "구현대조.md"
        쓰기(대상, trace.보고서(결과, 폴더.name))
        print(f"  보고서 — {대상}")
        나쁜것 = sum(수 for 이름, 수 in 결과["셈"].items() if 이름 != trace.확인됨)
        if 나쁜것:
            실패 = 1
    return 실패


def 명령_compare(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.폴더))
    if not 폴더들:
        print(f"출원건 폴더를 찾지 못했다: {인자.폴더}")
        return 2
    실패 = 0
    for 폴더 in 폴더들:
        설정본 = config.불러오기(폴더)
        print(f"■ {폴더.name}")
        if 인자.init:
            청구경로 = doc.청구범위찾기(폴더, 설정본) or doc.명세서찾기(폴더, 설정본)
            조사 = prior_art.조사결과(폴더, 설정본,
                                  doc.읽어들이기(청구경로) if 청구경로 else None)
            print(f"  문헌 목록 — {compare.뼈대만들기(폴더, 조사)}")
            if 조사:
                print(f"  선행기술 조사에서 {len(compare.목록읽기(폴더))}건을 옮겨 적었다. "
                      "상대 청구항 전문만 붙인다.")
            else:
                print("  ★ 자리에 문헌 번호·서지와 청구항 전문(또는 전문 파일)을 적는다.")
            continue

        if 인자.fetch_claims:
            from . import kipris
            try:
                받은것 = compare.청구항받아오기(폴더, 설정본, 덮어쓰기=인자.refetch)
            except kipris.열쇠없음 as 문제:
                print(f"  {문제}")
                실패 = 1
                continue
            except FileNotFoundError:
                print("  대비문헌 목록이 없다. --init 으로 먼저 만든다.")
                실패 = 1
                continue
            if not 받은것:
                print("  받아 올 문헌이 없다. 이미 채워졌거나 출원번호가 아닌 문헌뿐이다.")
            for 번호, 상태, 말 in 받은것:
                print(f"  {상태} — {번호}: {말}")
                if 상태 == "못받음":
                    실패 = 1

        문헌들 = compare.목록읽기(폴더)
        if not 문헌들:
            print(f"  대비할 문헌 목록이 없다 — {compare.목록경로(폴더)}")
            print("  --init 으로 목록을 만든다.")
            실패 = 1
            continue

        청구경로 = doc.청구범위찾기(폴더, 설정본) or doc.명세서찾기(폴더, 설정본)
        청구범위 = doc.읽어들이기(청구경로) if 청구경로 else None
        독립항들 = [항 for 항 in (청구범위.청구항들 if 청구범위 else []) if 항.독립항]
        if not 독립항들:
            print("  독립항을 찾지 못했다.")
            실패 = 1
            continue

        뿌리들 = [폴더, 폴더 / "_근거자료", 폴더 / "_원본자료", 폴더.parent,
                폴더.parent / "_원본자료"]
        청구대비, 전문모음 = [], {}
        for 문헌 in 문헌들:
            이름 = (문헌.get("번호") or "이름 없음").lstrip("★")
            try:
                상대청구, 상대전문 = compare.문헌글(문헌, 뿌리들)
            except (RuntimeError, FileNotFoundError) as 문제:
                print(f"  {이름} — 읽지 못했다: {문제}")
                실패 = 1
                continue
            if 상대청구:
                결과 = compare.청구항대비(독립항들[0], 상대청구)
                청구대비.append({
                    "번호": 이름, "서지": 문헌.get("서지", ""),
                    "청구항출처": 문헌.get("청구항출처", ""),
                    "청구항받은때": 문헌.get("청구항받은때", ""),
                    "줄": 결과["줄"], "대조못함": 결과["대조못함"],
                })
            elif 문헌.get("종류") != "확대선원":
                청구대비.append({"번호": 이름, "서지": 문헌.get("서지", ""), "줄": []})
            if 상대전문:
                전문모음[이름] = 상대전문

        if 청구대비:
            대상 = 폴더 / "_근거자료" / "선행문헌_청구항대비.md"
            쓰기(대상, compare.보고서_청구항(청구대비, 폴더.name))
            대조한것 = [한건 for 한건 in 청구대비 if 한건["줄"] and not 한건.get("대조못함")]
            못한것 = [한건 for 한건 in 청구대비 if 한건.get("대조못함")]
            대응없는수 = sum(1 for 한건 in 대조한것 for 줄 in 한건["줄"] if not 줄["대응있음"])
            말 = f"  청구항 대비 {len(청구대비)}건 · 대응 없음 축 {대응없는수}개"
            if 못한것:
                말 += f" · 언어가 달라 대조 못 한 문헌 {len(못한것)}건"
            print(말 + f" — {대상}")
        if 전문모음:
            묶음 = compare.용어그룹풀기(설정본.값("compare", "terms", 기본=[]))
            if not 묶음:
                묶음 = compare.용어자동뽑기(청구범위)
                print(f"  대조 용어를 독립항에서 뽑았다 — {len(묶음)}묶음 "
                      "(patent_config.json 의 compare.terms 로 바꿀 수 있다)")
            대조 = compare.전문대조(묶음, 전문모음)
            대상 = 폴더 / "_근거자료" / "확대선원_전문대비.md"
            쓰기(대상, compare.보고서_전문(대조, 폴더.name))
            나온것 = sum(1 for 칸 in 대조["표"]
                       if any(정보["셈"] for 정보 in 칸["문헌별"].values()))
            print(f"  전문 대조 {len(전문모음)}건 · 기재 확인된 용어 {나온것}묶음 — {대상}")
        if not 청구대비 and not 전문모음:
            print("  읽을 청구항도 전문도 없다. 대비문헌.json 을 채운다.")
            실패 = 1
    return 실패


def 명령_report(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.루트))
    if not 폴더들:
        print(f"출원건 폴더를 찾지 못했다: {인자.루트}")
        return 2
    모음들 = []
    for 폴더 in 폴더들:
        모은것 = dossier.모으기(폴더, config.불러오기(폴더))
        모음들.append(모은것)
        대상 = 폴더 / "_근거자료" / "04_변리사_검토사항_초안.md"
        쓰기(대상, dossier.건별초안(모은것))
        검사 = 모은것["검사"]
        print(f"■ {폴더.name} — 오류 {검사.오류수} · 경고 {검사.경고수}")
        print(f"  검토 초안 — {대상}")

    뿌리 = Path(인자.루트)
    대상 = Path(인자.out) if 인자.out else (
        (뿌리 if 뿌리.is_dir() and not 출원건인가(뿌리) else 뿌리.parent) / "00_종합보고서.md")
    쓰기(대상, dossier.프로젝트보고서(모음들))
    print(f"\n종합보고서 — {대상}")
    return 1 if any(모은것["검사"].오류수 for 모은것 in 모음들) else 0


def 명령_web(인자) -> int:
    try:
        return 메인보드.띄우기(Path(인자.폴더), 인자.port, not 인자.no_open,
                          어디=인자.host)
    except OSError as 문제:
        print(f"서버를 띄우지 못했다 — {문제}")
        print("  주소가 이 PC 의 것이 맞는지 본다. 사내망에 열려면 --host lan 을 준다.")
        return 2
    except RuntimeError as 문제:
        print(f"{문제}")
        return 2


def 명령_draw(인자) -> int:
    폴더들 = 출원건모으기(Path(인자.폴더))
    실패 = 0
    for 폴더 in 폴더들:
        설정본 = config.불러오기(폴더)
        print(f"■ {폴더.name}")
        try:
            for 이름, 상태 in drawings.만들기(폴더, 설정본, 인자.force):
                print(f"  {이름} — {상태}")
        except (FileNotFoundError, ValueError) as 문제:
            print(f"  실패 — {문제}")
            실패 = 1
    print("\n  초안이다. 관청에 낼 도면은 사람이 보고 다듬는다.")
    print("  PNG 로 바꾸려면 figures 명령을 실행한다.")
    return 실패


def 명령_sources(_인자) -> int:
    print()
    print(sources.전체표())
    return 0


def 명령_candidates(인자) -> int:
    뿌리 = Path(인자.폴더).resolve()
    if 인자.fill:
        더한것 = candidates.출원건에서채우기(뿌리)
        for 한건 in 더한것:
            print(f"  올림 — {한건['코드']} · {한건['이름'][:50]}")
        if not 더한것:
            print("  새로 올릴 출원건이 없다")
    if 인자.grade:
        코드, _, 등급 = 인자.grade.partition("=")
        한건 = candidates.고치기(뿌리, 코드.strip(), {
            "등급": 등급.strip(),
            "등급근거": 인자.reason or "",
            "판단자": 인자.by or "",
        })
        print(f"  {한건['코드']} → {한건['등급']} ({한건['판단자'] or '판단자 미기재'} "
              f"{한건['판단일']})")

    후보들 = candidates.읽기(뿌리)
    사실 = {한건.get("코드"): candidates.근거모으기(뿌리, 한건) for 한건 in 후보들}
    대상 = 뿌리 / "발명후보_원장.md"
    쓰기(대상, candidates.원장보고서(뿌리, 후보들, 사실))
    print()
    print(f"  후보 {len(후보들)}건 · 원장 {대상.name}")
    for 한건 in 후보들:
        근거 = 사실.get(한건.get("코드"), {})
        print(f"    [{한건.get('등급', '보류'):>2}] {한건.get('코드')} — "
              f"청구항 {근거.get('청구항수', 0)} · 선행문헌 {근거.get('선행문헌수', 0)} · "
              f"자사 저촉 {근거.get('자사저촉후보', 0)} · 남은 일 {len(근거.get('빠진것', []))}")
    return 0


def 명령_ir(인자) -> int:
    from . import ir as 포트폴리오

    결과 = 포트폴리오.만들기(Path(인자.루트).resolve())
    if not 결과["건수"]:
        print("출원건을 찾지 못했다.")
        return 2
    print(f"  건별 등록성 분석 {결과['건수']}건 · 포트폴리오 {결과['포트폴리오'].name}")
    print(f"  브라우저로 연다 — {결과['포트폴리오']}")
    return 0


def 명령_kipris(인자) -> int:
    """KIPRIS 열쇠를 시험하고, 없으면 어떻게 받는지 알려 준다."""
    from . import kipris

    폴더 = Path(인자.폴더)
    설정본 = None
    for 자리 in 출원건모으기(폴더) or [폴더]:
        try:
            설정본 = config.불러오기(자리)
            break
        except Exception:                       # 설정이 없어도 환경변수로 갈 수 있다
            continue

    print()
    try:
        열쇠 = kipris.열쇠찾기(설정본)
    except kipris.열쇠없음 as 문제:
        print(f"  {문제}")
        print()
        print(kipris.발급안내())
        return 2

    가림 = 열쇠[:4] + "…" + 열쇠[-4:] if len(열쇠) > 10 else "(짧다)"
    print(f"  열쇠 — {가림} ({len(열쇠)}자)")
    번호 = 인자.number or kipris.시험번호
    print(f"  물어본다 — {kipris.상세오퍼레이션} · 출원번호 {번호}")
    터 = ""
    if 설정본 is not None:
        터 = 설정본.값("prior_art", "kipris_endpoint", 기본="") or ""
    try:
        받은것 = kipris.상세받기(번호, 열쇠, 터, 다시받기=True)
    except kipris.받지못함 as 문제:
        print(f"  실패 — {문제}")
        print()
        print(kipris.실패풀이(str(문제)))
        return 1

    print()
    print(f"  됐다. 명칭 — {받은것['명칭'] or '(없음)'}")
    print(f"        출원인 — {받은것['출원인'] or '(없음)'}")
    print(f"        출원일 — {받은것['출원일'] or '(없음)'} · 공개일 {받은것['공개일'] or '-'}")
    print(f"        청구항 — {받은것['청구항수']}개")
    if 받은것["청구항들"]:
        첫항 = 받은것["청구항들"][0]
        print(f"        청구항 1 — {첫항[:70]}{'…' if len(첫항) > 70 else ''}")
    else:
        print("        이 문헌은 응답에 청구항 글이 없다. 다른 번호로 다시 시험해 본다.")
    print()
    print("  이제 「compare --fetch-claims」 나 메인보드의 "
          "「KIPRIS 에서 상대 청구항 받아오기」 가 돈다.")
    return 0


def 명령_install(_인자) -> int:
    return install.설치()


def 명령_uninstall(_인자) -> int:
    return install.제거()


def 명령_menu(인자) -> int:
    from . import menu
    return menu.실행(Path(getattr(인자, "폴더", ".")))


def 명령_selftest(_인자) -> int:
    from . import selftest
    print("자체 시험을 시작한다. 임시 폴더에 시험용 출원건을 만들어 검사한다.\n")
    return selftest.실행()


def 짜기() -> argparse.ArgumentParser:
    상위 = argparse.ArgumentParser(
        prog="patentkit", description="특허 출원 자동화 킷 — 검사·제출본·서식 생성",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    상위.add_argument("--version", action="version",
                     version=f"특허 자동화 킷 {__version__}")
    하위 = 상위.add_subparsers(dest="명령")

    개시 = 하위.add_parser("init", help="출원건 폴더와 뼈대 파일을 만든다")
    개시.add_argument("폴더")
    개시.add_argument("--title", help="발명의 명칭")
    개시.add_argument("--force", action="store_true", help="이미 있는 파일도 덮어쓴다")
    개시.set_defaults(함수=명령_init)

    검사 = 하위.add_parser("validate", help="명세서·청구범위·설정을 검사한다")
    검사.add_argument("폴더", nargs="?", default=".")
    검사.add_argument("--json", action="store_true", help="결과를 JSON 으로 낸다")
    검사.add_argument("--out", help="마크다운 보고서를 쓸 경로")
    검사.add_argument("--verbose", "-v", action="store_true", help="안내까지 모두 보인다")
    검사.add_argument("--strict", action="store_true", help="경고도 실패로 친다")
    검사.set_defaults(함수=명령_validate)

    제출 = 하위.add_parser("build", help="명세서와 청구범위를 합쳐 제출본을 만든다")
    제출.add_argument("폴더", nargs="?", default=".")
    제출.set_defaults(함수=명령_build)

    번호 = 하위.add_parser("renumber", help="단락번호를 1번부터 다시 매긴다")
    번호.add_argument("폴더", nargs="?", default=".")
    번호.add_argument("--dry-run", action="store_true", help="바꾸지 않고 결과만 보인다")
    번호.set_defaults(함수=명령_renumber)

    서식 = 하위.add_parser("docx", help="관청 제출용 DOCX 를 만든다")
    서식.add_argument("폴더", nargs="?", default=".")
    서식.add_argument("--cover", action="store_true", help="표지 쪽을 붙인다")
    서식.add_argument("--force", action="store_true", help="검사 오류와 ★ 값을 무시한다")
    서식.set_defaults(함수=명령_docx)

    도면 = 하위.add_parser("figures", help="도면 SVG 를 PNG 로 렌더한다")
    도면.add_argument("폴더", nargs="?", default=".")
    도면.add_argument("--scale", type=int, default=2, help="해상도 배율 (기본 2)")
    도면.set_defaults(함수=명령_figures)

    상태 = 하위.add_parser("status", help="여러 출원건의 상태를 한 표로 본다")
    상태.add_argument("루트", nargs="?", default=".")
    상태.add_argument("--out", help="마크다운 보고서를 쓸 경로")
    상태.set_defaults(함수=명령_status)

    점검 = 하위.add_parser("doctor", help="실행 환경과 선택 의존성을 점검한다")
    점검.set_defaults(함수=명령_doctor)

    자체 = 하위.add_parser("selftest", help="킷이 제대로 도는지 스스로 확인한다")
    자체.set_defaults(함수=명령_selftest)

    고름 = 하위.add_parser("menu", help="번호로 고르는 화면을 띄운다(인자 없이 실행해도 같다)")
    고름.add_argument("폴더", nargs="?", default=".")
    고름.set_defaults(함수=명령_menu)

    조사 = 하위.add_parser("prior-art", help="선행기술 결과를 읽어 판정과 보고서를 만든다")
    조사.add_argument("폴더", nargs="?", default=".")
    조사.add_argument("--자료", "--data", dest="자료", help="KIPRIS 결과 JSON 이 있는 폴더")
    조사.add_argument("--fetch", action="store_true", help="KIPRIS 에 직접 조회한다(열쇠 필요)")
    조사.add_argument("--max", type=int, default=10, help="조회 시 질의당 최대 건수")
    조사.add_argument("--date", help="기준 출원일(YYYY-MM-DD). 기본은 오늘")
    조사.add_argument("--out", help="보고서를 쓸 경로")
    조사.set_defaults(함수=명령_prior_art)

    증거 = 하위.add_parser("evidence", help="공개 증거를 받아 두고 공개이력 대장을 만든다")
    증거.add_argument("폴더", nargs="?", default=".")
    증거.add_argument("주소", nargs="*", help="받아 둘 주소들")
    증거.add_argument("--out", help="증거를 저장할 폴더")
    증거.add_argument("--report", help="대장을 쓸 경로")
    증거.set_defaults(함수=명령_evidence)

    대조 = 하위.add_parser("trace", help="청구항 구성이 제품 소스에 있는지 대조한다")
    대조.add_argument("폴더", nargs="?", default=".")
    대조.add_argument("--source", help="제품 소스 뿌리 폴더")
    대조.add_argument("--init", action="store_true", help="대조표 뼈대를 만든다")
    대조.add_argument("--update", action="store_true", help="지금 소스로 지문을 새로 남긴다")
    대조.add_argument("--out", help="보고서를 쓸 경로")
    대조.set_defaults(함수=명령_trace)

    대비 = 하위.add_parser("compare", help="인용문헌 청구항 대비표와 전문 용어 대조표를 만든다")
    대비.add_argument("폴더", nargs="?", default=".")
    대비.add_argument("--init", action="store_true", help="대비할 문헌 목록의 뼈대를 만든다")
    대비.add_argument("--fetch-claims", dest="fetch_claims", action="store_true",
                    help="빈 「청구항」 칸을 KIPRIS 에서 받아 채운다 (열쇠가 있어야 한다)")
    대비.add_argument("--refetch", action="store_true",
                    help="이미 채워진 청구항도 다시 받는다")
    대비.set_defaults(함수=명령_compare)

    엮기 = 하위.add_parser("report", help="변리사 검토 초안과 프로젝트 종합보고서를 만든다")
    엮기.add_argument("루트", nargs="?", default=".")
    엮기.add_argument("--out", help="종합보고서를 쓸 경로")
    엮기.set_defaults(함수=명령_report)

    보드 = 하위.add_parser("web", help="웹 메인보드를 띄운다(브라우저에서 전체를 다룬다)")
    보드.add_argument("폴더", nargs="?", default=".")
    보드.add_argument("--port", type=int, default=0, help="포트 번호. 기본은 빈 자리를 찾는다")
    보드.add_argument("--no-open", action="store_true", help="브라우저를 자동으로 열지 않는다")
    보드.add_argument("--host", default="", metavar="어디",
                    help="붙을 자리. 기본은 이 PC 뿐(127.0.0.1). "
                         "「lan」 을 주면 같은 사내망의 다른 PC 에서도 열린다. "
                         "주소를 직접 줘도 된다")
    보드.set_defaults(함수=명령_web)

    그림 = 하위.add_parser("draw", help="명세서에서 도면 초안(SVG)을 만든다")
    그림.add_argument("폴더", nargs="?", default=".")
    그림.add_argument("--force", action="store_true", help="이미 있는 도면도 덮어쓴다")
    그림.set_defaults(함수=명령_draw)

    근거 = 하위.add_parser("sources", help="킷이 근거로 삼는 법령과 규정의 출처를 보인다")
    근거.set_defaults(함수=명령_sources)

    원장 = 하위.add_parser("candidates", help="발명 후보 원장을 보이고 사람이 매긴 등급을 남긴다")
    원장.add_argument("폴더", nargs="?", default=".")
    원장.add_argument("--fill", action="store_true",
                    help="이미 있는 출원건 폴더를 후보로 올린다")
    원장.add_argument("--grade", metavar="코드=등급",
                    help="사람이 매긴 등급을 남긴다 (A·B·C·D·보류)")
    원장.add_argument("--reason", default="", help="그렇게 본 까닭")
    원장.add_argument("--by", default="", help="판단자 이름")
    원장.set_defaults(함수=명령_candidates)

    포트 = 하위.add_parser("ir", help="IR 포트폴리오와 건별 등록성 분석을 만든다")
    포트.add_argument("루트", nargs="?", default=".")
    포트.set_defaults(함수=명령_ir)

    열쇠 = 하위.add_parser("kipris", help="KIPRIS 열쇠를 시험한다. 없으면 받는 방법을 알려 준다")
    열쇠.add_argument("폴더", nargs="?", default=".")
    열쇠.add_argument("--number", default="", metavar="출원번호",
                    help="시험할 출원번호. 기본은 공개된 본보기 문헌")
    열쇠.set_defaults(함수=명령_kipris)

    놓기 = 하위.add_parser("install", help="이 컴퓨터에 설치한다(바탕화면 아이콘·PATH)")
    놓기.set_defaults(함수=명령_install)

    지우기 = 하위.add_parser("uninstall", help="이 컴퓨터에서 지운다")
    지우기.set_defaults(함수=명령_uninstall)
    return 상위


def 실행(인자들=None) -> int:
    콘솔준비()
    인자 = 짜기().parse_args(인자들)
    if getattr(인자, "함수", None) is None:      # 인자 없이 부르면 고르는 화면을 띄운다
        from . import menu
        return menu.실행(Path.cwd())
    return 인자.함수(인자)


main = 실행        # pip 로 설치했을 때 쓰는 ASCII 이름


if __name__ == "__main__":
    sys.exit(실행())
