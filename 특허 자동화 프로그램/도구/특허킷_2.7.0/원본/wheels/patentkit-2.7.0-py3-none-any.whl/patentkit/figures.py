# -*- coding: utf-8 -*-
"""도면 처리 — SVG 를 제출용 PNG 로 렌더한다.

도면은 흑백 선화로 그리고 명세서 【부호의 설명】의 부호를 그대로 쓴다.
렌더러는 다음 차례로 찾는다.

  1. playwright(크로미움) — 설치돼 있으면 쓴다. 여백까지 가장 정확하다.
  2. 엣지 또는 크롬 — 윈도우에 이미 깔려 있으므로 추가 설치가 필요 없다.
  3. cairosvg — 위 둘이 없을 때.

셋 다 브라우저 엔진이거나 그에 준하므로 한글 글꼴이 그대로 나온다.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

배율기본 = 2

브라우저후보 = [
    r"%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe",
    r"%ProgramFiles%\Microsoft\Edge\Application\msedge.exe",
    r"%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe",
    r"%ProgramFiles%\Google\Chrome\Application\chrome.exe",
    r"%LocalAppData%\Google\Chrome\Application\chrome.exe",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
]


def 성한가(그림: str):
    """SVG 가 XML 로 성한지 본다. 성하면 (True, ""), 아니면 (False, 까닭).

    브라우저는 깨진 SVG 를 만나면 그림 대신 붉은 오류 안내 쪽을 그린다. 그것을
    그대로 PNG 로 저장하면 관청에 오류 화면이 도면으로 들어간다. 그러므로 그리기
    전에 먼저 본다. 흔한 까닭은 글 안의 「<」 를 &lt; 로 바꾸지 아니한 것이다.
    """
    import xml.etree.ElementTree as XML

    try:
        XML.fromstring(그림)
        return True, ""
    except XML.ParseError as 문제:
        return False, str(문제)


def 렌더(도면폴더, 배율: int = 배율기본) -> list:
    """폴더 안의 *.svg 를 같은 이름의 *.png 로 만든다.

    반환 [(파일이름, 폭, 높이, 바이트수)]
    깨진 SVG 는 그리지 아니하고 (파일이름, 0, 0, 까닭) 으로 알린다.
    """
    도면폴더 = Path(도면폴더)
    파일들 = sorted(도면폴더.glob("*.svg"))
    if not 파일들:
        raise FileNotFoundError(f"SVG 파일이 없다: {도면폴더}")

    이름, 렌더러 = 렌더러고르기()
    결과 = []
    for 파일 in 파일들:
        그림 = 파일.read_text(encoding="utf-8")
        성함, 까닭 = 성한가(그림)
        if not 성함:
            결과.append((파일.name, 0, 0, f"XML 이 깨졌다 — {까닭}"))
            continue
        대상 = 파일.with_suffix(".png")
        폭, 높이 = 크기재기(그림)
        렌더러(파일, 대상, 폭, 높이, 배율)
        if not 대상.exists():
            raise RuntimeError(f"{이름} 이 그림을 만들지 못했다: {파일.name}")
        결과.append((대상.name, 폭, 높이, 대상.stat().st_size))
    return 결과


def 렌더러이름() -> str:
    """지금 쓸 수 있는 렌더러 이름. 없으면 빈 문자열."""
    try:
        return 렌더러고르기()[0]
    except RuntimeError:
        return ""


def 렌더러고르기():
    try:
        import playwright.sync_api  # noqa: F401
        return "playwright", _플레이라이트
    except ImportError:
        pass
    길 = 브라우저찾기()
    if 길:
        return f"브라우저({Path(길).stem})", _브라우저
    try:
        import cairosvg  # noqa: F401
        return "cairosvg", _케이로
    except ImportError:
        pass
    raise RuntimeError(
        "SVG 를 그릴 수단을 찾지 못했다. 셋 중 하나면 된다.\n"
        "  · 마이크로소프트 엣지 또는 구글 크롬 설치 (추가 설치가 가장 적다)\n"
        "  · pip install playwright  뒤에  playwright install chromium\n"
        "  · pip install cairosvg"
    )


def 브라우저찾기() -> str:
    """엣지나 크롬의 실행 파일 경로. 없으면 빈 문자열."""
    for 후보 in 브라우저후보:
        길 = os.path.expandvars(후보)
        if "%" not in 길 and Path(길).exists():
            return 길
    return ""


def _브라우저(원본: Path, 대상: Path, 폭: int, 높이: int, 배율: int) -> None:
    """엣지·크롬 헤드리스로 화면을 찍는다. 윈도우에는 대개 이미 깔려 있다."""
    실행기 = 브라우저찾기()
    if 대상.exists():
        대상.unlink()
    # 브라우저는 상대 경로를 제 작업 폴더에서 찾는다. 반드시 절대 경로로 준다.
    대상 = 대상.resolve()
    명령 = [
        실행기,
        "--headless=new",
        "--disable-gpu",
        "--hide-scrollbars",
        "--no-sandbox",
        "--disable-extensions",
        "--default-background-color=FFFFFFFF",
        f"--force-device-scale-factor={배율}",
        f"--window-size={폭},{높이}",
        f"--screenshot={대상}",
        원본.resolve().as_uri(),
    ]
    # CREATE_NO_WINDOW 는 주지 않는다. msedge 는 GUI 프로그램이라 콘솔 창이 애초에
    # 없고, 이 플래그를 주면 헤드리스 렌더가 소리 없이 빈손으로 끝나는 일이 있었다.
    끝난것 = subprocess.run(명령, capture_output=True, text=True, timeout=180,
                          encoding="utf-8", errors="replace")   # 브라우저가 한글을 뱉는다
    if not 대상.exists():
        까닭 = (끝난것.stderr or 끝난것.stdout or "").strip().splitlines()
        if not 까닭 and 끝난것.returncode == 0:
            # 아무 말 없이 빈손으로 끝났다 — 이미 떠 있는 브라우저가 실행을 가로챈
            # 모양새다(엣지 「시작 부스트」가 켜져 있으면 그렇게 된다).
            raise RuntimeError(
                "브라우저가 그림을 만들지 아니하고 바로 끝났다. 엣지가 이미 떠 있으면 "
                "이런 일이 있다. 엣지 창을 모두 닫고(설정 > 시스템 > 시작 부스트 끄기) "
                "다시 누르거나, 이미 만들어 둔 PNG 가 있으면 그대로 쓴다")
        raise RuntimeError("브라우저 렌더 실패 — " + (까닭[-1] if 까닭 else "까닭 미상"))


def _플레이라이트(원본: Path, 대상: Path, 폭: int, 높이: int, 배율: int) -> None:
    from playwright.sync_api import sync_playwright

    그림 = 원본.read_text(encoding="utf-8")
    with sync_playwright() as 무대:
        브라우저 = 무대.chromium.launch()
        쪽 = 브라우저.new_page(viewport={"width": 폭, "height": 높이},
                             device_scale_factor=배율)
        쪽.set_content(f"<html><body style='margin:0;background:#fff'>{그림}</body></html>")
        쪽.screenshot(path=str(대상))
        브라우저.close()


def _케이로(원본: Path, 대상: Path, 폭: int, 높이: int, 배율: int) -> None:
    import cairosvg

    cairosvg.svg2png(url=str(원본), write_to=str(대상),
                     output_width=폭 * 배율, output_height=높이 * 배율,
                     background_color="white")


def 크기재기(그림: str) -> tuple:
    폭 = re.search(r'width="(\d+)', 그림)
    높이 = re.search(r'height="(\d+)', 그림)
    if 폭 and 높이:
        return int(폭.group(1)), int(높이.group(1))
    보기 = re.search(r'viewBox="[\d.\s]*?([\d.]+)\s+([\d.]+)"', 그림)
    if 보기:
        return int(float(보기.group(1))), int(float(보기.group(2)))
    return 800, 600


def _창숨김() -> int:
    """윈도우에서 검은 창이 깜빡이지 않게 한다."""
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if sys.platform == "win32" else 0
