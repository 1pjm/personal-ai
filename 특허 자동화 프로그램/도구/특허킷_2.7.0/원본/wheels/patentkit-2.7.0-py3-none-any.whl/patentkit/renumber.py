# -*- coding: utf-8 -*-
"""단락번호 다시 매기기.

단락을 끼워 넣거나 지우면 [0001] 이후가 어긋난다. 이 도구는 행 머리의 표지를
1번부터 다시 매기고, 본문 가운데에서 다른 단락을 가리키는 인용도 같은 표로 고친다.
바꾸기 전 원본은 _작업이력 폴더에 남기고, 옛 번호와 새 번호의 대응표를 파일로 남긴다.
"""
from __future__ import annotations

import json
import re
from datetime import date
from pathlib import Path

from . import doc
from .util import 백업, 쓰기, 읽기


def 다시매기기(명세서경로: Path, 미리보기: bool = False) -> dict:
    """반환 {바뀐수, 대응표, 백업, 매핑파일}"""
    명세서경로 = Path(명세서경로)
    문 = doc.읽어들이기(명세서경로)

    # 청구범위·요약서 구역의 표지는 손대지 않는다. 그쪽은 검사에서 따로 지적한다.
    대상단락 = [(번호, 행) for 번호, 행, _ in 문.단락들
               if 문.최상위구간(행) not in ("청구범위", "요약서")]

    # 옛 번호가 두 번 이상 나오면 그 번호를 가리키는 인용이 어느 쪽인지 정할 수 없다.
    # 그런 번호는 대응표에서 빼고 인용을 그대로 둔 뒤, 호출측에 알린다.
    센것 = {}
    for 옛번호, _행 in 대상단락:
        센것[옛번호] = 센것.get(옛번호, 0) + 1
    중복번호 = {옛번호 for 옛번호, 수 in 센것.items() if 수 > 1}

    대응, 차례별 = {}, []
    for 차례, (옛번호, _행) in enumerate(대상단락, 1):
        차례별.append(차례)
        if 옛번호 not in 중복번호:
            대응[옛번호] = 차례

    바뀐수 = sum(1 for 차례, (옛번호, _행) in enumerate(대상단락, 1) if 옛번호 != 차례)

    새행들, 다음차례 = [], iter(차례별)
    for 번호, 줄 in enumerate(문.행들, 1):
        머리 = doc.단락표지식.match(줄)
        if 머리 and 문.최상위구간(번호) not in ("청구범위", "요약서"):
            새 = next(다음차례)
            줄 = f"[{새:04d}] " + _인용바꾸기(줄[머리.end():], 대응)
        else:
            줄 = _인용바꾸기(줄, 대응)
        새행들.append(줄)

    새본문 = "\n".join(새행들)
    if 문.본문.endswith("\n"):
        새본문 += "\n"

    결과 = {"바뀐수": 바뀐수, "대응표": 대응, "총단락": len(대상단락),
            "모호번호": sorted(중복번호), "백업": None, "매핑파일": None, "변동": False}
    if 미리보기 or 새본문 == 문.본문:
        return 결과

    결과["백업"] = str(백업(명세서경로, "단락번호") or "")
    결과["변동"] = 쓰기(명세서경로, 새본문)

    이력 = 명세서경로.parent / "_작업이력"
    이력.mkdir(exist_ok=True)
    매핑파일 = 이력 / f"_단락번호_매핑_{date.today():%Y%m%d}.json"
    매핑파일.write_text(json.dumps(
        {"작성": str(date.today()), "대상": 명세서경로.name,
         "대응표": {f"[{옛:04d}]": f"[{새:04d}]" for 옛, 새 in 대응.items() if 옛 != 새}},
        ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    결과["매핑파일"] = str(매핑파일)
    return 결과


def _인용바꾸기(글: str, 대응: dict) -> str:
    def 치환(맞음):
        옛 = int(맞음.group(1))
        새 = 대응.get(옛)
        return f"[{새:04d}]" if 새 else 맞음.group(0)

    return re.sub(r"\[(\d{4})\]", 치환, 글)
