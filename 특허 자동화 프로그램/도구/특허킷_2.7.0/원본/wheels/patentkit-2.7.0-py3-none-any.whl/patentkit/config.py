# -*- coding: utf-8 -*-
"""patent_config.json 읽기와 사람 확인값 판정.

★ 로 시작하는 값은 사람이 확정해야 하는 값이며, 채워지기 전에는
관청 서식(DOCX) 생성을 차단한다.
"""
from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path

기본설정 = {
    "invention": {"title_kr": "", "title_en": "", "tech_field": "", "related_project": None},
    "applicants": [],
    "inventors": [],
    "ipc": [],
    "filing": {
        "kind": "임시명세서(가출원)",
        "fee_reduction": "",
        "disclosure_exception": {"claimed": False, "date": "", "medium": ""},
        "priority_deadline": "",
    },
    "paths": {
        "base_dir": "",
        "spec_md": "01_명세서.md",
        "claims_md": "02_청구범위.md",
        "submission_md": "03_제출본_명세서_청구범위.md",
        "drawings_dir": "도면",
        "out_dir": "_출력",
    },
    "style": {
        "font_kr": "바탕",
        "font_code": "Consolas",
        "heading_sizes": {"1": 16, "2": 14, "3": 12, "4": 11, "5": 11, "6": 11},
        "body_size": 11,
        "table_style": "Light Grid Accent 1",
        "template_docx": "",
    },
    "output": {"filename_pattern": "임시명세서_{date}.docx"},
    "build": {"internal_sections": ["회피 논거"]},
    "prior_art": {"queries": [], "countries": ["KR", "US"], "max_results": 10,
                  "kipris_key": "", "endpoint": ""},
    "trace": {"source_root": ""},
    "compare": {"terms": []},
    "evidence": {"urls": []},
    "validation": {
        "strict": True,
        "required_sections": [
            "명세서", "발명의 명칭", "기술분야", "발명의 배경이 되는 기술",
            "발명의 내용", "해결하려는 과제", "과제의 해결 수단", "발명의 효과",
            "도면의 간단한 설명", "발명을 실시하기 위한 구체적인 내용",
            "요약서", "요약",
        ],
        "recommended_sections": ["선행기술문헌", "특허문헌", "비특허문헌", "부호의 설명", "대표도"],
        "forbidden_in_independent_claims": [],
        "style_checks": True,
        "min_claims": 1,
    },
}

필수값경로 = [
    ("invention", "title_kr"),
    ("applicants", 0, "name"),
    ("inventors", 0, "name"),
]


class 설정:
    """patent_config.json 한 벌."""

    def __init__(self, 자료: dict, 경로: Path | None = None, 폴더: Path | None = None):
        self.자료 = _합치기(기본설정, 자료)
        self.경로파일 = 경로
        self.폴더 = 폴더 or (경로.parent if 경로 else Path("."))

    # ── 읽기 도우미 ──────────────────────────────────────────────
    def 값(self, *열쇠, 기본=None):
        현재 = self.자료
        for 열 in 열쇠:
            if isinstance(현재, dict):
                if 열 not in 현재:
                    return 기본
                현재 = 현재[열]
            elif isinstance(현재, list):
                if not isinstance(열, int) or 열 >= len(현재):
                    return 기본
                현재 = 현재[열]
            else:
                return 기본
        return 현재 if 현재 is not None else 기본

    def 경로(self, 열쇠: str, 기본: str = "") -> str:
        return self.값("paths", 열쇠, 기본=기본) or 기본

    @property
    def 명칭(self) -> str:
        return self.값("invention", "title_kr", 기본="") or ""

    @property
    def 출력폴더(self) -> Path:
        return self.폴더 / (self.경로("out_dir", "_출력") or "_출력")

    # ── 사람 확인값 ──────────────────────────────────────────────
    def 미확정값(self) -> list:
        """★ 표식이 남아 있거나 비어 있는 필수 칸의 경로 목록."""
        결과 = []
        for 경로, 값 in _잎순회(self.자료):
            if isinstance(값, str) and 값.strip().startswith("★"):
                결과.append((경로, 값.strip()))
        for 열쇠들 in 필수값경로:
            값 = self.값(*열쇠들)
            if 값 in (None, ""):
                결과.append((_경로문자열(열쇠들), "(빈 값)"))
        return 결과

    def 검사칸수(self) -> int:
        return sum(1 for _ in _잎순회(self.자료))

    @property
    def 차단됨(self) -> bool:
        return bool(self.미확정값())

    # ── 날짜 ────────────────────────────────────────────────────
    def 공개일(self):
        return _날짜(self.값("filing", "disclosure_exception", "date", 기본=""))

    def 공지예외기한(self):
        """공개일부터 12개월. 이 날까지 출원해야 공지예외를 주장할 수 있다."""
        공개 = self.공개일()
        if not 공개:
            return None
        try:
            return 공개.replace(year=공개.year + 1)
        except ValueError:      # 2월 29일
            return 공개.replace(year=공개.year + 1, day=28)

    def 우선일기한(self):
        return _날짜(self.값("filing", "priority_deadline", 기본=""))


def 불러오기(폴더) -> 설정:
    """폴더 안의 patent_config.json 을 읽는다. 없으면 기본값으로 만든다."""
    폴더 = Path(폴더)
    파일 = 폴더 / "patent_config.json"
    if 파일.exists():
        자료 = json.loads(파일.read_text(encoding="utf-8-sig"))
        return 설정(자료, 파일, 폴더)
    return 설정({}, None, 폴더)


def 저장하기(설정본: 설정, 경로: Path | None = None) -> Path:
    대상 = Path(경로 or 설정본.경로파일 or (설정본.폴더 / "patent_config.json"))
    대상.write_text(json.dumps(설정본.자료, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")
    return 대상


def _합치기(바탕: dict, 덧: dict) -> dict:
    결과 = json.loads(json.dumps(바탕, ensure_ascii=False))
    for 열쇠, 값 in (덧 or {}).items():
        if isinstance(값, dict) and isinstance(결과.get(열쇠), dict):
            결과[열쇠] = _합치기(결과[열쇠], 값)
        else:
            결과[열쇠] = 값
    return 결과


def _잎순회(마디, 경로: str = ""):
    """설정 나무의 잎(문자·숫자·불리언)을 경로와 함께 훑는다."""
    if isinstance(마디, dict):
        for 열쇠, 값 in 마디.items():
            if 열쇠.startswith("_"):
                continue
            yield from _잎순회(값, f"{경로}.{열쇠}" if 경로 else 열쇠)
    elif isinstance(마디, list):
        for i, 값 in enumerate(마디):
            yield from _잎순회(값, f"{경로}[{i}]")
    else:
        yield 경로, 마디


def _경로문자열(열쇠들) -> str:
    조각 = ""
    for 열 in 열쇠들:
        조각 += f"[{열}]" if isinstance(열, int) else (f".{열}" if 조각 else str(열))
    return 조각


def _날짜(글: str):
    글 = (글 or "").strip()
    for 형식 in ("%Y-%m-%d", "%Y.%m.%d", "%Y/%m/%d", "%Y%m%d"):
        try:
            return datetime.strptime(글, 형식).date()
        except ValueError:
            continue
    return None


def 남은날(기한) -> int | None:
    return (기한 - date.today()).days if 기한 else None
