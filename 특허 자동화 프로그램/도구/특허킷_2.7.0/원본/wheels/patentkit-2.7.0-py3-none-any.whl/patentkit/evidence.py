# -*- coding: utf-8 -*-
"""공개 증거 수집 — 출원 전에 무엇이 공개돼 있었는지 자료로 남긴다.

특허법 제30조 공지예외를 주장하려면 공개 사실과 그 시각을 증명해야 하고,
증명서류는 출원일부터 30일 안에 내야 한다. 화면 캡처만으로는 게시일이 특정되지
않으므로, 이 도구는 응답 헤더와 본문을 그대로 받아 둔다.

받아 두는 것은 셋이다.
  <이름>.html           응답 본문 그대로
  <이름>_headers.txt    상태줄과 응답 헤더 전문(Date·Last-Modified·ETag 가 증거가 된다)
  캡처시각.txt          내려받은 시각(KST)

접근 통제가 걸려 401·403 이 오는 경로도 그대로 기록한다. 「인증이 필요했다」는
사실 자체가 공개되지 아니하였다는 증거가 되기 때문이다.
"""
from __future__ import annotations

import json
import re
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import sources

한국시각 = timezone(timedelta(hours=9))
브라우저이름 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) patentkit/1.1 evidence-collector"
대장파일 = "_수집대장.json"


def 지금() -> str:
    return datetime.now(한국시각).strftime("%Y-%m-%d %H:%M:%S")


def 이름짓기(주소: str) -> str:
    """주소를 파일 이름으로 바꾼다. 같은 사이트의 경로가 서로 구별되게 한다."""
    벗김 = re.sub(r"^https?://", "", 주소.strip())
    벗김 = 벗김.rstrip("/")
    이름 = re.sub(r"[^0-9A-Za-z가-힣._-]+", "_", 벗김).strip("_")
    return (이름 or "page")[:80]


def 한곳받기(주소: str, 대상폴더: Path, 시간제한: int = 30) -> dict:
    """한 주소를 받아 파일로 남기고 결과를 돌려준다."""
    대상폴더 = Path(대상폴더)
    대상폴더.mkdir(parents=True, exist_ok=True)
    이름 = 이름짓기(주소)
    받은때 = 지금()

    부탁 = urllib.request.Request(주소, headers={"User-Agent": 브라우저이름})
    상태, 헤더들, 본문, 문제 = 0, [], b"", ""
    try:
        with urllib.request.urlopen(부탁, timeout=시간제한) as 답:
            상태 = 답.status
            헤더들 = list(답.headers.items())
            본문 = 답.read()
            최종주소 = 답.url
    except urllib.error.HTTPError as 답:          # 401·403·404 도 증거다
        상태 = 답.code
        헤더들 = list(답.headers.items())
        본문 = 답.read() or b""
        최종주소 = 주소
    except (urllib.error.URLError, TimeoutError, OSError) as 잘못:
        문제 = str(잘못)
        최종주소 = 주소

    if 문제:
        return {"주소": 주소, "이름": 이름, "받은때": 받은때, "상태": 0,
                "문제": 문제, "본문파일": "", "헤더파일": "", "크기": 0,
                "종류": "", "접근통제": "확인 못 함"}

    본문파일 = 대상폴더 / f"{이름}.html"
    헤더파일 = 대상폴더 / f"{이름}_headers.txt"
    본문파일.write_bytes(본문)
    헤더파일.write_text(
        f"HTTP {상태}\n최종 주소: {최종주소}\n"
        + "\n".join(f"{열쇠}: {값}" for 열쇠, 값 in 헤더들) + "\n",
        encoding="utf-8")
    (대상폴더 / "캡처시각.txt").write_text(f"저장시각(KST): {받은때}\n", encoding="utf-8")

    종류 = dict((열쇠.lower(), 값) for 열쇠, 값 in 헤더들).get("content-type", "")
    return {
        "주소": 주소, "최종주소": 최종주소, "이름": 이름, "받은때": 받은때,
        "상태": 상태, "문제": "", "본문파일": 본문파일.name, "헤더파일": 헤더파일.name,
        "크기": len(본문), "종류": 종류,
        "접근통제": "있음" if 상태 in (401, 403) else ("없음" if 상태 == 200 else "해당 없음"),
        "제목": 제목뽑기(본문),
    }


def 제목뽑기(본문: bytes) -> str:
    글 = 본문[:20000].decode("utf-8", "replace")
    맞음 = re.search(r"<title[^>]*>(.*?)</title>", 글, re.S | re.I)
    return re.sub(r"\s+", " ", 맞음.group(1)).strip()[:80] if 맞음 else ""


def 수집(주소들, 대상폴더: Path) -> list:
    """여러 주소를 받아 대장에 쌓는다. 이미 있던 기록은 남기고 새 줄을 더한다."""
    대상폴더 = Path(대상폴더)
    모은것 = [한곳받기(주소, 대상폴더) for 주소 in 주소들]
    대장 = 대상폴더 / 대장파일
    이전 = json.loads(대장.read_text(encoding="utf-8")) if 대장.exists() else []
    대장.write_text(json.dumps(이전 + 모은것, ensure_ascii=False, indent=1),
                   encoding="utf-8")
    return 모은것


def 대장읽기(대상폴더: Path) -> list:
    대장 = Path(대상폴더) / 대장파일
    if 대장.exists():
        return json.loads(대장.read_text(encoding="utf-8"))
    return 캡처폴더읽기(대상폴더)


def 캡처폴더읽기(대상폴더: Path) -> list:
    """대장 없이 파일만 남은 캡처 폴더를 읽는다.

    킷이 있기 전에 손이나 다른 스크립트로 받아 둔 자료도 <이름>_headers.txt 와
    <이름>.html 짝만 있으면 같은 모양으로 읽어 낸다. 이미 받아 둔 증거를 다시
    받게 하는 것은 증거의 시각을 뒤로 미루는 일이므로 하지 아니한다.
    """
    대상폴더 = Path(대상폴더)
    if not 대상폴더.is_dir():
        return []
    받은때 = ""
    시각파일 = 대상폴더 / "캡처시각.txt"
    if 시각파일.exists():
        맞음 = re.search(r"(\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2})",
                       시각파일.read_text(encoding="utf-8", errors="replace"))
        받은때 = 맞음.group(1) if 맞음 else ""

    기록들 = []
    for 헤더파일 in sorted(대상폴더.glob("*_headers.txt")):
        이름 = 헤더파일.name[: -len("_headers.txt")]
        글 = 헤더파일.read_text(encoding="utf-8", errors="replace")
        상태맞음 = re.search(r"HTTP(?:/[\d.]+)?\s+(\d{3})", 글)
        상태 = int(상태맞음.group(1)) if 상태맞음 else 0
        주소맞음 = re.search(r"^(?:최종 주소|Location|Content-Location):\s*(\S+)",
                         글, re.M)
        종류맞음 = re.search(r"^Content-Type:\s*(.+)$", 글, re.M | re.I)
        본문파일 = next((대상폴더 / f"{이름}{꼬리}" for 꼬리 in (".html", ".htm", ".txt", ".json")
                    if (대상폴더 / f"{이름}{꼬리}").exists()), None)
        본문 = 본문파일.read_bytes() if 본문파일 else b""
        본문속주소 = ""
        if not 주소맞음 and 본문:
            터 = re.search(rb'<(?:link[^>]+rel="canonical"|meta[^>]+property="og:url")'
                         rb'[^>]+(?:href|content)="(https?://[^"]+)"', 본문[:60000], re.I)
            본문속주소 = 터.group(1).decode("utf-8", "replace") if 터 else ""
        기록들.append({
            "주소": (주소맞음.group(1) if 주소맞음 else 본문속주소 or f"{이름} (주소 미기재)"),
            "주소확인": bool(주소맞음 or 본문속주소),
            "이름": 이름, "받은때": 받은때, "상태": 상태, "문제": "",
            "본문파일": 본문파일.name if 본문파일 else "", "헤더파일": 헤더파일.name,
            "크기": len(본문), "종류": (종류맞음.group(1).strip() if 종류맞음 else ""),
            "접근통제": "있음" if 상태 in (401, 403) else ("없음" if 상태 == 200 else "해당 없음"),
            "제목": 제목뽑기(본문),
            "비고": "킷 밖에서 받아 둔 자료를 읽었다",
        })
    return 기록들


def 대장보고서(대상폴더: Path, 설정본=None) -> str:
    """01_출원전_공개이력_대장.md 로 쓸 글을 만든다."""
    줄들 = ["# 출원 전 공개 이력 대장", "",
           f"작성 {지금()} · 자료 {Path(대상폴더).name}", "",
           "○ 이 대장은 무인증으로 열리는 자원을 기계로 확인한 기록이다. "
           "응답 헤더 전문과 본문을 함께 저장했으므로 게시 시각의 증명 자료로 쓸 수 있다.", "",
           "---", "", "## 1. 확인 결과", "",
           "| 확인 시각(KST) | 주소 | 응답 | 접근 통제 | 크기 | 제목 |",
           "| --- | --- | --- | --- | --- | --- |"]
    기록들 = 대장읽기(대상폴더)
    for 기록 in 기록들:
        상태 = 기록.get("상태") or "받지 못함"
        줄들.append(
            f"| {기록.get('받은때', '-')} | {_자르기(기록.get('주소', ''), 60)} | {상태} | "
            f"{기록.get('접근통제', '-')} | {기록.get('크기', 0):,}B | "
            f"{_자르기(기록.get('제목', ''), 40) or '-'} |")
    if not 기록들:
        줄들.append("| - | 수집한 기록이 없다 | - | - | - | - |")
    줄들.append("")

    열린것 = [기록 for 기록 in 기록들 if 기록.get("상태") == 200]
    막힌것 = [기록 for 기록 in 기록들 if 기록.get("상태") in (401, 403)]
    줄들 += ["○ 무인증으로 열린 경로 " + str(len(열린것)) + "곳, "
            "인증이 필요한 경로 " + str(len(막힌것)) + "곳.", ""]

    줄들 += ["---", "", "## 2. 시한", ""]
    if 설정본 is not None:
        공개 = 설정본.공개일()
        기한 = 설정본.공지예외기한()
        if 공개 and 기한:
            from .config import 남은날
            남음 = 남은날(기한)
            줄들 += [f"○ 설정에 적은 최초 공개일은 {공개} 이며, 공지예외를 주장할 수 있는 "
                    f"출원 기한은 **{기한}**(D-{남음})이다.", "",
                    "○ 증명서류는 출원일부터 **30일 안**에 내야 한다(특허법 제30조제2항).", ""]
        else:
            줄들 += ["○ patent_config.json 의 filing.disclosure_exception.date 가 비어 있다. "
                    "최초 공개일을 확정해 적는다.", ""]
    줄들 += ["○ 위 표의 확인 시각은 **내려받은 시각**이지 게시 시각이 아니다. "
            "게시 시각은 배포 이력·저장소 커밋·업로드 기록으로 따로 증명한다.", "",
            "---", "", "## 3. 사람이 확인할 것", "",
            "○ 열린 경로에 특허 후보의 핵심 구성이 문언으로 드러나 있는지 읽는다.",
            "○ 드러나 있으면 그 문언을 이 대장에 그대로 옮겨 적는다.",
            "○ 국가마다 공지예외 기간과 요건이 다르다. 해외 출원 계획이 있으면 함께 살핀다.", "",
            "---", ""]
    줄들.append(sources.출처묶음(["공지예외", "공지예외증명", "신규성"]))
    return "\n".join(줄들)


def _자르기(글: str, 길이: int) -> str:
    글 = (글 or "").replace("|", "\\|").strip()
    return 글 if len(글) <= 길이 else 글[:길이 - 1] + "…"
