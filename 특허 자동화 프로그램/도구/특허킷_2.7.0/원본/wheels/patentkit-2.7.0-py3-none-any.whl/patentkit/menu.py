# -*- coding: utf-8 -*-
"""고르는 화면 — 명령을 외우지 않고 번호로 쓴다.

윈도우에서 「특허킷.bat」을 두 번 누르면 이 화면이 뜬다.
명령줄에 익숙하면 이 화면 없이 patentkit validate … 로 바로 써도 된다.
"""
from __future__ import annotations

from pathlib import Path

from . import __version__
from . import build as 제출본
from . import compare, config, doc, docxout, dossier, drawings, evidence, figures, install, prior_art
from . import renumber, rules, scaffold, trace
from . import 보기자료
from . import web as 메인보드
from .report import 일람표, 콘솔출력
from .util import 쓰기

줄 = "─" * 58


def 묻기(안내: str) -> str:
    """입력을 받는다. 창이 닫히거나 Ctrl+C 를 누르면 조용히 마친다."""
    try:
        return input(안내).strip()
    except (EOFError, KeyboardInterrupt):
        print("\n  마친다.")
        raise SystemExit(0)


킷폴더 = Path(__file__).resolve().parent


def 킷내부(자리: Path) -> bool:
    """킷이 들고 있는 뼈대(templates)를 출원건으로 잘못 세지 않기 위한 판정."""
    try:
        풀린것 = Path(자리).resolve()
    except OSError:
        return False
    return 풀린것 == 킷폴더 or 킷폴더 in 풀린것.parents


def 출원건인가(폴더: Path) -> bool:
    if 킷내부(폴더):
        return False
    return (폴더 / "patent_config.json").exists() or (폴더 / "01_명세서.md").exists()


def 출원건모으기(루트: Path) -> list:
    루트 = Path(루트)
    if not 루트.exists():
        return []
    if 출원건인가(루트):
        return [루트]
    try:
        return sorted(자리 for 자리 in 루트.iterdir()
                      if 자리.is_dir() and 출원건인가(자리))
    except OSError:
        return []


def 훑기(뿌리: Path, 깊이: int = 4, 최대: int = 800) -> list:
    """뿌리 아래를 몇 층까지만 훑어 출원건 폴더를 모은다.

    출원건을 찾으면 그 안쪽은 더 들어가지 않는다. _작업이력·도면까지 뒤질 일이 없다.
    """
    뿌리 = Path(뿌리)
    if not 뿌리.is_dir():
        return []
    모은것, 대기, 본수 = [], [(뿌리, 0)], 0
    while 대기 and 본수 < 최대 and len(모은것) < 50:
        자리, 층 = 대기.pop(0)
        본수 += 1
        if 출원건인가(자리):
            모은것.append(자리)
            continue
        if 층 >= 깊이:
            continue
        try:
            아이들 = sorted(아이 for 아이 in 자리.iterdir() if 아이.is_dir())
        except OSError:
            continue
        for 아이 in 아이들:
            if 아이.name.startswith((".", "_출력", "__")):
                continue
            대기.append((아이, 층 + 1))
    return 모은것


def 뒤진곳(시작: Path) -> list:
    """출원건을 찾아볼 폴더 차례. 없는 폴더는 뺀다."""
    시작 = Path(시작).resolve()      # 「.」의 부모는 「.」이므로 먼저 실제 경로로 편다
    후보 = [시작, 시작.parent,
           Path.home() / "Desktop", Path.home() / "바탕 화면",
           Path.home() / "Documents", Path.home() / "문서"]
    본것, 남길것 = set(), []
    for 자리 in 후보:
        if 자리 not in 본것 and 자리.is_dir():
            본것.add(자리)
            남길것.append(자리)
    return 남길것


def 찾아보기(시작: Path) -> list:
    """현재 폴더, 그 위 폴더, 바탕화면, 문서 차례로 출원건을 찾는다."""
    for 자리 in 뒤진곳(시작):
        모은것 = 훑기(자리)
        if 모은것:
            return 모은것
    return []


def 경로묻기(안내: str, 뒤진것=None) -> Path | None:
    print(f"\n{안내}")
    for 자리 in 뒤진것 or []:
        print(f"  찾아본 곳 — {자리}")
    print("  (탐색기에서 폴더를 이 창으로 끌어다 놓고 Enter. 그냥 Enter 면 취소)")
    답 = 묻기("  폴더 > ").strip('"').strip("'")
    if not 답:
        return None
    자리 = Path(답)
    if not 자리.exists():
        print(f"  그런 폴더가 없다: {자리}")
        return None
    return 자리


def 고르기(폴더들: list) -> Path | None:
    if len(폴더들) == 1:
        return 폴더들[0]
    print()
    for 번호, 자리 in enumerate(폴더들, 1):
        print(f"  {번호}. {자리.name}")
    답 = 묻기("\n  번호 > ")
    if 답.isdigit() and 1 <= int(답) <= len(폴더들):
        return 폴더들[int(답) - 1]
    print("  번호가 아니다. 되돌아간다.")
    return None


def 대상고르기(바탕: Path, 쓰임: str) -> Path | None:
    폴더들 = 찾아보기(바탕)
    if not 폴더들:
        자리 = 경로묻기(f"{쓰임}할 출원건 폴더를 알려 준다.", 뒤진곳(바탕))
        if 자리 is None:
            return None
        폴더들 = 출원건모으기(자리)
        if not 폴더들:
            print(f"  그 폴더 안에 출원건이 없다: {자리}")
            print("  출원건 폴더에는 01_명세서.md 나 patent_config.json 이 있어야 한다.")
            return None
    return 고르기(폴더들)


# ── 각 항목 ─────────────────────────────────────────────────────
def _현황(바탕: Path) -> None:
    폴더들 = 찾아보기(바탕)
    if not 폴더들:
        자리 = 경로묻기("출원건이 들어 있는 폴더를 알려 준다.", 뒤진곳(바탕))
        폴더들 = 출원건모으기(자리) if 자리 else []
    if not 폴더들:
        print("  볼 출원건이 없다.")
        return
    결과들 = [rules.검사(자리, config.불러오기(자리)) for 자리 in 폴더들]
    print()
    print(일람표(결과들))
    print(f"\n  찾은 곳 — {폴더들[0].parent}")


def _검사(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "검사")
    if 자리 is None:
        return
    콘솔출력(rules.검사(자리, config.불러오기(자리)))


def _제출본(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "제출본을 생성")
    if 자리 is None:
        return
    print()
    try:
        제출본.실행(자리, config.불러오기(자리))
    except (FileNotFoundError, ValueError) as 문제:
        print(f"  실패 — {문제}")


def _서식(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "관청 서식을 생성")
    if 자리 is None:
        return
    설정 = config.불러오기(자리)
    결과 = rules.검사(자리, 설정, 빠르게=True)
    if 결과.오류수:
        print(f"\n  검사 오류 {결과.오류수}건이 있다. 3번으로 먼저 확인한다.")
        답 = 묻기("  그래도 검토용으로 만들까? (y/N) > ").lower()
        if 답 != "y":
            return
    try:
        print(f"\n  생성 — {docxout.만들기(자리, 설정, 강행=True, 표지=True)}")
    except (ValueError, FileNotFoundError, docxout.의존성없음) as 문제:
        print(f"  실패 — {문제}")


def _새출원건(바탕: Path) -> None:
    이름 = 묻기("\n  폴더 이름 (예: 출원건_05_새발명) > ")
    if not 이름:
        return
    명칭 = 묻기("  발명의 명칭 (나중에 채우려면 그냥 Enter) > ")
    자리 = 바탕 / 이름
    if 자리.exists():
        print(f"  이미 있다: {자리}")
        return
    scaffold.만들기(자리, 명칭)
    print(f"\n  만들었다 — {자리}")
    print("  patent_config.json 과 01_명세서.md 의 ★ 자리를 채운 뒤 3번으로 검사한다.")


def _도면(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "도면을 렌더")
    if 자리 is None:
        return
    설정 = config.불러오기(자리)
    도면폴더 = 자리 / (설정.경로("drawings_dir", "도면") or "도면")
    print()
    try:
        for 이름, 폭, 높이, 바이트 in figures.렌더(도면폴더):
            if 폭 == 0:
                print(f"  건너뜀 — {이름} · {바이트}")
                continue
            print(f"  렌더 — {이름} {폭}x{높이} {바이트 / 1024:.1f}KB")
    except FileNotFoundError:
        print(f"  그릴 SVG 가 없다: {도면폴더}")
    except RuntimeError as 문제:
        print(f"  실패 — {문제}")


def _번호(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "단락번호를 정리")
    if 자리 is None:
        return
    설정 = config.불러오기(자리)
    명세서 = doc.명세서찾기(자리, 설정)
    if 명세서 is None:
        print("  명세서가 없다.")
        return
    미리 = renumber.다시매기기(명세서, 미리보기=True)
    print(f"\n  단락 {미리['총단락']}개 중 {미리['바뀐수']}개가 바뀐다.")
    if 미리["바뀐수"] == 0:
        print("  고칠 것이 없다.")
        return
    for 옛, 새 in list(미리["대응표"].items())[:8]:
        if 옛 != 새:
            print(f"    [{옛:04d}] → [{새:04d}]")
    if 묻기("\n  적용할까? 원본은 _작업이력에 백업된다. (y/N) > ").lower() != "y":
        return
    결과 = renumber.다시매기기(명세서)
    print(f"  고쳤다. 백업 — {Path(결과['백업']).name if 결과['백업'] else '없음'}")
    print("  제출본을 다시 만들려면 4번을 실행한다.")


def _선행기술(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "선행기술을 조사")
    if 자리 is None:
        return
    설정 = config.불러오기(자리)
    자료 = [자리 / "_원본자료", 자리.parent / "_원본자료"]
    청구경로 = doc.청구범위찾기(자리, 설정)
    청구범위 = doc.읽어들이기(청구경로) if 청구경로 else None
    결과 = prior_art.조사(설정, 자료, None, 청구범위)
    if not 결과["문헌수"]:
        print("\n  읽을 KIPRIS 결과 파일이 없다.")
        for 한곳 in 자료:
            print(f"    찾아본 곳 — {한곳}")
        print("  받아 둔 결과 JSON 을 그 폴더에 넣거나, 설정에 열쇠를 넣고 명령줄에서")
        print("  특허킷 prior-art --fetch 를 실행한다.")
        return
    자사수 = len(결과["묶음"][prior_art.자사선출원])
    확대수 = len(결과["묶음"][prior_art.확대선원])
    print(f"\n  문헌 {결과['문헌수']}건 · 자사 선출원 {자사수}건 · 확대선원 후보 {확대수}건")
    for 줄 in 결과["상위"][:8]:
        print(f"    겹침{줄['점수']} {줄['지위']} — {줄['문헌'].title[:44]}")
    대상 = 자리 / "_근거자료" / "선행기술조사.md"
    쓰기(대상, prior_art.보고서(결과, f"선행기술 조사 — {자리.name}"))
    print(f"  보고서 — {대상}")


def _공개증거(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "공개 증거를 모을")
    if 자리 is None:
        return
    print("\n  받아 둘 주소를 한 줄에 하나씩 넣는다. 다 넣었으면 그냥 Enter.")
    주소들 = []
    while True:
        답 = 묻기(f"  주소 {len(주소들) + 1} > ")
        if not 답:
            break
        주소들.append(답)
    대상 = 보기자료.증거폴더찾기(자리)
    if 주소들:
        for 기록 in evidence.수집(주소들, 대상):
            뒤 = 기록["문제"] or f"{기록['크기']:,}B · 접근통제 {기록['접근통제']}"
            print(f"    {기록['상태'] or '받지 못함'}  {기록['주소']}  {뒤}")
    기록들 = evidence.대장읽기(대상)
    if not 기록들:
        print("  받아 둔 기록이 없다.")
        return
    보고 = 자리 / "_원본자료" / "공개이력대장.md"
    쓰기(보고, evidence.대장보고서(대상, config.불러오기(자리)))
    print(f"  대장 — {보고} (기록 {len(기록들)}건)")


def _구현대조(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "구현을 대조")
    if 자리 is None:
        return
    설정 = config.불러오기(자리)
    if not trace.읽기(자리):
        청구경로 = doc.청구범위찾기(자리, 설정) or doc.명세서찾기(자리, 설정)
        문 = doc.읽어들이기(청구경로) if 청구경로 else None
        if not (문 and 문.청구항들):
            print("  청구항을 찾지 못했다.")
            return
        print(f"\n  대조표 뼈대를 만들었다 — {trace.뼈대만들기(자리, 문.청구항들)}")
        print("  그 파일의 ★ 자리에 제품 소스의 파일과 행을 적은 뒤 다시 실행한다.")
        return

    적힌뿌리 = 설정.값("trace", "source_root", 기본="") or ""
    안내 = 적힌뿌리 or "설정에 없음"
    답 = 묻기(f"\n  제품 소스 폴더 (그냥 Enter 면 {안내}) > ").strip('"').strip("'")
    뿌리 = Path(답 or 적힌뿌리) if (답 or 적힌뿌리) else None
    if 뿌리 is None:
        print("  제품 소스 폴더를 알려 줘야 한다.")
        return
    if not 뿌리.exists():
        print(f"  그런 폴더가 없다: {뿌리}")
        return
    결과 = trace.검증(자리, 뿌리, 지문갱신=False)
    for 이름, 수 in 결과["셈"].items():
        print(f"  {이름} {수}건")
    대상 = 자리 / "_근거자료" / "구현대조.md"
    쓰기(대상, trace.보고서(결과, 자리.name))
    print(f"  보고서 — {대상}")
    if 결과["셈"].get(trace.미확인):
        if 묻기("  지금 소스로 지문을 남길까? (y/N) > ").lower() == "y":
            trace.검증(자리, 뿌리, 지문갱신=True)
            print("  지문을 남겼다. 다음부터는 소스가 바뀌면 알려 준다.")

def _대비표(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "인용문헌을 대비")
    if 자리 is None:
        return
    설정 = config.불러오기(자리)
    문헌들 = compare.목록읽기(자리)
    if not 문헌들:
        청구경로0 = doc.청구범위찾기(자리, 설정) or doc.명세서찾기(자리, 설정)
        조사 = prior_art.조사결과(자리, 설정,
                              doc.읽어들이기(청구경로0) if 청구경로0 else None)
        print(f"\n  대비할 문헌 목록을 만들었다 — {compare.뼈대만들기(자리, 조사)}")
        if 조사:
            print(f"  선행기술 조사에서 {len(compare.목록읽기(자리))}건을 옮겨 적었다.")
        print("  그 파일에 상대 청구항 전문(또는 전문 파일)을 적고 다시 실행한다.")
        return

    청구경로 = doc.청구범위찾기(자리, 설정) or doc.명세서찾기(자리, 설정)
    청구범위 = doc.읽어들이기(청구경로) if 청구경로 else None
    독립항들 = [항 for 항 in (청구범위.청구항들 if 청구범위 else []) if 항.독립항]
    if not 독립항들:
        print("  독립항을 찾지 못했다.")
        return

    뿌리들 = [자리, 자리 / "_근거자료", 자리 / "_원본자료", 자리.parent,
            자리.parent / "_원본자료"]
    청구대비, 전문모음 = [], {}
    print()
    for 문헌 in 문헌들:
        이름 = (문헌.get("번호") or "이름 없음").lstrip("★")
        try:
            상대청구, 상대전문 = compare.문헌글(문헌, 뿌리들)
        except (RuntimeError, FileNotFoundError) as 문제:
            print(f"  {이름} — 읽지 못했다: {문제}")
            continue
        if 상대청구:
            결과 = compare.청구항대비(독립항들[0], 상대청구)
            청구대비.append({"번호": 이름, "서지": 문헌.get("서지", ""),
            "청구항출처": 문헌.get("청구항출처", ""),
            "청구항받은때": 문헌.get("청구항받은때", ""),
                          "줄": 결과["줄"], "대조못함": 결과["대조못함"]})
        if 상대전문:
            전문모음[이름] = 상대전문

    if 청구대비:
        대상 = 자리 / "_근거자료" / "선행문헌_청구항대비.md"
        쓰기(대상, compare.보고서_청구항(청구대비, 자리.name))
        못한것 = sum(1 for 한건 in 청구대비 if 한건.get("대조못함"))
        없는축 = sum(1 for 한건 in 청구대비 if not 한건.get("대조못함")
                   for 줄 in 한건["줄"] if not 줄["대응있음"])
        말 = f"  청구항 대비 {len(청구대비)}건 · 대응 없음 축 {없는축}개"
        if 못한것:
            말 += f" · 언어가 달라 대조 못 한 문헌 {못한것}건"
        print(말)
        print(f"  보고서 — {대상}")
    if 전문모음:
        묶음 = compare.용어그룹풀기(설정.값("compare", "terms", 기본=[])) \
            or compare.용어자동뽑기(청구범위)
        대조 = compare.전문대조(묶음, 전문모음)
        대상 = 자리 / "_근거자료" / "확대선원_전문대비.md"
        쓰기(대상, compare.보고서_전문(대조, 자리.name))
        나온것 = sum(1 for 칸 in 대조["표"]
                   if any(정보["셈"] for 정보 in 칸["문헌별"].values()))
        print(f"  전문 대조 {len(전문모음)}건 · 기재 확인된 용어 {나온것}묶음")
        print(f"  보고서 — {대상}")
    if not 청구대비 and not 전문모음:
        print("  읽을 청구항도 전문도 없다. 대비문헌.json 을 채운다.")


def _검토초안(바탕: Path) -> None:
    폴더들 = 찾아보기(바탕)
    if not 폴더들:
        자리 = 경로묻기("출원건이 들어 있는 폴더를 알려 준다.", 뒤진곳(바탕))
        폴더들 = 출원건모으기(자리) if 자리 else []
    if not 폴더들:
        print("  볼 출원건이 없다.")
        return
    print()
    모음들 = []
    for 자리 in 폴더들:
        모은것 = dossier.모으기(자리, config.불러오기(자리))
        모음들.append(모은것)
        대상 = 자리 / "_근거자료" / "04_변리사_검토사항_초안.md"
        쓰기(대상, dossier.건별초안(모은것))
        print(f"  {자리.name} — 검토 초안 {대상.name}")
    뿌리 = 폴더들[0].parent
    대상 = 뿌리 / "00_종합보고서.md"
    쓰기(대상, dossier.프로젝트보고서(모음들))
    print(f"  종합보고서 — {대상}")


def _메인보드(바탕: Path) -> None:
    폴더들 = 찾아보기(바탕)
    뿌리 = 폴더들[0].parent if 폴더들 else 바탕
    print(f"\n  웹 메인보드를 띄운다 — {뿌리}")
    print("  브라우저가 열린다. 이 창을 닫거나 Ctrl+C 를 누르면 메인보드도 닫힌다.")
    메인보드.띄우기(뿌리)


def _도면초안(바탕: Path) -> None:
    자리 = 대상고르기(바탕, "도면 초안을 만들")
    if 자리 is None:
        return
    설정 = config.불러오기(자리)
    print()
    try:
        for 이름, 상태 in drawings.만들기(자리, 설정):
            print(f"  {이름} — {상태}")
    except (FileNotFoundError, ValueError) as 문제:
        print(f"  실패 — {문제}")
        return
    print("  초안이다. 관청에 낼 도면은 사람이 보고 다듬는다.")
    print("  PNG 로 바꾸려면 5번(도면 그리기)을 실행한다.")


def _환경(_바탕: Path) -> None:
    from .cli import 명령_doctor
    print()
    명령_doctor(None)


def _설치(_바탕: Path) -> None:
    놓인곳 = install.설치됨()
    if 놓인곳:
        print(f"\n  이미 설치돼 있다 — {놓인곳.parent}")
        if 묻기("  다시 설치할까? (y/N) > ").lower() != "y":
            return
    install.설치()


def _후보원장(바탕: Path) -> None:
    """발명 후보 원장 — 킷은 사실만 세고 등급은 사람이 매긴다."""
    from . import candidates

    올린것 = candidates.출원건에서채우기(바탕)
    for 한건 in 올린것:
        print(f"  올림 — {한건['코드']}")
    후보들 = candidates.읽기(바탕)
    if not 후보들:
        print("  후보가 없다. 출원건 폴더를 먼저 만든다.")
        return
    사실 = {한건.get("코드"): candidates.근거모으기(바탕, 한건) for 한건 in 후보들}
    print()
    print(f"  {'등급':>4}  {'코드':<28}  청구항  선행문헌  자사저촉  남은일")
    for 한건 in 후보들:
        근거 = 사실.get(한건.get("코드"), {})
        print(f"  {한건.get('등급', '보류'):>4}  {한건.get('코드', ''):<28}"
              f"  {근거.get('청구항수', 0):>5}  {근거.get('선행문헌수', 0):>7}"
              f"  {근거.get('자사저촉후보', 0):>7}  {len(근거.get('빠진것', [])):>5}")
    print()
    코드 = input("  등급을 매길 코드(그냥 엔터면 건너뛴다): ").strip()
    if not 코드:
        return
    등급 = input(f"  등급 [{'·'.join(candidates.등급들)}]: ").strip()
    까닭 = input("  그렇게 본 까닭: ").strip()
    사람 = input("  판단자: ").strip()
    try:
        한건 = candidates.고치기(바탕, 코드,
                             {"등급": 등급, "등급근거": 까닭, "판단자": 사람})
    except (KeyError, ValueError) as 문제:
        print(f"  {문제}")
        return
    대상 = 바탕 / "발명후보_원장.md"
    후보들 = candidates.읽기(바탕)
    쓰기(대상, candidates.원장보고서(
        바탕, 후보들,
        {하나.get("코드"): candidates.근거모으기(바탕, 하나) for 하나 in 후보들}))
    print(f"  {한건['코드']} → {한건['등급']} ({한건['판단일']}) · 원장 {대상.name}")


def _포트폴리오(바탕: Path) -> None:
    from . import ir as 포트

    결과 = 포트.만들기(바탕)
    if not 결과["건수"]:
        print("  출원건을 찾지 못했다.")
        return
    print(f"  건별 등록성 분석 {결과['건수']}건 · {결과['포트폴리오'].name}")
    print(f"  브라우저로 연다 — {결과['포트폴리오']}")
    try:
        import webbrowser
        webbrowser.open(결과["포트폴리오"].as_uri())
    except OSError:
        pass


항목들 = [
    ("1", "웹 메인보드 열기 (브라우저에서 전체를 다룬다)", _메인보드),
    ("2", "출원건 현황 한눈에 보기", _현황),
    ("3", "새 출원건 폴더 만들기", _새출원건),
    ("4", "검사하기", _검사),
    ("5", "제출본 만들기", _제출본),
    ("6", "도면 초안 만들기 (명세서에서 SVG)", _도면초안),
    ("7", "도면 그리기 (SVG → PNG)", _도면),
    ("8", "관청 서식(DOCX) 만들기", _서식),
    ("9", "단락번호 다시 매기기", _번호),
    ("10", "선행기술 조사 결과 보기", _선행기술),
    ("11", "인용문헌 대비표 만들기 (청구항·전문)", _대비표),
    ("12", "공개 증거 받아 두기 (공지예외 대비)", _공개증거),
    ("13", "청구항·제품 소스 대조", _구현대조),
    ("14", "변리사 검토 초안·종합보고서 만들기", _검토초안),
    ("15", "발명 후보 원장 (등급은 사람이 매긴다)", _후보원장),
    ("16", "IR 포트폴리오·등록성 분석 만들기", _포트폴리오),
    ("17", "실행 환경 점검", _환경),
    ("18", "이 컴퓨터에 설치 (바탕화면 아이콘 만들기)", _설치),
]


def 실행(바탕=None) -> int:
    바탕 = Path(바탕 or Path.cwd())
    print()
    print(줄)
    print(f"  특허 자동화 킷 {__version__}")
    print("  명세서 검사 · 제출본 생성 · 관청 서식 생성")
    print(줄)
    print(f"  기준 폴더 — {바탕}")

    while True:
        print()
        for 번호, 이름, _함수 in 항목들:
            print(f"  {번호}. {이름}")
        print("  0. 나가기")
        답 = 묻기("\n  번호 > ")
        if 답 in ("0", "q", "Q"):
            print("\n  마친다.")
            return 0
        if not 답:                      # 그냥 Enter 를 눌러도 창이 닫히지 않는다
            continue
        고른것 = next((함수 for 번호, _이름, 함수 in 항목들 if 번호 == 답), None)
        if 고른것 is None:
            print("  없는 번호다.")
            continue
        print()
        print(줄)
        try:
            고른것(바탕)
        except KeyboardInterrupt:
            print("\n  그만둔다.")
        except Exception as 문제:                     # 화면이 닫히지 않게 잡아 둔다
            print(f"  뜻밖의 문제 — {문제.__class__.__name__}: {문제}")
        print(줄)
