# -*- coding: utf-8 -*-
"""청구항 ↔ 제품 소스 대조.

명세서에 적은 구성이 제품에 실제로 있는지 파일·행 단위로 확인한다. 뒷받침이
없는 구성은 출원 전에 빼야 하고, 한 번 확인한 뒤 소스가 바뀌면 다시 봐야 한다.

대조표는 `_근거자료/구현대조.json` 에 둔다.

  [
    {"claim": 1,
     "구성요소": "구간 산출부의 하한·상한·구간 폭",
     "소스": [{"file": "app/engine/interval.py", "lines": "223-245"}],
     "지문": "…",            ← 확인한 그때의 내용 지문. 킷이 채운다
     "확인": "2026-08-24"}
  ]

지문은 그 행 범위의 내용을 줄인 값이다. 소스가 바뀌면 지문이 달라지므로
「그때는 맞았으나 지금은 다르다」를 가려낼 수 있다.
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import date
from pathlib import Path

대조파일 = "구현대조.json"

확인됨 = "구현 확인"
바뀜 = "소스 바뀜"
행벗어남 = "행 범위 벗어남"
파일없음 = "파일 없음"
미확인 = "지문 없음"


def 소스뿌리찾기(자리: Path, 설정본):
    """설정의 source_root 를 실제 폴더로 푼다. 상대 경로는 출원건 기준이다.

    「.」 을 주면 출원건 폴더 자신이다 — 배포 소스가 이 PC 에 없어도, 프로젝트에
    동봉된 참조 구현·실측 스크립트와 대조할 수 있게 한다.
    """
    값 = (설정본.값("trace", "source_root", 기본="") or "").strip()
    if not 값:
        return None
    길 = Path(값)
    return 길 if 길.is_absolute() else (Path(자리) / 길)


def 대조표경로(출원건: Path) -> Path:
    return Path(출원건) / "_근거자료" / 대조파일


def 읽기(출원건: Path) -> list:
    자리 = 대조표경로(출원건)
    if not 자리.exists():
        return []
    자료 = json.loads(자리.read_text(encoding="utf-8-sig"))
    return 자료 if isinstance(자료, list) else []


def 쓰기(출원건: Path, 줄들: list) -> Path:
    자리 = 대조표경로(출원건)
    자리.parent.mkdir(parents=True, exist_ok=True)
    자리.write_text(json.dumps(줄들, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    return 자리


def _한정문언(본문: str) -> str:
    """종속항에서 인용 전제부를 걷어 내고 더한 한정만 남긴다."""
    글 = re.sub(r"^#{1,6}[^\n]*\n", "", (본문 or "").strip())
    글 = re.sub(r"^\s*제\s*[\d항제및내지,~\-\s]*항에\s*있어서\s*[,،]?\s*", "", 글)
    글 = " ".join(글.split())
    if not 글:
        return "★이 청구항의 핵심 구성을 한 줄로 적는다"
    return 글[:70] + ("…" if len(글) > 70 else "")


def 뼈대만들기(출원건: Path, 청구항들) -> Path:
    """청구항마다 줄을 만든다.

    구성요소 칸은 비워 두지 아니하고 청구항 문언에서 뽑은 이름을 그대로 넣는다.
    사람이 채울 것은 소스의 파일과 행뿐이다. 독립항은 구성요소마다 한 줄씩
    나누어, 어느 구성이 구현되지 아니했는지 구성 단위로 드러나게 한다.
    """
    from .compare import 구성요소쪼개기

    이미 = {(줄.get("claim"), 줄.get("구성요소")) for 줄 in 읽기(출원건)}
    줄들 = 읽기(출원건)
    본이름 = {줄.get("claim") for 줄 in 줄들}

    def 더하기(번호, 이름):
        if (번호, 이름) in 이미:
            return
        줄들.append({
            "claim": 번호, "구성요소": 이름,
            "소스": [{"file": "★app/engine/….py", "lines": "★1-10"}],
            "지문": "", "확인": "",
        })

    for 항 in 청구항들:
        if 항.번호 in 본이름:
            continue
        요소들 = 구성요소쪼개기(항.본문) if 항.독립항 else []
        if 요소들:
            for 요소 in 요소들:
                더하기(항.번호, 요소["축"])
        else:
            더하기(항.번호, _한정문언(항.본문))
    줄들.sort(key=lambda 줄: (줄.get("claim") or 0))
    return 쓰기(출원건, 줄들)


def 행뽑기(파일: Path, 범위: str):
    """「223-245」 또는 「223」 형태의 행 범위를 읽어 온다."""
    숫자 = [int(값) for 값 in re.findall(r"\d+", 범위 or "")]
    if not 숫자:
        return None, "행 범위를 읽지 못했다"
    처음 = 숫자[0]
    끝 = 숫자[1] if len(숫자) > 1 else 처음
    if 끝 < 처음:
        처음, 끝 = 끝, 처음
    try:
        모든행 = 파일.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as 문제:
        return None, str(문제)
    if 처음 < 1 or 끝 > len(모든행):
        return None, f"파일은 {len(모든행)}행인데 {처음}~{끝}행을 가리킨다"
    return 모든행[처음 - 1:끝], ""


def 지문(행들) -> str:
    """행 내용을 줄여 한 값으로 만든다. 여백 차이는 무시한다."""
    다듬은것 = "\n".join(줄.strip() for 줄 in 행들 if 줄.strip())
    return hashlib.sha256(다듬은것.encode("utf-8")).hexdigest()[:16]


def 검증(출원건: Path, 소스뿌리: Path, 지문갱신: bool = False) -> dict:
    """대조표의 모든 줄을 확인한다."""
    출원건 = Path(출원건)
    소스뿌리 = Path(소스뿌리)
    줄들 = 읽기(출원건)
    결과 = []

    for 줄 in 줄들:
        칸들 = []
        for 자리 in 줄.get("소스", []):
            파일이름 = (자리.get("file") or "").strip()
            범위 = (자리.get("lines") or "").strip()
            파일 = 소스뿌리 / 파일이름
            if "★" in 파일이름 or not 파일이름:
                칸들.append({"file": 파일이름, "lines": 범위, "판정": 미확인,
                            "말": "아직 채우지 않았다"})
                continue
            if not 파일.exists():
                칸들.append({"file": 파일이름, "lines": 범위, "판정": 파일없음,
                            "말": f"{파일} 가 없다"})
                continue
            행들, 잘못 = 행뽑기(파일, 범위)
            if 행들 is None:
                칸들.append({"file": 파일이름, "lines": 범위, "판정": 행벗어남, "말": 잘못})
                continue
            지금지문 = 지문(행들)
            적힌지문 = (자리.get("지문") or 줄.get("지문") or "").strip()
            if not 적힌지문:
                칸들.append({"file": 파일이름, "lines": 범위, "판정": 미확인,
                            "말": "지문을 아직 남기지 않았다", "지문": 지금지문})
            elif 지금지문 == 적힌지문:
                칸들.append({"file": 파일이름, "lines": 범위, "판정": 확인됨,
                            "말": "", "지문": 지금지문})
            else:
                칸들.append({"file": 파일이름, "lines": 범위, "판정": 바뀜,
                            "말": f"확인 당시 {적힌지문} → 지금 {지금지문}", "지문": 지금지문})
        결과.append({"claim": 줄.get("claim"), "구성요소": 줄.get("구성요소", ""),
                    "확인": 줄.get("확인", ""), "칸": 칸들})

    if 지문갱신:
        _지문쓰기(출원건, 줄들, 결과)
        # 새로 남긴 지문이 반영된 상태를 보여 준다. 한 번만 다시 본다.
        return 검증(출원건, 소스뿌리, 지문갱신=False)

    셈 = {}
    for 한줄 in 결과:
        for 칸 in 한줄["칸"]:
            셈[칸["판정"]] = 셈.get(칸["판정"], 0) + 1
    return {"줄": 결과, "셈": 셈, "소스뿌리": str(소스뿌리),
            "대조표": str(대조표경로(출원건))}


def _지문쓰기(출원건: Path, 줄들: list, 결과: list) -> None:
    """지금 소스의 지문을 대조표에 적어 둔다. 이 시점을 「확인한 때」로 삼는다."""
    for 원본, 본것 in zip(줄들, 결과):
        for 자리, 칸 in zip(원본.get("소스", []), 본것["칸"]):
            if 칸.get("지문"):
                자리["지문"] = 칸["지문"]
        if any(칸.get("지문") for 칸 in 본것["칸"]):
            원본["확인"] = str(date.today())
        원본.pop("지문", None)
    쓰기(출원건, 줄들)


def 보고서(결과: dict, 이름: str = "") -> str:
    셈 = 결과["셈"]
    줄들 = [f"# 청구항 구현 대조{' — ' + 이름 if 이름 else ''}", "",
           f"작성 {date.today()} · 소스 기준 {결과['소스뿌리']}", "",
           "○ 청구항의 구성이 제품 소스의 어느 파일 몇 행에 있는지 대조한 결과다. "
           "뒷받침이 없는 구성은 출원 전에 빼거나 구현한다.", "",
           "| 판정 | 건수 |", "| --- | --- |"]
    for 이름값 in (확인됨, 바뀜, 행벗어남, 파일없음, 미확인):
        if 셈.get(이름값):
            줄들.append(f"| {이름값} | {셈[이름값]} |")
    if not 셈:
        줄들.append("| 대조표가 비어 있다 | 0 |")
    줄들 += ["", "---", "", "## 청구항별 대조", "",
            "| 청구항 | 구성요소 | 소스 근거 | 판정 | 비고 |",
            "| --- | --- | --- | --- | --- |"]
    for 한줄 in 결과["줄"]:
        if not 한줄["칸"]:
            줄들.append(f"| {한줄['claim']} | {_자르기(한줄['구성요소'], 40)} | - | {미확인} | 소스를 적지 않았다 |")
        for i, 칸 in enumerate(한줄["칸"]):
            줄들.append(
                f"| {한줄['claim'] if i == 0 else ''} | "
                f"{_자르기(한줄['구성요소'], 40) if i == 0 else ''} | "
                f"`{칸['file']}` {칸['lines']}행 | {칸['판정']} | {_자르기(칸.get('말', ''), 40)} |")
    줄들 += ["", "○ 「소스 바뀜」은 확인한 뒤 그 행의 내용이 달라졌다는 뜻이다. "
            "구성이 그대로인지 다시 보고, 그대로면 --update 로 지문을 새로 남긴다.", ""]
    return "\n".join(줄들)


def _자르기(글: str, 길이: int) -> str:
    글 = (글 or "").replace("|", "\\|").strip()
    return 글 if len(글) <= 길이 else 글[:길이 - 1] + "…"
