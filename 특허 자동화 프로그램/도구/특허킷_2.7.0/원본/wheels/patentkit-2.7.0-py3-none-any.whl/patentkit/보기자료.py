# -*- coding: utf-8 -*-
"""메인보드 화면에 그대로 뿌릴 자료를 만든다.

보고서는 사람이 읽는 글이고, 이 자료는 화면이 표로 그릴 값이다. 같은 계산을
두 번 하지 아니하도록 계산은 각 꾸러미에 두고 여기서는 화면이 쓰기 좋은 모양으로
추려 담기만 한다.

설정값 고치기도 여기서 다룬다. 사람이 확정해야 하는 값(발명자·사업자등록번호 등)을
브라우저에서 바로 채울 수 있어야 「검사 → 서식 생성」이 한 화면에서 끝나기 때문이다.
아무 칸이나 고치게 두지 아니하고, 아래 허용목록에 있는 칸만 고친다.
"""
from __future__ import annotations

import json
from pathlib import Path

from . import compare, config, doc, evidence, prior_art, trace

# 브라우저에서 고칠 수 있는 칸. 이 밖의 값은 파일을 직접 고친다.
고칠수있는칸 = {
    "invention.title_en": "발명의 명칭(영문)",
    "invention.tech_field": "기술 분야",
    "applicants.0.name": "출원인",
    "applicants.0.biz_no": "사업자등록번호",
    "applicants.0.customer_no": "특허고객번호",
    "applicants.0.representative": "대표자",
    "inventors.0.name": "발명자",
    "inventors.0.org": "발명자 소속",
    "inventors.0.position": "발명자 직위",
    "inventors.0.share_pct": "발명자 지분(%)",
    "inventors.0.contact": "발명자 연락처",
    "filing.kind": "출원 종류",
    "filing.fee_reduction": "수수료 감면",
    "filing.disclosure_exception.claimed": "공지예외 주장",
    "filing.disclosure_exception.date": "최초 공개일",
    "filing.disclosure_exception.medium": "공개 매체",
    "filing.priority_deadline": "우선일 마감",
    "trace.source_root": "제품 소스 폴더",
    "prior_art.kipris_key": "KIPRIS 서비스 열쇠",
}

# 화면에 값을 그대로 비추지 아니할 칸. 열쇠는 어깨너머로도 새어 나간다.
가릴칸 = {"prior_art.kipris_key"}

숫자칸 = {"inventors.0.share_pct"}
참거짓칸 = {"filing.disclosure_exception.claimed"}


def _청구범위(자리: Path, 설정본):
    청구경로 = doc.청구범위찾기(자리, 설정본) or doc.명세서찾기(자리, 설정본)
    return doc.읽어들이기(청구경로) if 청구경로 else None


# ── 선행기술 ────────────────────────────────────────────────────
def 선행기술(자리: Path, 설정본, 상위: int = 25) -> dict:
    자료폴더 = [자리 / "_원본자료", 자리.parent / "_원본자료"]
    문헌들 = prior_art.모아읽기(자료폴더)
    if not 문헌들:
        return {"있음": False, "찾아본곳": [str(한곳) for 한곳 in 자료폴더],
                "문헌수": 0, "묶음": {}, "목록": [], "낱말": []}
    결과 = prior_art.조사(설정본, 자료폴더, None, _청구범위(자리, 설정본), 상위)
    묶음수 = {이름: len(줄들) for 이름, 줄들 in 결과["묶음"].items()}
    목록 = []
    for 줄 in 결과["전체"][:상위]:
        한건 = 줄["문헌"]
        목록.append({
            "겹침": 줄["점수"], "지위": 줄["지위"],
            "낱말": 줄["맞은낱말"][:6],
            "출원번호": 한건.appno, "공개번호": 한건.pubnum,
            "명칭": 한건.title, "출원인": 한건.assignee,
            "출원일": 한건.app_date, "공개일": str(한건.공개일 or ""),
            "url": 한건.url, "요지": (한건.snippet or "")[:220],
        })
    return {"있음": True, "찾아본곳": [str(한곳) for 한곳 in 자료폴더],
            "문헌수": 결과["문헌수"], "묶음": 묶음수, "목록": 목록,
            "낱말": 결과["낱말"][:20], "기준일": str(결과["우리출원일"])}


# ── 인용문헌 대비 ───────────────────────────────────────────────
def 대비(자리: Path, 설정본) -> dict:
    문헌들 = compare.목록읽기(자리)
    답 = {"목록있음": bool(문헌들), "문헌수": len(문헌들), "청구항대비": [],
         "목록": [], "용어표": {"문헌": [], "줄": []}, "빠진것": []}
    if not 문헌들:
        답["빠진것"].append("대비할 문헌을 아직 적지 아니했다")
        return 답
    def _채웠나(값) -> bool:
        """★ 로 시작하는 값은 아직 사람이 채우지 아니한 자리다."""
        글 = str(값 or "").strip()
        return bool(글) and not 글.startswith("★")

    for 문헌 in 문헌들:
        번호 = 문헌.get("번호") or "이름 없음"
        답["목록"].append({
            "번호": 번호.lstrip("★"), "미기재": 번호.startswith("★"),
            "명칭": 문헌.get("명칭", ""), "서지": 문헌.get("서지", ""),
            "종류": 문헌.get("종류", "선행문헌"),
            "출처": 문헌.get("출처", ""),
            "겹친낱말": 문헌.get("겹친낱말", []),
            "청구항있음": _채웠나(문헌.get("청구항")) or _채웠나(문헌.get("청구항파일")),
            "전문있음": _채웠나(문헌.get("전문파일")),
            "청구항출처": 문헌.get("청구항출처", ""),
            "청구항받은때": 문헌.get("청구항받은때", ""),
            "법적상태": 문헌.get("법적상태", ""),
            "비고": 문헌.get("비고", ""),
        })

    청구범위 = _청구범위(자리, 설정본)
    독립항들 = [항 for 항 in (청구범위.청구항들 if 청구범위 else []) if 항.독립항]
    뿌리들 = [자리, 자리 / "_근거자료", 자리 / "_원본자료", 자리.parent,
            자리.parent / "_원본자료"]
    전문모음 = {}
    for 문헌 in 문헌들:
        이름 = (문헌.get("번호") or "이름 없음").lstrip("★")
        try:
            상대청구, 상대전문 = compare.문헌글(문헌, 뿌리들)
        except (RuntimeError, FileNotFoundError) as 문제:
            답["빠진것"].append(f"{이름} — 읽지 못했다: {문제}")
            continue
        if 상대전문:
            전문모음[이름] = 상대전문
        if not 상대청구:
            if 문헌.get("종류") != "확대선원":
                답["빠진것"].append(f"{이름} — 청구항 전문을 아직 넣지 아니했다")
            continue
        if not 독립항들:
            답["빠진것"].append("우리 독립항을 찾지 못했다")
            break
        결과 = compare.청구항대비(독립항들[0], 상대청구)
        답["청구항대비"].append({
            "번호": 이름, "서지": 문헌.get("서지", ""), "종류": 문헌.get("종류", ""),
            "대조못함": 결과["대조못함"],
            "줄": [{"축": 줄["축"], "우리": 줄["우리"], "상대": 줄["상대"],
                  "겹침": 줄["겹침"], "낱말": 줄["낱말"][:5],
                  "대응있음": 줄["대응있음"]} for 줄 in 결과["줄"]],
        })

    if 전문모음:
        묶음 = compare.용어그룹풀기(설정본.값("compare", "terms", 기본=[])) \
            or compare.용어자동뽑기(청구범위)
        대조 = compare.전문대조(묶음, 전문모음)
        답["용어표"] = {
            "문헌": 대조["문헌"],
            "줄": [{"이름": 칸["이름"], "용어": 칸["용어"],
                  "값": {문헌이름: 칸["문헌별"][문헌이름]["셈"] for 문헌이름 in 대조["문헌"]},
                  "보기": {문헌이름: 칸["문헌별"][문헌이름]["보기"] for 문헌이름 in 대조["문헌"]}}
                 for 칸 in 대조["표"]],
        }
    return 답


# ── 구현 대조 ───────────────────────────────────────────────────
def 구현(자리: Path, 설정본) -> dict:
    줄들 = trace.읽기(자리)
    뿌리 = trace.소스뿌리찾기(자리, 설정본)
    소스뿌리 = str(뿌리) if 뿌리 else ""
    답 = {"표있음": bool(줄들), "줄수": len(줄들), "소스뿌리": 소스뿌리,
         "소스있음": bool(뿌리) and 뿌리.exists(),
         "셈": {}, "줄": []}
    if not 줄들 or not 답["소스있음"]:
        답["줄"] = [{"claim": 한줄.get("claim"), "구성요소": 한줄.get("구성요소", ""),
                   "칸": [{"file": 자리값.get("file", ""), "lines": 자리값.get("lines", ""),
                         "판정": trace.미확인, "말": "제품 소스 폴더를 알려 주면 확인한다"}
                        for 자리값 in 한줄.get("소스", [])]}
                  for 한줄 in 줄들]
        return 답
    결과 = trace.검증(자리, 뿌리)
    답["셈"] = 결과["셈"]
    답["줄"] = 결과["줄"]
    return 답


# ── 공개 증거 ───────────────────────────────────────────────────
def 증거폴더찾기(자리: Path) -> Path:
    """받아 둘 자리. 이미 받아 둔 캡처 폴더가 있으면 그것을 먼저 쓴다.

    팀이 킷보다 먼저 만들어 둔 「공개증거_20260821」 같은 폴더도 찾는다. 증거는
    받은 시각이 값이므로, 이미 있는 것을 못 본 체하고 다시 받게 하면 안 된다.
    """
    기본 = 자리 / "_원본자료" / "공개증거"
    if 기본.exists():
        return 기본
    for 어미 in (자리 / "_원본자료", 자리.parent / "_원본자료"):
        if not 어미.is_dir():
            continue
        있는것 = sorted((한곳 for 한곳 in 어미.glob("공개증거*") if 한곳.is_dir()),
                    reverse=True)
        if 있는것:
            return 있는것[0]
    return 기본


def 증거(자리: Path) -> dict:
    대상 = 증거폴더찾기(자리)
    기록들 = evidence.대장읽기(대상)
    return {
        "폴더": str(대상), "폴더이름": 대상.name, "기록수": len(기록들),
        "기록": [{"주소": 한건.get("주소", ""), "받은때": 한건.get("받은때", ""),
                "주소확인": 한건.get("주소확인", True),
                "상태": 한건.get("상태", 0), "접근통제": 한건.get("접근통제", ""),
                "크기": 한건.get("크기", 0), "제목": 한건.get("제목", ""),
                "비고": 한건.get("비고", ""),
                "문제": 한건.get("문제", "")} for 한건 in 기록들],
        "열린것": sum(1 for 한건 in 기록들 if 한건.get("상태") == 200),
        "막힌것": sum(1 for 한건 in 기록들 if 한건.get("상태") in (401, 403)),
    }


# ── 설정값 ──────────────────────────────────────────────────────
def _파고들기(자료, 경로: str):
    현재 = 자료
    for 조각 in 경로.split("."):
        if isinstance(현재, list):
            차례 = int(조각)
            if 차례 >= len(현재):
                return None
            현재 = 현재[차례]
        elif isinstance(현재, dict):
            if 조각 not in 현재:
                return None
            현재 = 현재[조각]
        else:
            return None
    return 현재


def _심어넣기(자료, 경로: str, 값) -> None:
    조각들 = 경로.split(".")
    현재 = 자료
    for 차례, 조각 in enumerate(조각들[:-1]):
        다음 = 조각들[차례 + 1]
        if isinstance(현재, list):
            자리번호 = int(조각)
            while len(현재) <= 자리번호:
                현재.append({})
            if 현재[자리번호] is None:
                현재[자리번호] = {}
            현재 = 현재[자리번호]
        else:
            if 조각 not in 현재 or 현재[조각] is None:
                현재[조각] = [] if 다음.isdigit() else {}
            현재 = 현재[조각]
    끝 = 조각들[-1]
    if isinstance(현재, list):
        자리번호 = int(끝)
        while len(현재) <= 자리번호:
            현재.append({})
        현재[자리번호] = 값
    else:
        현재[끝] = 값


def 설정보기(자리: Path, 설정본) -> dict:
    자료 = 설정본.자료
    칸들 = []
    for 경로, 이름 in 고칠수있는칸.items():
        값 = _파고들기(자료, 경로)
        가림 = 경로 in 가릴칸
        보일값 = "" if 값 is None else 값
        if 가림 and isinstance(보일값, str) and 보일값 and not 보일값.startswith("★"):
            보일값 = ""                       # 저장된 열쇠는 화면으로 내보내지 아니한다
        칸들.append({
            "경로": 경로, "이름": 이름,
            "값": 보일값,
            "가림": 가림,
            "채워짐": bool(str(값 or "").strip()) and not str(값).startswith("★"),
            "미확정": isinstance(값, str) and 값.strip().startswith("★"),
            "갈래": ("참거짓" if 경로 in 참거짓칸 else
                   "숫자" if 경로 in 숫자칸 else "글"),
        })
    from . import kipris

    return {
        "파일": str((설정본.경로파일 or (자리 / "patent_config.json")).name),
        "명칭": 설정본.명칭,
        "열쇠": {**kipris.열쇠상태(설정본),
               "출처": [{"이름": 이름, "주소": 주소} for 이름, 주소 in kipris.발급출처],
               "확인일": kipris.확인일},
        "ipc": 설정본.값("ipc", 기본=[]),
        "칸": 칸들,
        "미확정": [{"자리": 한자리, "값": 값} for 한자리, 값 in 설정본.미확정값()],
    }


def 설정고치기(자리: Path, 바꿀것: dict) -> dict:
    """허용된 칸만 고친다. IPC 는 쉼표로 나눈 글로 받는다."""
    설정본 = config.불러오기(자리)
    자료 = json.loads(json.dumps(설정본.자료, ensure_ascii=False))
    고친것 = []

    for 경로, 값 in (바꿀것 or {}).items():
        if 경로 == "ipc":
            조각들 = [조각.strip() for 조각 in str(값).replace("\n", ",").split(",")]
            자료["ipc"] = [조각 for 조각 in 조각들 if 조각]
            고친것.append("IPC")
            continue
        if 경로 not in 고칠수있는칸:
            raise ValueError(f"이 칸은 브라우저에서 고칠 수 없다: {경로}")
        if 경로 in 참거짓칸:
            값 = bool(값)
        elif 경로 in 숫자칸:
            값 = None if 값 in ("", None) else float(값)
            if 값 is not None and 값 == int(값):
                값 = int(값)
        else:
            값 = "" if 값 is None else str(값).strip()
        if 경로 in 가릴칸 and 값 == "":
            continue          # 화면은 가린 칸을 빈 채로 보낸다. 빈 값으로 지우지 아니한다
        _심어넣기(자료, 경로, 값)
        고친것.append(고칠수있는칸[경로])

    새설정 = config.설정(자료, 설정본.경로파일, 자리)
    config.저장하기(새설정, 자리 / "patent_config.json")
    다시 = config.불러오기(자리)
    return {"고친것": 고친것, "설정": 설정보기(자리, 다시),
            "남은미확정": len(다시.미확정값())}
