# -*- coding: utf-8 -*-
"""웹 메인보드 — 브라우저에서 출원 준비 전체를 본다.

  특허킷 web            내 컴퓨터에서만 열리는 화면을 띄운다

표준 라이브러리의 http.server 만 쓴다. 설치할 것이 늘지 아니하고, 실행 파일로
구워도 그대로 돈다.

**바깥에서는 열리지 아니한다.** 127.0.0.1 에만 붙이고, 매번 새로 만든 열쇠를 지닌
주소로만 답한다. 이 화면은 파일을 고치고 프로그램을 실행하므로, 같은 망의 다른
사람이 열 수 있으면 안 되기 때문이다. 읽고 쓰는 파일도 프로젝트 폴더 안으로 막는다.
"""
from __future__ import annotations

import json
import mimetypes
import secrets
import socket
import threading
import traceback
import urllib.parse
import webbrowser
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import (build as 제출본, candidates, compare, config, doc, docxout, dossier,
               drawings, evidence, figures, prior_art, rules, sources, trace)
from . import 보기자료
from .config import 남은날
from .util import 쓰기, 읽기

화면파일 = Path(__file__).resolve().parent / "자료" / "dashboard.html"
읽어도되는꼬리 = {".md", ".json", ".txt", ".svg", ".png", ".html", ".docx"}


class 살림:
    """서버가 들고 있는 것. 프로젝트 뿌리와 열쇠."""

    def __init__(self, 뿌리: Path, 열쇠: str):
        self.뿌리 = Path(뿌리).resolve()
        self.열쇠 = 열쇠
        self.기록 = []            # 최근 실행 기록
        self.바깥에열림 = False    # 사내망에 열어 두었는가
        self.찾아온곳 = {}         # 이 PC 밖에서 들어온 주소별 횟수

    def 남기기(self, 작업: str, 대상: str, 결과: str, 어디서: str = "") -> None:
        한줄 = {"때": _시각(), "작업": 작업, "대상": 대상, "결과": 결과}
        if 어디서:
            한줄["어디서"] = 어디서
        self.기록.insert(0, 한줄)
        del self.기록[40:]

    def 손님왔다(self, 주소: str) -> None:
        """이 PC 밖에서 들어온 주소를 센다. 누가 썼는지 화면에 보이게 한다."""
        if not 주소 or 주소.startswith("127."):
            return
        처음인가 = 주소 not in self.찾아온곳
        self.찾아온곳[주소] = self.찾아온곳.get(주소, 0) + 1
        if 처음인가:
            self.남기기("접속", 주소, "다른 PC 에서 처음 열었다", 주소)


def 출원건인가(폴더: Path) -> bool:
    return (폴더 / "patent_config.json").exists() or (폴더 / "01_명세서.md").exists()


def 출원건모으기(뿌리: Path) -> list:
    뿌리 = Path(뿌리)
    if 출원건인가(뿌리):
        return [뿌리]
    try:
        return sorted(자리 for 자리 in 뿌리.iterdir()
                      if 자리.is_dir() and 출원건인가(자리))
    except OSError:
        return []


# ── 상태 모으기 ─────────────────────────────────────────────────
def 한건상태(폴더: Path, 자세히: bool = False) -> dict:
    설정본 = config.불러오기(폴더)
    검사 = rules.검사(폴더, 설정본)
    수치 = 검사.수치
    기한 = 설정본.공지예외기한()
    우선 = 설정본.우선일기한()

    산출물 = {}
    for 보일이름, 상대 in (
        ("제출본", 설정본.경로("submission_md", "03_제출본_명세서_청구범위.md")),
        ("선행기술조사", "_근거자료/선행기술조사.md"),
        ("청구항대비", "_근거자료/선행문헌_청구항대비.md"),
        ("전문대비", "_근거자료/확대선원_전문대비.md"),
        ("구현대조", "_근거자료/구현대조.md"),
        ("검토초안", "_근거자료/04_변리사_검토사항_초안.md"),
    ):
        자리 = 폴더 / 상대
        산출물[보일이름] = {"있음": 자리.exists(), "경로": str(자리.relative_to(폴더))}

    도면폴더 = 폴더 / (설정본.경로("drawings_dir", "도면") or "도면")
    그림들 = sorted(자리.name for 자리 in 도면폴더.glob("*.png")) if 도면폴더.exists() else []

    한건 = {
        "이름": 폴더.name,
        "명칭": 설정본.명칭,
        "기술분야": 설정본.값("invention", "tech_field", 기본="") or "",
        "오류": 검사.오류수, "경고": 검사.경고수, "통과": len(검사.통과항목),
        "단락": 수치.get("단락범위", "-"), "단락수": 수치.get("단락수", 0),
        "청구항수": 수치.get("청구항수", 0), "독립항": 수치.get("독립항", "-"),
        "도면수": 수치.get("도면수", 0),
        "출원가능": 검사.오류수 == 0,
        "미확정": [{"자리": 자리, "값": 값} for 자리, 값 in 설정본.미확정값()],
        "공지예외기한": str(기한) if 기한 else "",
        "공지예외남은날": 남은날(기한) if 기한 else None,
        "우선일기한": str(우선) if 우선 else "",
        "우선일남은날": 남은날(우선) if 우선 else None,
        "산출물": 산출물, "도면": 그림들, "도면폴더": 도면폴더.name,
    }
    항목들 = _준비항목(폴더, 설정본, 검사, 산출물, 그림들)
    한건["준비항목"] = 항목들
    한건["진행"] = _진행률(항목들)
    if 자세히:
        한건["지적"] = [{"등급": 건.등급, "항목": 건.항목, "규칙": 건.규칙,
                      "내용": 건.내용, "파일": 건.파일, "행": 건.행}
                     for 건 in 검사.정렬된지적()]
        한건["대비문헌"] = len(compare.목록읽기(폴더))
        한건["대조줄"] = len(trace.읽기(폴더))
        자료 = [폴더 / "_원본자료", 폴더.parent / "_원본자료"]
        한건["선행문헌수"] = len(prior_art.모아읽기(자료))
    return 한건


def _준비항목(폴더: Path, 설정본, 검사, 산출물: dict, 그림들: list) -> list:
    """준비도를 이루는 낱개 항목. 눈금 하나로 뭉개지 아니하고 왜 그 값인지 보인다.

    문서 형식과 설정값을 갈라 센다 — 형식은 킷이 이미 통과시켰는데 사람 확정 값
    두 칸 때문에 전체가 낮아 보이면, 무엇이 남았는지가 가려지기 때문이다.
    """
    from . import 등록성

    문서오류 = sum(1 for 건 in 검사.지적들
               if 건.등급 == "오류" and 건.항목 != "설정값")
    회피 = 등록성.회피논거읽기(폴더, 설정본)
    return [
        {"이름": "명세서", "됨": doc.명세서찾기(폴더, 설정본) is not None},
        {"이름": "청구범위", "됨": 검사.수치.get("청구항수", 0) > 0},
        {"이름": "문서 형식 검사", "됨": 문서오류 == 0},
        {"이름": "사람 확정 값", "됨": not 설정본.미확정값()},
        {"이름": "제출본", "됨": 산출물["제출본"]["있음"]},
        {"이름": "도면 렌더", "됨": bool(그림들)},
        {"이름": "선행기술 조사", "됨": 산출물["선행기술조사"]["있음"]},
        {"이름": "대비 문헌 목록", "됨": bool(compare.목록읽기(폴더))},
        {"이름": "회피 논거 서면", "됨": bool(회피)},
        {"이름": "구현 대조표", "됨": bool(trace.읽기(폴더))},
        {"이름": "검토 초안", "됨": 산출물["검토초안"]["있음"]},
        {"이름": "등록성 분석",
         "됨": (폴더 / "_근거자료" / "05_등록성_분석.md").exists()},
    ]


def _진행률(항목들: list) -> int:
    return round(sum(1 for 한칸 in 항목들 if 한칸["됨"]) / len(항목들) * 100)


def 전체상태(그릇: 살림) -> dict:
    폴더들 = 출원건모으기(그릇.뿌리)
    건들 = [한건상태(폴더) for 폴더 in 폴더들]
    후보들 = candidates.읽기(그릇.뿌리)
    임박 = [한건 for 한건 in 건들
          if 한건["공지예외남은날"] is not None and 한건["공지예외남은날"] <= 90]
    return {
        "뿌리": str(그릇.뿌리),
        "오늘": str(date.today()),
        "출원건": 건들,
        "후보수": len(후보들),
        "IR있음": (그릇.뿌리 / "IR_특허포트폴리오.html").exists(),
        "바깥에열림": getattr(그릇, "바깥에열림", False),
        "찾아온곳": getattr(그릇, "찾아온곳", {}),
        "요약": {
            "건수": len(건들),
            "출원가능": sum(1 for 한건 in 건들 if 한건["출원가능"]),
            "오류합": sum(한건["오류"] for 한건 in 건들),
            "경고합": sum(한건["경고"] for 한건 in 건들),
            "임박": len(임박),
        },
        "기록": 그릇.기록,
    }


# ── 작업 실행 ───────────────────────────────────────────────────
def 작업하기(그릇: 살림, 작업: str, 이름: str, 딸림: dict) -> dict:
    """화면의 단추 하나가 이 함수 한 번이다."""
    줄들 = []

    def 적기(글: str) -> None:
        줄들.append(글)

    대상들 = ([그릇.뿌리 / 이름] if 이름 else 출원건모으기(그릇.뿌리))
    대상들 = [자리 for 자리 in 대상들 if 자리.exists()]
    if 작업 not in ("report", "candidates", "ir") and not 대상들:
        return {"좋음": False, "줄": ["대상 출원건을 찾지 못했다"]}

    좋음 = True
    for 자리 in 대상들:
        설정본 = config.불러오기(자리)
        try:
            if 작업 == "validate":
                결과 = rules.검사(자리, 설정본)
                적기(f"{자리.name} — 통과 {len(결과.통과항목)} · 경고 {결과.경고수} · 오류 {결과.오류수}")
                for 건 in 결과.정렬된지적()[:8]:
                    if 건.등급 != "안내":
                        적기(f"    [{건.등급}] {건.항목}·{건.규칙} — {건.내용}")
                좋음 = 좋음 and 결과.오류수 == 0

            elif 작업 == "build":
                _대상, _변동, 말 = 제출본.실행(자리, 설정본, 조용히=True)
                적기(f"{자리.name} — {말}")

            elif 작업 == "renumber":
                from . import renumber as 번호매기기
                명세서 = doc.명세서찾기(자리, 설정본)
                미리 = 번호매기기.다시매기기(명세서, 미리보기=True)
                if 미리["바뀐수"] == 0:
                    적기(f"{자리.name} — 고칠 단락번호가 없다")
                elif 딸림.get("적용"):
                    번호매기기.다시매기기(명세서)
                    적기(f"{자리.name} — {미리['바뀐수']}개를 다시 매겼다. 원본은 _작업이력에 두었다")
                else:
                    적기(f"{자리.name} — {미리['바뀐수']}개가 바뀐다(미리보기). "
                        "적용하려면 「적용」을 켜고 다시 누른다")

            elif 작업 == "draw":
                for 이름값, 상태 in drawings.만들기(자리, 설정본, 딸림.get("덮어쓰기", False)):
                    적기(f"{자리.name} — {이름값} {상태}")

            elif 작업 == "figures":
                도면폴더 = 자리 / (설정본.경로("drawings_dir", "도면") or "도면")
                try:
                    for 이름값, 폭, 높이, 바이트 in figures.렌더(도면폴더):
                        if 폭 == 0:
                            적기(f"{자리.name} — {이름값} 를 그리지 아니했다. {바이트}")
                            좋음 = False
                            continue
                        적기(f"{자리.name} — {이름값} {폭}x{높이} {바이트 / 1024:.0f}KB")
                except FileNotFoundError:
                    적기(f"{자리.name} — 그릴 SVG 가 없다. 먼저 「도면 초안」을 누른다")

            elif 작업 == "prior-art":
                자료 = [자리 / "_원본자료", 자리.parent / "_원본자료"]
                결과 = prior_art.조사(설정본, 자료, None,
                                   _청구범위(자리, 설정본))
                if not 결과["문헌수"]:
                    적기(f"{자리.name} — 읽을 KIPRIS 결과 파일이 없다")
                    좋음 = False
                else:
                    쓰기(자리 / "_근거자료" / "선행기술조사.md",
                        prior_art.보고서(결과, f"선행기술 조사 — {자리.name}"))
                    적기(f"{자리.name} — 문헌 {결과['문헌수']}건 · 자사 선출원 "
                        f"{len(결과['묶음'][prior_art.자사선출원])}건 · 확대선원 후보 "
                        f"{len(결과['묶음'][prior_art.확대선원])}건")

            elif 작업 == "compare":
                for 한줄 in _대비하기(자리, 설정본):
                    적기(한줄)

            elif 작업 == "claims":
                for 한줄, 나쁜가 in _청구항받기(자리, 설정본, 딸림):
                    적기(한줄)
                    좋음 = 좋음 and not 나쁜가

            elif 작업 == "trace":
                for 한줄 in _대조하기(자리, 설정본, 딸림):
                    적기(한줄)

            elif 작업 == "docx":
                검사 = rules.검사(자리, 설정본, 빠르게=True)
                if 검사.오류수 and not 딸림.get("강행"):
                    적기(f"{자리.name} — 차단. 검사 오류 {검사.오류수}건을 먼저 고친다")
                    좋음 = False
                else:
                    만든것 = docxout.만들기(자리, 설정본, 강행=True, 표지=True)
                    적기(f"{자리.name} — {만든것.name}")

            elif 작업 == "evidence":
                주소들 = [한줄.strip() for 한줄 in (딸림.get("주소") or "").splitlines()
                       if 한줄.strip()]
                대상 = 보기자료.증거폴더찾기(자리)
                if 주소들:
                    for 기록 in evidence.수집(주소들, 대상):
                        뒤 = 기록["문제"] or f"{기록['크기']:,}B · 접근통제 {기록['접근통제']}"
                        적기(f"{기록['상태'] or '받지 못함'}  {기록['주소']}  {뒤}")
                기록들 = evidence.대장읽기(대상)
                if 기록들:
                    쓰기(자리 / "_원본자료" / "공개이력대장.md",
                        evidence.대장보고서(대상, 설정본))
                    적기(f"{자리.name} — 대장 {len(기록들)}건")
                else:
                    적기(f"{자리.name} — 받아 둔 기록이 없다. 주소를 넣고 다시 누른다")
                    좋음 = False
        except Exception as 문제:                    # 화면이 죽지 않게 잡는다
            적기(f"{자리.name} — 실패: {문제.__class__.__name__}: {문제}")
            좋음 = False

    if 작업 == "report":
        모음들 = [dossier.모으기(자리, config.불러오기(자리))
                for 자리 in 출원건모으기(그릇.뿌리)]
        for 모은것 in 모음들:
            쓰기(모은것["폴더"] / "_근거자료" / "04_변리사_검토사항_초안.md",
                dossier.건별초안(모은것))
        뿌리대상 = 그릇.뿌리 / "00_종합보고서.md"
        쓰기(뿌리대상, dossier.프로젝트보고서(모음들))
        적기(f"검토 초안 {len(모음들)}건 · 종합보고서 {뿌리대상.name}")

    if 작업 == "ir":
        from . import ir as 포트폴리오
        결과 = 포트폴리오.만들기(그릇.뿌리)
        적기(f"건별 등록성 분석 {결과['건수']}건 · {결과['포트폴리오'].name} 을 만들었다")
        적기("화면 위 「IR 포트폴리오 열기」 단추로 새 창에서 본다")

    if 작업 == "candidates":
        후보들 = candidates.읽기(그릇.뿌리)
        사실모음 = {한건.get("코드"): candidates.근거모으기(그릇.뿌리, 한건)
                 for 한건 in 후보들}
        쓰기(그릇.뿌리 / "발명후보_원장.md",
            candidates.원장보고서(그릇.뿌리, 후보들, 사실모음))
        적기(f"후보 {len(후보들)}건의 근거를 다시 세고 원장을 썼다")

    그릇.남기기(작업, 이름 or "전체", "좋음" if 좋음 else "볼 것 있음")
    return {"좋음": 좋음, "줄": 줄들}


def _청구범위(자리: Path, 설정본):
    청구경로 = doc.청구범위찾기(자리, 설정본) or doc.명세서찾기(자리, 설정본)
    return doc.읽어들이기(청구경로) if 청구경로 else None


def _조사결과(자리: Path, 설정본):
    """선행기술 조사를 돌려 둔 자료가 있으면 그대로 다시 계산해 돌려준다."""
    자료폴더 = [자리 / "_원본자료", 자리.parent / "_원본자료"]
    if not prior_art.모아읽기(자료폴더):
        return None
    return prior_art.조사(설정본, 자료폴더, None, _청구범위(자리, 설정본))


def _청구항받기(자리: Path, 설정본, 딸림: dict) -> list:
    """KIPRIS 에서 상대 청구항을 받아 대비문헌 목록을 채운다."""
    from . import kipris

    try:
        결과 = compare.청구항받아오기(자리, 설정본,
                               덮어쓰기=bool(딸림.get("덮어쓰기")))
    except kipris.열쇠없음 as 문제:
        return [(f"{자리.name} — {문제}", True)]
    except FileNotFoundError:
        return [(f"{자리.name} — 대비문헌 목록이 없다. 먼저 「인용문헌 대비」를 누른다", True)]

    if not 결과:
        return [(f"{자리.name} — 받아 올 문헌이 없다. "
                 "이미 청구항이 채워졌거나 출원번호가 아닌 문헌뿐이다", False)]
    줄들 = []
    for 번호, 상태, 말 in 결과:
        줄들.append((f"{자리.name} — {번호} {상태}: {말}", 상태 == "못받음"))
    받은수 = sum(1 for _번호, 상태, _말 in 결과 if 상태 == "받음")
    줄들.insert(0, (f"{자리.name} — {len(결과)}건 가운데 {받은수}건을 받았다", False))
    return 줄들


def _대비하기(자리: Path, 설정본) -> list:
    문헌들 = compare.목록읽기(자리)
    if not 문헌들:
        조사 = _조사결과(자리, 설정본)
        compare.뼈대만들기(자리, 조사)
        옮긴수 = len(compare.목록읽기(자리)) if 조사 else 0
        if 옮긴수:
            return [f"{자리.name} — 선행기술 조사에서 겹침이 큰 {옮긴수}건을 "
                    "대비문헌.json 에 옮겨 적었다. 상대 청구항 전문만 붙이고 다시 누른다"]
        return [f"{자리.name} — 대비문헌.json 뼈대를 만들었다. "
                "문헌 번호와 상대 청구항 전문을 적고 다시 누른다"]
    청구범위 = _청구범위(자리, 설정본)
    독립항들 = [항 for 항 in (청구범위.청구항들 if 청구범위 else []) if 항.독립항]
    if not 독립항들:
        return [f"{자리.name} — 독립항을 찾지 못했다"]

    뿌리들 = [자리, 자리 / "_근거자료", 자리 / "_원본자료", 자리.parent,
            자리.parent / "_원본자료"]
    청구대비, 전문모음, 말들 = [], {}, []
    for 문헌 in 문헌들:
        이름 = (문헌.get("번호") or "이름 없음").lstrip("★")
        try:
            상대청구, 상대전문 = compare.문헌글(문헌, 뿌리들)
        except (RuntimeError, FileNotFoundError) as 문제:
            말들.append(f"  {이름} — 읽지 못했다: {문제}")
            continue
        if 상대청구:
            결과 = compare.청구항대비(독립항들[0], 상대청구)
            청구대비.append({"번호": 이름, "서지": 문헌.get("서지", ""),
                          "청구항출처": 문헌.get("청구항출처", ""),
                          "청구항받은때": 문헌.get("청구항받은때", ""),
                          "줄": 결과["줄"], "대조못함": 결과["대조못함"]})
        if 상대전문:
            전문모음[이름] = 상대전문

    if 청구대비:
        쓰기(자리 / "_근거자료" / "선행문헌_청구항대비.md",
            compare.보고서_청구항(청구대비, 자리.name))
        없는축 = sum(1 for 한건 in 청구대비 if not 한건.get("대조못함")
                   for 줄 in 한건["줄"] if not 줄["대응있음"])
        못한것 = sum(1 for 한건 in 청구대비 if 한건.get("대조못함"))
        말들.append(f"{자리.name} — 청구항 대비 {len(청구대비)}건 · 대응 없음 축 {없는축}개"
                  + (f" · 언어가 달라 대조 못 한 문헌 {못한것}건" if 못한것 else ""))
    if 전문모음:
        묶음 = compare.용어그룹풀기(설정본.값("compare", "terms", 기본=[])) \
            or compare.용어자동뽑기(청구범위)
        대조 = compare.전문대조(묶음, 전문모음)
        쓰기(자리 / "_근거자료" / "확대선원_전문대비.md",
            compare.보고서_전문(대조, 자리.name))
        나온것 = sum(1 for 칸 in 대조["표"]
                   if any(정보["셈"] for 정보 in 칸["문헌별"].values()))
        말들.append(f"{자리.name} — 전문 대조 {len(전문모음)}건 · 기재 확인된 용어 {나온것}묶음")
    if not 말들:
        말들.append(f"{자리.name} — 읽을 청구항도 전문도 없다. 대비문헌.json 을 채운다")
    return 말들


def _대조하기(자리: Path, 설정본, 딸림: dict) -> list:
    if not trace.읽기(자리):
        청구범위 = _청구범위(자리, 설정본)
        if not (청구범위 and 청구범위.청구항들):
            return [f"{자리.name} — 청구항을 찾지 못했다"]
        trace.뼈대만들기(자리, 청구범위.청구항들)
        return [f"{자리.name} — 구현대조.json 뼈대를 만들었다. "
                "청구항마다 제품 소스의 파일과 행을 적고 다시 누른다"]
    손소스 = (딸림.get("소스") or "").strip()
    if 손소스:
        길 = Path(손소스)
        소스뿌리 = 길 if 길.is_absolute() else (자리 / 길)
    else:
        소스뿌리 = trace.소스뿌리찾기(자리, 설정본)
    if not 소스뿌리 or not 소스뿌리.exists():
        return [f"{자리.name} — 제품 소스 폴더를 알려 준다(설정의 trace.source_root)"]
    결과 = trace.검증(자리, 소스뿌리, 딸림.get("지문갱신", False))
    쓰기(자리 / "_근거자료" / "구현대조.md", trace.보고서(결과, 자리.name))
    센것 = " · ".join(f"{이름} {수}" for 이름, 수 in 결과["셈"].items()) or "대조표가 비었다"
    return [f"{자리.name} — {센것}"]


# ── HTTP ────────────────────────────────────────────────────────
class 손님(BaseHTTPRequestHandler):
    server_version = "patentkit"
    그릇: 살림 = None

    def log_message(self, 꼴, *인자):              # 콘솔을 조용히 둔다
        pass

    # 열쇠가 맞아야 답한다
    def _열쇠확인(self, 물음: dict) -> bool:
        준것 = (물음.get("key", [""])[0]
              or self.headers.get("X-Patentkit-Key", ""))
        맞음 = secrets.compare_digest(준것, self.그릇.열쇠)
        if 맞음:
            self.그릇.손님왔다(self.client_address[0])
        return 맞음

    def do_GET(self):
        길, _, 물음글 = self.path.partition("?")
        물음 = urllib.parse.parse_qs(물음글)
        if 길 == "/":
            열쇠 = 물음.get("key", [""])[0]
            if not secrets.compare_digest(열쇠, self.그릇.열쇠):
                return self._글답(403, "열쇠가 없거나 다르다. 프로그램이 띄운 주소로 연다.")
            return self._파일답(화면파일, "text/html; charset=utf-8")
        if not self._열쇠확인(물음):
            return self._json답({"잘못": "열쇠가 다르다"}, 403)

        try:
            if 길 == "/api/state":
                return self._json답(전체상태(self.그릇))
            if 길 == "/api/case":
                이름 = 물음.get("name", [""])[0]
                자리 = self.그릇.뿌리 / 이름
                if not 자리.exists():
                    return self._json답({"잘못": "그런 출원건이 없다"}, 404)
                return self._json답(한건상태(자리, 자세히=True))
            if 길 == "/api/file":
                return self._자료답(물음.get("path", [""])[0])
            if 길 == "/api/candidates":
                후보들 = candidates.읽기(self.그릇.뿌리)
                사실 = {한건.get("코드"): candidates.근거모으기(self.그릇.뿌리, 한건)
                      for 한건 in 후보들}
                return self._json답({"후보": 후보들, "근거": 사실,
                                   "등급": candidates.등급들, "등급뜻": candidates.등급뜻})
            if 길 == "/api/data":
                이름 = 물음.get("name", [""])[0]
                갈래 = 물음.get("kind", [""])[0]
                자리 = self.그릇.뿌리 / 이름
                if not 이름 or not 자리.exists():
                    return self._json답({"잘못": "그런 출원건이 없다"}, 404)
                설정본 = config.불러오기(자리)
                if 갈래 == "prior":
                    return self._json답(보기자료.선행기술(자리, 설정본))
                if 갈래 == "compare":
                    return self._json답(보기자료.대비(자리, 설정본))
                if 갈래 == "trace":
                    return self._json답(보기자료.구현(자리, 설정본))
                if 갈래 == "evidence":
                    return self._json답(보기자료.증거(자리))
                if 갈래 == "config":
                    return self._json답(보기자료.설정보기(자리, 설정본))
                return self._json답({"잘못": "갈래를 알 수 없다"}, 400)
            if 길 == "/api/sources":
                return self._json답({"법령": sources.근거표, "기술": sources.기술근거표,
                                   "확인일": sources.확인일})
        except Exception:
            return self._json답({"잘못": traceback.format_exc(limit=3)}, 500)
        return self._json답({"잘못": "그런 길이 없다"}, 404)

    def do_POST(self):
        길, _, 물음글 = self.path.partition("?")
        물음 = urllib.parse.parse_qs(물음글)
        if not self._열쇠확인(물음):
            return self._json답({"잘못": "열쇠가 다르다"}, 403)
        길이 = int(self.headers.get("Content-Length") or 0)
        try:
            보낸것 = json.loads(self.rfile.read(길이) or b"{}")
        except ValueError:
            return self._json답({"잘못": "보낸 값을 읽지 못했다"}, 400)

        try:
            if 길 == "/api/run":
                답 = 작업하기(self.그릇, 보낸것.get("작업", ""),
                           보낸것.get("출원건", ""), 보낸것.get("딸림", {}))
                return self._json답(답)
            if 길 == "/api/candidate":
                갈래 = 보낸것.get("갈래")
                if 갈래 == "채우기":
                    더한것 = candidates.출원건에서채우기(self.그릇.뿌리)
                    self.그릇.남기기("candidates", "전체",
                                  f"출원건에서 {len(더한것)}건을 올렸다")
                    return self._json답({"더한것": 더한것})
                if 갈래 == "더하기":
                    한건 = candidates.더하기(self.그릇.뿌리, 보낸것.get("코드", ""),
                                        보낸것.get("이름", ""), 보낸것.get("축", ""))
                elif 갈래 == "고치기":
                    한건 = candidates.고치기(self.그릇.뿌리, 보낸것.get("코드", ""),
                                        보낸것.get("바꿀것", {}))
                else:
                    return self._json답({"잘못": "갈래를 알 수 없다"}, 400)
                return self._json답({"후보": 한건})
            if 길 == "/api/claim":
                이름 = 보낸것.get("출원건", "")
                자리 = self.그릇.뿌리 / 이름
                if not 이름 or not 자리.exists():
                    return self._json답({"잘못": "그런 출원건이 없다"}, 404)
                문헌 = compare.청구항손입력(자리, 보낸것.get("번호", ""),
                                     보낸것.get("청구항", ""))
                self.그릇.남기기("claim", 이름,
                              f"{문헌['번호']} 청구항 {문헌.get('청구항수', '?')}개 손입력")
                return self._json답({"문헌": {"번호": 문헌["번호"],
                                          "청구항수": 문헌.get("청구항수", 0)}})
            if 길 == "/api/config":
                이름 = 보낸것.get("출원건", "")
                자리 = self.그릇.뿌리 / 이름
                if not 이름 or not 자리.exists():
                    return self._json답({"잘못": "그런 출원건이 없다"}, 404)
                답 = 보기자료.설정고치기(자리, 보낸것.get("바꿀것", {}))
                self.그릇.남기기("config", 이름, " · ".join(답["고친것"]) or "바뀐 것 없음")
                return self._json답(답)
            if 길 == "/api/open":
                return self._json답({"열림": _폴더열기(self.그릇.뿌리,
                                                 보낸것.get("경로", ""))})
        except (ValueError, KeyError) as 문제:
            return self._json답({"잘못": str(문제)}, 400)
        except Exception:
            return self._json답({"잘못": traceback.format_exc(limit=3)}, 500)
        return self._json답({"잘못": "그런 길이 없다"}, 404)

    # ── 답하기 ──────────────────────────────────────────────
    def _json답(self, 값, 코드: int = 200) -> None:
        몸 = json.dumps(값, ensure_ascii=False, default=str).encode("utf-8")
        self.send_response(코드)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(몸)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(몸)

    def _글답(self, 코드: int, 글: str) -> None:
        몸 = 글.encode("utf-8")
        self.send_response(코드)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(몸)))
        self.end_headers()
        self.wfile.write(몸)

    def _파일답(self, 자리: Path, 갈래: str) -> None:
        몸 = Path(자리).read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", 갈래)
        self.send_header("Content-Length", str(len(몸)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(몸)

    def _자료답(self, 상대: str) -> None:
        """프로젝트 폴더 안의 파일만 내준다. 밖으로 나가는 길은 막는다."""
        if not 상대:
            return self._json답({"잘못": "경로가 없다"}, 400)
        자리 = (self.그릇.뿌리 / 상대).resolve()
        if self.그릇.뿌리 not in 자리.parents and 자리 != self.그릇.뿌리:
            return self._json답({"잘못": "프로젝트 밖의 파일은 내주지 아니한다"}, 403)
        if not 자리.exists() or not 자리.is_file():
            return self._json답({"잘못": "그런 파일이 없다"}, 404)
        if 자리.suffix.lower() not in 읽어도되는꼬리:
            return self._json답({"잘못": "이 갈래의 파일은 내주지 아니한다"}, 403)
        if 자리.suffix.lower() in (".md", ".txt", ".json"):
            return self._json답({"경로": 상대, "글": 읽기(자리)})
        갈래 = mimetypes.guess_type(자리.name)[0] or "application/octet-stream"
        return self._파일답(자리, 갈래)


def _폴더열기(뿌리: Path, 상대: str) -> bool:
    """탐색기로 폴더를 연다. 프로젝트 밖은 열지 아니한다."""
    import subprocess
    import sys as 시스템
    자리 = (뿌리 / 상대).resolve() if 상대 else 뿌리
    if 뿌리 not in 자리.parents and 자리 != 뿌리:
        return False
    if not 자리.exists():
        return False
    try:
        if 시스템.platform == "win32":
            subprocess.Popen(["explorer", str(자리)])
        elif 시스템.platform == "darwin":
            subprocess.Popen(["open", str(자리)])
        else:
            subprocess.Popen(["xdg-open", str(자리)])
        return True
    except OSError:
        return False


def 빈자리찾기(처음: int = 8765, 끝: int = 8800) -> int:
    for 번호 in range(처음, 끝):
        with socket.socket() as 구멍:
            if 구멍.connect_ex(("127.0.0.1", 번호)) != 0:
                return 번호
    raise RuntimeError("빈 포트를 찾지 못했다")


def 프로젝트찾기(시작: Path) -> tuple:
    """출원건이 있는 폴더를 찾는다. 반환 (찾은 폴더, 찾아본 곳들).

    바탕화면 아이콘으로 띄우면 일할 폴더가 바탕화면이 된다. 거기에 출원건이
    없다고 빈 화면을 보이면 사람은 무엇이 잘못됐는지 알 수 없다. 그래서 번호로
    고르는 화면과 같은 차례로 찾아본다 — 지금 폴더 → 위 폴더 → 바탕화면 → 문서.
    """
    from .menu import 뒤진곳

    시작 = Path(시작).resolve()
    뒤진것 = 뒤진곳(시작)
    for 자리 in 뒤진것:
        if 출원건인가(자리) or 출원건모으기(자리):
            return 자리, 뒤진것
    return 시작, 뒤진것


def 이컴퓨터주소() -> str:
    """사내망에서 이 PC 를 가리키는 주소. 못 찾으면 빈 글."""
    구멍 = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        구멍.connect(("203.0.113.1", 9))   # 실제로 보내지 아니한다. 경로만 물어본다
        return 구멍.getsockname()[0]
    except OSError:
        try:
            return socket.gethostbyname(socket.gethostname())
        except OSError:
            return ""
    finally:
        구멍.close()


def 붙을자리(어디: str = "") -> str:
    """--host 값을 실제로 「붙을」 주소로 바꾼다.

      (없음)·local·localhost   127.0.0.1 — 이 PC 에서만 열린다. 기본이다.
      lan                       0.0.0.0 — 모든 갈래에 붙는다. 그래야 사내망 주소와
                                127.0.0.1 이 **함께** 열린다. 한 주소에만 붙이면
                                이 PC 에서 127.0.0.1 로 못 열게 된다.
      그 밖                     적어 준 주소 그대로.
    """
    값 = (어디 or "").strip().lower()
    if 값 in ("", "local", "localhost", "127.0.0.1"):
        return "127.0.0.1"
    if 값 in ("lan", "사내망", "network", "0.0.0.0"):
        return "0.0.0.0"
    return (어디 or "").strip()


def 보일주소(붙는곳: str) -> str:
    """다른 PC 에 알려 줄 주소. 0.0.0.0 은 주소가 아니므로 실제 주소로 바꾼다."""
    if 붙는곳 == "0.0.0.0":
        return 이컴퓨터주소() or ""
    return 붙는곳


def 바깥에열리나(주소: str) -> bool:
    """이 PC 밖에서도 닿는 자리인가."""
    return not str(주소 or "").startswith("127.")


def 띄우기(뿌리: Path, 포트: int = 0, 열기: bool = True, 조용히: bool = False,
        어디: str = "") -> int:
    if not 화면파일.exists():
        print(f"화면 파일이 없다: {화면파일}")
        return 2
    붙는곳 = 붙을자리(어디)
    바깥 = 바깥에열리나(붙는곳)
    포트 = 포트 or 빈자리찾기()
    찾은것, 뒤진것 = 프로젝트찾기(뿌리)
    그릇 = 살림(찾은것, secrets.token_urlsafe(24))
    그릇.바깥에열림 = 바깥
    손님.그릇 = 그릇
    서버 = ThreadingHTTPServer((붙는곳, 포트), 손님)
    보일곳 = 보일주소(붙는곳)
    주소 = f"http://{보일곳 or 붙는곳}:{포트}/?key={그릇.열쇠}"
    내주소 = f"http://127.0.0.1:{포트}/?key={그릇.열쇠}"

    if not 조용히:
        print()
        print("─" * 64)
        print("  특허 자동화 킷 — 웹 메인보드")
        print("─" * 64)
        print(f"  프로젝트 — {그릇.뿌리}")
        if not 출원건모으기(그릇.뿌리):
            print("  (이 폴더에서 출원건을 찾지 못했다. 찾아본 곳 —)")
            for 한곳 in 뒤진것:
                print(f"      {한곳}")
            print("  출원건 폴더를 담고 있는 폴더를 주고 다시 띄운다.")
        print(f"  주소 — {주소}")
        if 바깥:
            if 붙는곳 == "0.0.0.0" and not 보일곳:
                print("  (이 PC 의 사내망 주소를 찾지 못했다. ipconfig 로 확인해 알려 준다)")
            print(f"  이 PC 에서 — {내주소}")
            print()
            print("  ※ 지금은 같은 사내망의 다른 PC 에서도 열린다.")
            print("     주소에 붙은 열쇠를 아는 사람은 출원 자료를 읽고 작업을 실행할 수 있다.")
            print("     열쇠는 이 창을 닫으면 사라진다. 메신저 단체방에 올리지 아니한다.")
            print("     시연이 끝나면 이 창을 닫는다. 이 PC 에서만 쓰려면 --host 를 뺀다.")
        else:
            print()
            print("  이 주소는 이 컴퓨터에서만 열린다. 다른 PC 에서도 열려면 --host lan 을 준다.")
        print("  창을 닫으면 화면도 닫힌다. 멈추려면 이 창에서 Ctrl+C 를 누른다.")
        print("─" * 64, flush=True)      # 다른 곳으로 넘길 때에도 바로 보이게 한다
    if 열기:
        threading.Timer(0.6, lambda: webbrowser.open(내주소)).start()
    try:
        서버.serve_forever()
    except KeyboardInterrupt:
        if not 조용히:
            print("\n  메인보드를 닫는다.")
    finally:
        서버.server_close()
    return 0


def _시각() -> str:
    from datetime import datetime
    return datetime.now().strftime("%H:%M:%S")
