# -*- coding: utf-8 -*-
"""도면 초안 만들기 — 명세서에서 도 1 블록도와 도 2 순서도를 뽑는다.

명세서의 【부호의 설명】과 방법 청구항은 도면에 필요한 것을 이미 다 담고 있다.
부호는 상자의 이름과 번호이고, 방법 청구항의 각 단계는 흐름의 칸이다. 그래서
사람이 다시 그리지 아니하고도 초안을 뽑을 수 있다.

  도 1 블록도   100 번대를 장치의 구성부로 보고 상자로 그린다. 200·300 번대는
                바깥 장치로 보아 오른쪽에 둔다.
  도 2 순서도   방법 독립항의 단계마다 칸을 만들고 S 번호를 붙인다.

**초안이다.** 관청에 낼 도면은 사람이 보고 다듬어야 한다. 상자의 자리와 선의
흐름은 발명의 뜻을 담아야 하는데, 그것까지는 기계가 정하지 못한다.
흑백 선화로만 그린다. 특허 도면은 색을 쓰지 아니한다.
"""
from __future__ import annotations

import re
from pathlib import Path

from . import doc

글꼴 = "Malgun Gothic, Apple SD Gothic Neo, sans-serif"

화살촉 = ('<defs><marker id="a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" '
        'markerHeight="6" orient="auto"><path d="M0,0 L10,5 L0,10 z" fill="#000" '
        'stroke="none"/></marker></defs>')


def 머리(폭: int, 높이: int) -> str:
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{폭}" height="{높이}" '
            f'viewBox="0 0 {폭} {높이}">'
            f'<rect width="{폭}" height="{높이}" fill="#fff"/>'
            f'<g fill="none" stroke="#000" stroke-width="1.4" font-family="{글꼴}" '
            f'font-size="11" stroke-linejoin="round">') + 화살촉


꼬리 = "</g></svg>"


def 글자(x, y, 글, 크기=11, 자리="start", 굵게=False) -> str:
    무게 = ' font-weight="700"' if 굵게 else ""
    return (f'<text x="{x}" y="{y}" text-anchor="{자리}" stroke="none" fill="#000" '
            f'font-size="{크기}"{무게}>{_바꾸기(글)}</text>')


def 상자(x, y, 폭, 높이, 이름, 번호="", 크기=11) -> str:
    조각 = [f'<rect x="{x}" y="{y}" width="{폭}" height="{높이}"/>']
    for 차례, 줄 in enumerate(_줄나누기(이름, 폭, 크기)):
        조각.append(글자(x + 폭 / 2, y + 높이 / 2 + 4 + (차례 - (len(_줄나누기(이름, 폭, 크기)) - 1) / 2) * (크기 + 3),
                       줄, 크기, "middle"))
    if 번호:
        조각.append(글자(x + 폭 - 3, y - 4, 번호, 10, "end"))
    return "".join(조각)


def 선(x1, y1, x2, y2, 점선=False, 화살=True) -> str:
    무늬 = ' stroke-dasharray="4 3"' if 점선 else ""
    끝 = ' marker-end="url(#a)"' if 화살 else ""
    return f'<path d="M{x1},{y1} L{x2},{y2}"{무늬}{끝}/>'


# ── 부호 읽기 ───────────────────────────────────────────────────
def 부호읽기(명세서) -> list:
    """【부호의 설명】에서 (번호, 이름) 목록을 뽑는다. S 단계는 뺀다."""
    구 = 명세서.구간찾기("부호의 설명")
    if not 구:
        return []
    본문 = 구.본문(명세서.행들)
    본문 = re.sub(r"^\[\d{4}\]\s*", "", 본문.strip(), flags=re.M)
    모은것 = []
    for 조각 in re.split(r"[,、]\s*", 본문):
        맞음 = re.match(r"\s*(\d{2,4})\s*:\s*(.+)", 조각.strip())
        if 맞음:
            이름 = 맞음.group(2).strip().rstrip(".")
            이름 = re.sub(r"\s*\([^)]*\)$", "", 이름)      # 괄호 부기는 뺀다
            모은것.append((int(맞음.group(1)), 이름))
    return 모은것


def 단계읽기(청구범위) -> list:
    """방법 독립항에서 (S번호, 단계 이름) 목록을 뽑는다."""
    방법항 = None
    for 항 in (청구범위.청구항들 if 청구범위 else []):
        if "방법" in (항.말미범주 or "") and 항.본문:
            방법항 = 항
            break
    if 방법항 is None:
        return []
    from .compare import 구성요소쪼개기
    단계들 = []
    for 요소 in 구성요소쪼개기(방법항.본문):
        축 = 요소["축"]
        if 축 in ("전제부", "말미 한정") or 축.startswith("상기") and "단계" not in 축:
            continue
        이름 = 단계이름(요소["문언"])
        if 이름:
            단계들.append(이름)
    return [(f"S{(차례 + 1) * 10 + 100}", 이름) for 차례, 이름 in enumerate(단계들)]


def 단계이름(문언: str) -> str:
    """단계 칸에 넣을 짧은 이름. 「…부분 산출값을 얻는 단계」 → 「부분 산출값을 얻는」."""
    본 = 문언.strip().rstrip(";； ,.")
    본 = re.sub(r"\s*단계$", "", 본).strip()
    본 = re.sub(r"^상기\s*", "", 본)
    낱말들 = 본.split()
    if not 낱말들:
        return ""
    이름 = " ".join(낱말들[-5:])
    return 이름 if len(이름) <= 30 else " ".join(낱말들[-3:])[:30]


# ── 도 1 블록도 ─────────────────────────────────────────────────
def 블록도(명세서, 폭: int = 760) -> str:
    부호들 = 부호읽기(명세서)
    if not 부호들:
        raise ValueError("【부호의 설명】에서 부호를 찾지 못했다")

    본체번호, 본체이름 = 부호들[0]
    # 이름으로 안팎을 가른다. 「…부」는 장치 안의 구성이고, 「…장치·단말·서버·
    # 데이터베이스」는 밖에서 이어지는 것이다. 번호대로 가르면 200 번대의 구성부가
    # 밖으로 밀려 나므로 이름을 본다.
    # 번호대도 함께 본다. 본체가 100 이면 구성부는 대개 110~2xx 이고, 3xx·4xx 는
    # 다른 도면의 자료구조나 그림 요소다. 그것까지 담으면 블록도가 아니게 된다.
    바깥것 = re.compile(r"(장치|단말|서버|데이터베이스|시스템|디비|DB)$")
    본체대 = 본체번호 - (본체번호 % 100)
    구성부 = [(번호, 이름) for 번호, 이름 in 부호들[1:]
            if not 바깥것.search(이름) and 번호 < 본체대 + 200]
    바깥 = [(번호, 이름) for 번호, 이름 in 부호들[1:] if 바깥것.search(이름)][:4]

    칸너비, 칸높이, 사이 = 168, 46, 16
    줄당 = 3
    줄수 = max(1, (len(구성부) + 줄당 - 1) // 줄당)
    안쪽폭 = 줄당 * 칸너비 + (줄당 - 1) * 사이
    안쪽높이 = 줄수 * 칸높이 + (줄수 - 1) * 사이

    왼쪽, 위 = 40, 60
    테두리폭 = 안쪽폭 + 44
    테두리높이 = 안쪽높이 + 48
    바깥폭, 바깥높이, 바깥사이 = 150, 52, 26
    바깥전체 = (len(바깥) * 바깥높이 + max(0, len(바깥) - 1) * 바깥사이) if 바깥 else 0
    높이 = 위 + max(테두리높이, 바깥전체 + 20) + 40
    폭 = 왼쪽 + 테두리폭 + (바깥폭 + 60 if 바깥 else 20) + 20

    조각 = [머리(폭, 높이)]
    조각.append(글자(왼쪽, 위 - 14, f"{본체번호} {본체이름}", 12, "start", True))
    조각.append(f'<rect x="{왼쪽}" y="{위}" width="{테두리폭}" height="{테두리높이}" '
               f'stroke-dasharray="6 4"/>')

    for 차례, (번호, 이름) in enumerate(구성부):
        줄, 칸 = divmod(차례, 줄당)
        x = 왼쪽 + 22 + 칸 * (칸너비 + 사이)
        y = 위 + 26 + 줄 * (칸높이 + 사이)
        조각.append(상자(x, y, 칸너비, 칸높이, 이름, str(번호)))

    if 바깥:
        바깥x = 왼쪽 + 테두리폭 + 46
        시작y = 위 + max(0, (테두리높이 - 바깥전체) / 2)
        for 차례, (번호, 이름) in enumerate(바깥):
            y = 시작y + 차례 * (바깥높이 + 바깥사이)
            조각.append(상자(바깥x, y, 바깥폭, 바깥높이, 이름, str(번호)))
            조각.append(선(왼쪽 + 테두리폭, y + 바깥높이 / 2, 바깥x, y + 바깥높이 / 2,
                        점선=True, 화살=False))
    조각.append(꼬리)
    return "".join(조각)


# ── 도 2 순서도 ─────────────────────────────────────────────────
def 순서도(청구범위, 폭: int = 520) -> str:
    단계들 = 단계읽기(청구범위)
    if not 단계들:
        raise ValueError("방법 독립항에서 단계를 찾지 못했다")

    칸너비, 칸높이, 사이 = 320, 52, 34
    위 = 46
    높이 = 위 + len(단계들) * (칸높이 + 사이) + 20
    x = (폭 - 칸너비) / 2

    조각 = [머리(폭, 높이)]
    조각.append(글자(폭 / 2, 26, "시작", 11, "middle"))
    조각.append(선(폭 / 2, 32, 폭 / 2, 위))
    for 차례, (에스번호, 이름) in enumerate(단계들):
        y = 위 + 차례 * (칸높이 + 사이)
        조각.append(상자(x, y, 칸너비, 칸높이, 이름, 에스번호))
        다음y = y + 칸높이
        if 차례 < len(단계들) - 1:
            조각.append(선(폭 / 2, 다음y, 폭 / 2, 다음y + 사이))
        else:
            조각.append(선(폭 / 2, 다음y, 폭 / 2, 다음y + 사이 - 12))
            조각.append(글자(폭 / 2, 다음y + 사이 + 2, "끝", 11, "middle"))
    조각.append(꼬리)
    return "".join(조각)


# ── 만들기 ──────────────────────────────────────────────────────
def 만들기(출원건: Path, 설정본, 덮어쓰기: bool = False) -> list:
    """도면 폴더에 도 1·도 2 초안 SVG 를 놓는다. 반환 [(파일, 상태)]"""
    출원건 = Path(출원건)
    명세서경로 = doc.명세서찾기(출원건, 설정본)
    if 명세서경로 is None:
        raise FileNotFoundError("명세서가 없다")
    명세서 = doc.읽어들이기(명세서경로)
    청구경로 = doc.청구범위찾기(출원건, 설정본) or 명세서경로
    청구범위 = doc.읽어들이기(청구경로)

    도면폴더 = 출원건 / (설정본.경로("drawings_dir", "도면") or "도면")
    도면폴더.mkdir(parents=True, exist_ok=True)

    결과 = []
    for 이름, 그리기 in (("도1_블록도.svg", lambda: 블록도(명세서)),
                      ("도2_순서도.svg", lambda: 순서도(청구범위))):
        자리 = 도면폴더 / 이름
        if 자리.exists() and not 덮어쓰기:
            결과.append((이름, "이미 있어 두었다"))
            continue
        try:
            자리.write_text(그리기(), encoding="utf-8")
            결과.append((이름, "만들었다"))
        except ValueError as 문제:
            결과.append((이름, f"만들지 못했다 — {문제}"))
    return 결과


# ── 잔손질 ──────────────────────────────────────────────────────
def _바꾸기(글: str) -> str:
    return (str(글).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def _줄나누기(글: str, 폭: int, 크기: int) -> list:
    """상자 너비에 맞추어 낱말 단위로 줄을 나눈다. 최대 두 줄."""
    한글자 = 크기 * 0.95
    한줄최대 = max(4, int((폭 - 14) / 한글자))
    if len(글) <= 한줄최대:
        return [글]
    낱말들 = 글.split()
    줄들, 지금 = [], ""
    for 낱말 in 낱말들:
        후보 = (지금 + " " + 낱말).strip()
        if len(후보) <= 한줄최대:
            지금 = 후보
        else:
            if 지금:
                줄들.append(지금)
            지금 = 낱말
    if 지금:
        줄들.append(지금)
    if len(줄들) > 2:
        줄들 = [줄들[0], 줄들[1][:한줄최대 - 1] + "…"]
    return 줄들
