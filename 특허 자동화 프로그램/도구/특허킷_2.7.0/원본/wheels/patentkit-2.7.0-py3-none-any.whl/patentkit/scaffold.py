# -*- coding: utf-8 -*-
"""출원건 폴더 만들기.

명세서·청구범위 뼈대와 설정 파일, 도면·근거자료 폴더를 한 번에 만든다.
뼈대의 ★ 자리는 사람이 채운다. ★가 남아 있으면 검사에서 오류로 잡힌다.
"""
from __future__ import annotations

import json
from pathlib import Path

from .util import 읽기, 쓰기

본틀폴더 = Path(__file__).parent / "templates"
하위폴더 = ["도면", "_근거자료", "_작업이력"]


def 만들기(대상: Path, 명칭: str = "", 덮어쓰기: bool = False) -> list:
    """반환: 만든 파일·폴더 경로 목록."""
    대상 = Path(대상)
    대상.mkdir(parents=True, exist_ok=True)
    만든것 = [대상]

    for 이름 in 하위폴더:
        (대상 / 이름).mkdir(exist_ok=True)
        만든것.append(대상 / 이름)

    for 이름 in ("01_명세서.md", "02_청구범위.md", "04_변리사_검토사항.md"):
        자리 = 대상 / 이름
        if 자리.exists() and not 덮어쓰기:
            continue
        내용 = 읽기(본틀폴더 / 이름)
        if 명칭 and 이름 == "01_명세서.md":
            내용 = 내용.replace("★발명의 명칭", 명칭)
        쓰기(자리, 내용)
        만든것.append(자리)

    설정자리 = 대상 / "patent_config.json"
    if not 설정자리.exists() or 덮어쓰기:
        자료 = json.loads(읽기(본틀폴더 / "patent_config.json"))
        자료["invention"]["title_kr"] = 명칭
        자료["paths"]["base_dir"] = str(대상)
        쓰기(설정자리, json.dumps(자료, ensure_ascii=False, indent=2) + "\n")
        만든것.append(설정자리)

    if 명칭:
        쓰기(대상 / "_발명의명칭.txt", 명칭 + "\n")
        만든것.append(대상 / "_발명의명칭.txt")

    return 만든것
