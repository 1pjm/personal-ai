# -*- coding: utf-8 -*-
"""공통 도구 — 파일 입출력, 검사 결과 자료형, 콘솔 표시."""
from __future__ import annotations

import sys
from dataclasses import dataclass, field, asdict
from datetime import date
from pathlib import Path

오류 = "오류"
경고 = "경고"
안내 = "안내"

등급순위 = {오류: 0, 경고: 1, 안내: 2}


def 콘솔준비() -> None:
    """윈도우 콘솔에서 한글이 깨지지 않게 표준 출력을 UTF-8 로 맞춘다."""
    for 스트림 in (sys.stdout, sys.stderr):
        try:
            스트림.reconfigure(encoding="utf-8")
        except Exception:
            pass


def 읽기(경로: Path) -> str:
    """BOM 이 붙어 있어도 그대로 읽는다."""
    return Path(경로).read_text(encoding="utf-8-sig")


def 쓰기(경로: Path, 내용: str) -> bool:
    """내용이 같으면 쓰지 않는다. 실제로 쓴 경우에만 참을 반환한다."""
    경로 = Path(경로)
    기존 = 읽기(경로) if 경로.exists() else None
    if 기존 == 내용:
        return False
    경로.parent.mkdir(parents=True, exist_ok=True)
    경로.write_text(내용, encoding="utf-8")
    return True


def 백업(경로: Path, 꼬리표: str) -> Path | None:
    """원본을 _작업이력 폴더로 복사해 둔다. 되돌릴 근거를 남기기 위한 것이다."""
    경로 = Path(경로)
    if not 경로.exists():
        return None
    이력 = 경로.parent / "_작업이력"
    이력.mkdir(exist_ok=True)
    대상 = 이력 / f"_backup_{경로.stem}_{date.today():%Y%m%d}_{꼬리표}{경로.suffix}"
    대상.write_text(읽기(경로), encoding="utf-8")
    return 대상


@dataclass
class 지적:
    """검사 한 건의 결과."""

    항목: str            # 검사 묶음 이름. 예 「단락번호」
    규칙: str            # 세부 규칙 이름. 예 「결번」
    등급: str            # 오류·경고·안내
    내용: str
    파일: str = ""
    행: int = 0

    def 한줄(self) -> str:
        위치 = f"{self.파일}:{self.행}" if self.행 else self.파일
        머리 = f"[{self.등급}] {self.항목}·{self.규칙}"
        return f"{머리} — {self.내용}" + (f"  ({위치})" if 위치 else "")


@dataclass
class 검사결과:
    """한 출원건에 대한 검사 전체 결과."""

    대상: str
    지적들: list = field(default_factory=list)
    항목들: list = field(default_factory=list)   # 수행한 검사 묶음의 이름
    수치: dict = field(default_factory=dict)     # 단락 수, 청구항 수 등

    def 더하기(self, 항목: str, 규칙: str, 등급: str, 내용: str,
               파일: str = "", 행: int = 0) -> None:
        self.항목등록(항목)
        self.지적들.append(지적(항목, 규칙, 등급, 내용, 파일, 행))

    def 항목등록(self, 이름: str) -> None:
        if 이름 not in self.항목들:
            self.항목들.append(이름)

    def 셈(self, 등급: str) -> int:
        return sum(1 for 건 in self.지적들 if 건.등급 == 등급)

    @property
    def 오류수(self) -> int:
        return self.셈(오류)

    @property
    def 경고수(self) -> int:
        return self.셈(경고)

    @property
    def 통과항목(self) -> list:
        결함 = {건.항목 for 건 in self.지적들 if 건.등급 in (오류, 경고)}
        return [이름 for 이름 in self.항목들 if 이름 not in 결함]

    def 정렬된지적(self) -> list:
        return sorted(self.지적들,
                      key=lambda 건: (등급순위[건.등급], 건.항목, 건.규칙, 건.파일, 건.행))

    def 사전(self) -> dict:
        return {
            "대상": self.대상,
            "오류": self.오류수,
            "경고": self.경고수,
            "통과항목": self.통과항목,
            "수치": self.수치,
            "지적": [asdict(건) for 건 in self.정렬된지적()],
        }


def 표만들기(머리: list, 행들: list) -> str:
    """콘솔용 고정폭 표. 한글은 두 칸으로 세어 칸을 맞춘다."""

    def 폭(글자: str) -> int:
        return sum(2 if ord(문자) > 0x1100 else 1 for 문자 in 글자)

    칸수 = [max(폭(str(머리[i])), *(폭(str(행[i])) for 행 in 행들)) if 행들
            else 폭(str(머리[i])) for i in range(len(머리))]

    def 한행(값들) -> str:
        조각 = []
        for i, 값 in enumerate(값들):
            글 = str(값)
            조각.append(글 + " " * (칸수[i] - 폭(글)))
        return "  " + " │ ".join(조각)

    줄 = "  " + "─┼─".join("─" * n for n in 칸수)
    return "\n".join([한행(머리), 줄] + [한행(행) for 행 in 행들])
